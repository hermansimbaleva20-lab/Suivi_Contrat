-- MySQL dump 10.13  Distrib 8.4.7, for Win64 (x86_64)
--
-- Host: localhost    Database: prise_db
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alerts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `contract_id` bigint unsigned DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `alerts_project_id_foreign` (`project_id`),
  KEY `alerts_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `machine_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `organizational_unit_id` bigint unsigned DEFAULT NULL,
  `old_values` longtext COLLATE utf8mb4_unicode_ci,
  `new_values` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  KEY `audit_logs_action_index` (`action`),
  KEY `audit_logs_project_id_index` (`project_id`),
  KEY `audit_logs_organizational_unit_id_index` (`organizational_unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,1,'DEMANDE_REINITIALISATION','User','1','Lien non envoyé à hermansimbaleva20@gmail.com : Paramètres SMTP incomplets : renseignez le serveur et l’adresse d’expédition dans Paramètres.','DESKTOP-GHOST','2026-10-14 12:44:47','2026-10-14 12:44:47',NULL,NULL,NULL),(2,1,1,'REINITIALISATION_MOT_DE_PASSE','User','1','Mot de passe défini à l’aide d’un lien de réinitialisation à usage unique.','DESKTOP-GHOST','2026-10-14 13:20:05','2026-10-14 13:20:05',NULL,NULL,NULL),(3,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 13:20:45','2026-10-14 13:20:45',NULL,NULL,NULL),(4,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 13:21:46','2026-10-14 13:21:46',NULL,NULL,NULL),(5,2,2,'REINITIALISATION_MOT_DE_PASSE','User','2','Mot de passe défini à l’aide d’un lien de réinitialisation à usage unique.','DESKTOP-GHOST','2026-10-14 13:22:41','2026-10-14 13:22:41',NULL,NULL,NULL),(6,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-14 13:23:28','2026-10-14 13:23:28',NULL,NULL,NULL),(7,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 13:27:38','2026-10-14 13:27:38',NULL,NULL,NULL),(8,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 13:49:24','2026-10-14 13:49:24',NULL,NULL,NULL),(9,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-14 13:50:08','2026-10-14 13:50:08',NULL,NULL,NULL),(10,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 14:00:56','2026-10-14 14:00:56',NULL,NULL,NULL),(11,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 06:49:40','2026-10-15 06:49:40',NULL,NULL,NULL),(12,1,1,'NOTIFICATION_MDP_LUE','PasswordResetRequest','1','Notification de rÃ©initialisation marquÃ©e comme lue.','DESKTOP-GHOST','2026-10-15 06:56:02','2026-10-15 06:56:02',NULL,NULL,NULL),(13,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-15 06:58:20','2026-10-15 06:58:20',NULL,NULL,NULL),(14,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 07:00:33','2026-10-15 07:00:33',NULL,NULL,NULL),(15,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 08:40:08','2026-10-15 08:40:08',NULL,NULL,NULL),(16,1,1,'CREATION','Company','1','Entreprise SZTC créée.','DESKTOP-GHOST','2026-10-15 08:58:09','2026-10-15 08:58:09',NULL,NULL,NULL),(17,1,1,'COORDONNEES','Company','1','Coordonnées de l’entreprise SZTC mises à jour.','DESKTOP-GHOST','2026-10-15 08:58:26','2026-10-15 08:58:26',NULL,NULL,NULL),(18,1,1,'CREATION','Company','2','Entreprise SAGEC-KAT créée.','DESKTOP-GHOST','2026-10-15 08:58:58','2026-10-15 08:58:58',NULL,NULL,NULL),(19,1,1,'CREATION','Company','3','Entreprise CGC créée.','DESKTOP-GHOST','2026-10-15 09:00:05','2026-10-15 09:00:05',NULL,NULL,NULL),(20,1,1,'CREATION','Contract','1','Contrat 068 créé avec 4 site(s).','DESKTOP-GHOST','2026-10-15 09:08:38','2026-10-15 09:08:38',NULL,NULL,NULL),(21,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 09:37:20','2026-10-15 09:37:20',NULL,NULL,NULL),(22,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 09:37:53','2026-10-15 09:37:53',NULL,NULL,NULL),(23,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-15 09:40:50','2026-10-15 09:40:50',NULL,NULL,NULL),(24,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 09:41:43','2026-10-15 09:41:43',NULL,NULL,NULL),(25,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 09:51:53','2026-10-15 09:51:53',NULL,NULL,NULL),(26,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 12:20:37','2026-10-15 12:20:37',NULL,NULL,NULL),(27,1,1,'CREATION','Contract','2','Contrat 069 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-15 12:57:07','2026-10-15 12:57:07',NULL,NULL,NULL),(28,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 13:01:00','2026-10-15 13:01:00',NULL,NULL,NULL),(29,1,1,'CREATION','Contract','3','Contrat 070 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-15 13:20:10','2026-10-15 13:20:10',NULL,NULL,NULL),(30,1,1,'MODIFICATION','Contract','3','Contrat 070 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-15 13:24:48','2026-10-15 13:24:48',NULL,NULL,NULL),(31,1,1,'TEST_SMTP','SmtpSetting','1','Aucun destinataire valide n’est configuré.','DESKTOP-GHOST','2026-10-15 13:30:23','2026-10-15 13:30:23',NULL,NULL,NULL),(32,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:32:19','2026-10-15 13:32:19',NULL,NULL,NULL),(33,1,1,'TEST_SMTP','SmtpSetting','1','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c3eda61fb26sm132808166b.69 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-10-15 13:32:44','2026-10-15 13:32:44',NULL,NULL,NULL),(34,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:34:19','2026-10-15 13:34:19',NULL,NULL,NULL),(35,1,1,'TEST_SMTP','SmtpSetting','1','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c3ed6be6ddasm138225366b.7 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-10-15 13:34:23','2026-10-15 13:34:23',NULL,NULL,NULL),(36,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261015_143425.sql.gz.','DESKTOP-GHOST','2026-10-15 13:34:25','2026-10-15 13:34:25',NULL,NULL,NULL),(37,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261015_143436.sql.gz.','DESKTOP-GHOST','2026-10-15 13:34:36','2026-10-15 13:34:36',NULL,NULL,NULL),(38,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:43:47','2026-10-15 13:43:47',NULL,NULL,NULL),(39,1,1,'TEST_SMTP','SmtpSetting','1','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c3ed6be6546sm135422966b.4 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-10-15 13:43:52','2026-10-15 13:43:52',NULL,NULL,NULL),(40,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:45:13','2026-10-15 13:45:13',NULL,NULL,NULL),(41,1,1,'TEST_SMTP','SmtpSetting','1','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c3eda620c30sm135172766b.66 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-10-15 13:45:21','2026-10-15 13:45:21',NULL,NULL,NULL),(42,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261015_144636.sql.gz.','DESKTOP-GHOST','2026-10-15 13:46:36','2026-10-15 13:46:36',NULL,NULL,NULL),(43,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:54:15','2026-10-15 13:54:15',NULL,NULL,NULL),(44,1,1,'TEST_SMTP','SmtpSetting','1','Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-15 13:54:24','2026-10-15 13:54:24',NULL,NULL,NULL),(45,1,1,'TEST_SMTP','SmtpSetting','1','Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-15 13:54:31','2026-10-15 13:54:31',NULL,NULL,NULL),(46,1,1,'ALERTE_GARANTIE','PerformanceGuarantee','2','Alerte « 069 » envoyée manuellement. Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-15 13:55:02','2026-10-15 13:55:02',NULL,NULL,NULL),(47,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-16 06:57:04','2026-10-16 06:57:04',NULL,NULL,NULL),(48,1,1,'CREATION','Contract','4','Contrat 071 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-16 07:55:09','2026-10-16 07:55:09',NULL,NULL,NULL),(49,1,1,'CREATION','Contract','5','Contrat 072 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-16 08:07:40','2026-10-16 08:07:40',NULL,NULL,NULL),(50,1,1,'MODIFICATION','Contract','5','Contrat 072 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:07:55','2026-10-16 08:07:55',NULL,NULL,NULL),(51,1,1,'MODIFICATION','Contract','1','Contrat 068 modifié avec 4 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:08:25','2026-10-16 08:08:25',NULL,NULL,NULL),(52,1,1,'MODIFICATION','Contract','2','Contrat 069 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:08:45','2026-10-16 08:08:45',NULL,NULL,NULL),(53,1,1,'MODIFICATION','Contract','3','Contrat 070 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:09:14','2026-10-16 08:09:14',NULL,NULL,NULL),(54,1,1,'MODIFICATION','Contract','4','Contrat 071 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:10:14','2026-10-16 08:10:14',NULL,NULL,NULL),(55,1,1,'CREATION','Contract','6','Contrat 073 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-16 09:47:51','2026-10-16 09:47:51',NULL,NULL,NULL),(56,1,1,'CREATION','Contract','7','Contrat 091 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-16 09:54:14','2026-10-16 09:54:14',NULL,NULL,NULL),(57,1,1,'MODIFICATION','Contract','7','Contrat 091 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 10:06:09','2026-10-16 10:06:09',NULL,NULL,NULL),(58,1,1,'CREATION','ProgressEntry','1','Situation du contrat 068 : 16/10/2026, avancement 78 %.','DESKTOP-GHOST','2026-10-16 10:15:22','2026-10-16 10:15:22',NULL,NULL,NULL),(59,1,1,'MODIFICATION','Contract','1','Contrat 068 modifié avec 4 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 10:24:34','2026-10-16 10:24:34',NULL,NULL,NULL),(60,1,1,'CREATION','ProgressEntry','2','Situation du contrat 068 : 30/09/2026, avancement 39 %.','DESKTOP-GHOST','2026-10-16 10:41:49','2026-10-16 10:41:49',NULL,NULL,NULL),(61,1,1,'MODIFICATION','ProgressEntry','1','Contrat 068. Ancienne situation : date 16/10/2026, avancement 78 %. Nouvelle : date 30/09/2026, avancement 78 %.','DESKTOP-GHOST','2026-10-16 10:42:06','2026-10-16 10:42:06',NULL,NULL,NULL),(62,1,1,'CREATION','ProgressEntry','3','Situation du contrat 068 : 30/09/2026, avancement 21 %.','DESKTOP-GHOST','2026-10-16 10:45:06','2026-10-16 10:45:06',NULL,NULL,NULL),(63,1,1,'CREATION','ProgressEntry','4','Situation du contrat 068 : 30/09/2026, avancement 1 %.','DESKTOP-GHOST','2026-10-16 11:04:49','2026-10-16 11:04:49',NULL,NULL,NULL),(64,1,1,'MODIFICATION','Contract','1','Contrat 068 modifié avec 4 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 11:06:29','2026-10-16 11:06:29',NULL,NULL,NULL),(65,1,1,'CREATION','ContractPayment','1','Paiement du contrat 068, date 30/09/2026, montant 352 268,82.','DESKTOP-GHOST','2026-10-16 12:29:46','2026-10-16 12:29:46',NULL,NULL,NULL),(66,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 15:45:19','2026-10-18 15:45:19',NULL,NULL,NULL),(67,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 16:00:23','2026-10-18 16:00:23',NULL,NULL,NULL),(68,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 16:29:10','2026-10-18 16:29:10',NULL,NULL,NULL),(69,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 16:48:27','2026-10-18 16:48:27',NULL,NULL,NULL),(70,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 22:22:26','2026-10-18 22:22:26',NULL,NULL,NULL),(71,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 22:51:35','2026-10-18 22:51:35',NULL,NULL,NULL),(72,1,3,'DEMANDE_INSCRIPTION','User','3','Demande d’inscription de jorcelinmikado@gmail.com, en attente de validation.','DESKTOP-GHOST','2026-10-18 22:53:27','2026-10-18 22:53:27',NULL,NULL,NULL),(73,1,1,'APPROBATION_COMPTE','User','3','Compte jorcelinmikado@gmail.com approuvÃ© (lecture seule). Ajustez les habilitations si nÃ©cessaire.','DESKTOP-GHOST','2026-10-18 22:53:58','2026-10-18 22:53:58',NULL,NULL,NULL),(74,1,3,'CONNEXION','User','3','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 22:54:42','2026-10-18 22:54:42',NULL,NULL,NULL),(75,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises Ã  jour.','DESKTOP-GHOST','2026-10-18 22:56:10','2026-10-18 22:56:10',NULL,NULL,NULL),(76,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises Ã  jour.','DESKTOP-GHOST','2026-10-18 22:57:35','2026-10-18 22:57:35',NULL,NULL,NULL),(77,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-19 06:31:46','2026-10-19 06:31:46',NULL,NULL,NULL),(78,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261019_084637.sql.gz.','DESKTOP-GHOST','2026-10-19 07:46:37','2026-10-19 07:46:37',NULL,NULL,NULL),(79,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-19 13:09:57','2026-10-19 13:09:57',NULL,NULL,NULL),(80,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-19 13:54:26','2026-10-19 13:54:26',NULL,NULL,NULL),(81,1,1,'CREATION','ProgressEntry','5','Situation du contrat 069 : 30/09/2026, avancement 24 %.','DESKTOP-GHOST','2026-10-19 13:58:27','2026-10-19 13:58:27',NULL,NULL,NULL),(82,1,1,'CREATION','ProgressEntry','6','Situation du contrat 069 : 30/09/2026, avancement 28 %.','DESKTOP-GHOST','2026-10-19 14:01:26','2026-10-19 14:01:26',NULL,NULL,NULL),(83,1,1,'MODIFICATION','ProgressEntry','5','Contrat 069. Ancienne situation : date 30/09/2026, avancement 24 %. Nouvelle : date 30/09/2026, avancement 24 %.','DESKTOP-GHOST','2026-10-19 14:01:45','2026-10-19 14:01:45',NULL,NULL,NULL),(84,1,1,'CREATION','ProgressEntry','7','Situation du contrat 069 : 30/09/2026, avancement 19 %.','DESKTOP-GHOST','2026-10-19 14:04:46','2026-10-19 14:04:46',NULL,NULL,NULL),(85,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-22 14:18:36','2026-10-22 14:18:36',NULL,NULL,NULL),(86,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises Ã  jour.','DESKTOP-GHOST','2026-10-22 15:20:47','2026-10-22 15:20:47',NULL,NULL,NULL),(87,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-22 20:11:51','2026-10-22 20:11:51',NULL,NULL,NULL),(88,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 09:41:12','2026-10-28 09:41:12',NULL,NULL,NULL),(89,1,1,'ALERTE_RETARD','Contract','3','Alerte « 070 » envoyée manuellement. Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-28 12:37:06','2026-10-28 12:37:06',NULL,NULL,NULL),(90,1,1,'ALERTE_RETARD','Contract','2','Alerte « 069 » envoyée manuellement. Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-28 12:37:12','2026-10-28 12:37:12',NULL,NULL,NULL),(91,1,1,'MODIFICATION_UNITE','OrganizationalUnit','1','Unité Coordination nationale modifiée.','DESKTOP-GHOST','2026-10-28 12:40:00','2026-10-28 12:40:00',NULL,'{\"id\":1,\"project_id\":1,\"type\":\"COORDINATION\",\"code\":\"CN\",\"name\":\"Coordination nationale\",\"province\":null,\"description\":null,\"is_active\":1}','{\"id\":1,\"project_id\":1,\"type\":\"COORDINATION\",\"code\":\"CN\",\"name\":\"Coordination nationale\",\"province\":\"Kinshasa\",\"description\":null,\"is_active\":1}'),(92,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 12:50:06','2026-10-28 12:50:06',NULL,NULL,NULL),(93,1,1,'CREATION_POSTE','Position','1','Poste CN créé.','DESKTOP-GHOST','2026-10-28 12:51:28','2026-10-28 12:51:28',NULL,NULL,'{\"name\":\"CN\",\"description\":\"COORDINATION NATIONALE\",\"project_id\":1,\"is_active\":true,\"id\":1}'),(94,1,1,'CREATION_POSTE','Position','2','Poste HNRAF créé.','DESKTOP-GHOST','2026-10-28 12:52:45','2026-10-28 12:52:45',NULL,NULL,'{\"name\":\"HNRAF\",\"description\":\"MANDAT DE L’HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"project_id\":1,\"is_active\":true,\"id\":2}'),(95,1,1,'CREATION_POSTE','Position','3','Poste COMPTABLE créé.','DESKTOP-GHOST','2026-10-28 12:53:12','2026-10-28 12:53:12',NULL,NULL,'{\"name\":\"COMPTABLE\",\"description\":\"COMPTABLE\",\"project_id\":1,\"is_active\":true,\"id\":3}'),(96,1,1,'MODIFICATION_POSTE','Position','2','Poste HNRAF modifié.','DESKTOP-GHOST','2026-10-28 12:53:23','2026-10-28 12:53:23',NULL,'{\"id\":2,\"project_id\":1,\"name\":\"HNRAF\",\"description\":\"MANDAT DE L’HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"is_active\":1}','{\"id\":2,\"project_id\":1,\"name\":\"HNRAF\",\"description\":\"HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"is_active\":1}'),(97,1,1,'CREATION_POSTE','Position','4','Poste AC créé.','DESKTOP-GHOST','2026-10-28 12:53:51','2026-10-28 12:53:51',NULL,NULL,'{\"name\":\"AC\",\"description\":\"ASSISTANT COMPTABLE\",\"project_id\":1,\"is_active\":true,\"id\":4}'),(98,1,1,'CREATION_POSTE','Position','5','Poste HCPM créé.','DESKTOP-GHOST','2026-10-28 12:54:25','2026-10-28 12:54:25',NULL,NULL,'{\"name\":\"HCPM\",\"description\":\"HOMOLOGUE NATIONAL EN PASSATION DE MARCHES\",\"project_id\":1,\"is_active\":true,\"id\":5}'),(99,1,1,'MODIFICATION_UNITE','OrganizationalUnit','1','Unité Coordination nationale modifiée.','DESKTOP-GHOST','2026-10-28 12:54:50','2026-10-28 12:54:50',NULL,'{\"id\":1,\"project_id\":1,\"type\":\"COORDINATION\",\"code\":\"CN\",\"name\":\"Coordination nationale\",\"province\":\"Kinshasa\",\"description\":null,\"is_active\":1}','{\"id\":1,\"project_id\":1,\"type\":\"COORDINATION\",\"code\":\"CN\",\"name\":\"Coordination nationale\",\"province\":\"Kinshasa\",\"description\":null,\"is_active\":1}'),(100,1,1,'CREATION_POSTE','Position','6','Poste APM créé.','DESKTOP-GHOST','2026-10-28 12:55:40','2026-10-28 12:55:40',NULL,NULL,'{\"name\":\"APM\",\"description\":\"ASSISTANT EN PASSATION DES MARCHES\",\"project_id\":1,\"is_active\":true,\"id\":6}'),(101,1,1,'CREATION_POSTE','Position','7','Poste HNSE créé.','DESKTOP-GHOST','2026-10-28 12:59:35','2026-10-28 12:59:35',NULL,NULL,'{\"name\":\"HNSE\",\"description\":\"HOMOLOGUE NATIONAL EN SUIVI-EVALUATION\",\"project_id\":1,\"is_active\":true,\"id\":7}'),(102,1,1,'CREATION_POSTE','Position','8','Poste CCI créé.','DESKTOP-GHOST','2026-10-28 13:00:52','2026-10-28 13:00:52',NULL,NULL,'{\"name\":\"CCI\",\"description\":\"CHEF DE CELLULE INFRASTRUCTURES (AEP)\",\"project_id\":1,\"is_active\":true,\"id\":8}');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observation` text COLLATE utf8mb4_unicode_ci,
  `guarantee_bank` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantee_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantee_observation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_project_id_name_unique` (`project_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,1,'SZTC','','','','','','','','2026-10-15 08:58:09','2026-10-15 08:58:26'),(2,1,'SAGEC-KAT','','','','','','','','2026-10-15 08:58:58','2026-10-15 08:58:58'),(3,1,'CGC','','','','','','','','2026-10-15 09:00:05','2026-10-15 09:00:05');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_amendments`
--

DROP TABLE IF EXISTS `contract_amendments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_amendments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `duration_days` int NOT NULL DEFAULT '0',
  `added_months` int unsigned NOT NULL DEFAULT '0',
  `previous_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_amendments_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_amendments`
--

LOCK TABLES `contract_amendments` WRITE;
/*!40000 ALTER TABLE `contract_amendments` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_amendments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_documents`
--

DROP TABLE IF EXISTS `contract_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `original_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storage_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint unsigned NOT NULL DEFAULT '0',
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_documents_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_documents`
--

LOCK TABLES `contract_documents` WRITE;
/*!40000 ALTER TABLE `contract_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_payments`
--

DROP TABLE IF EXISTS `contract_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_payments_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_payments`
--

LOCK TABLES `contract_payments` WRITE;
/*!40000 ALTER TABLE `contract_payments` DISABLE KEYS */;
INSERT INTO `contract_payments` VALUES (1,1,'2026-09-30',352268.82,'','','2026-10-16 12:29:46','2026-10-16 12:29:46');
/*!40000 ALTER TABLE `contract_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_sites`
--

DROP TABLE IF EXISTS `contract_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_sites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `province` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `work_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` decimal(15,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_sites_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_sites`
--

LOCK TABLES `contract_sites` WRITE;
/*!40000 ALTER TABLE `contract_sites` DISABLE KEYS */;
INSERT INTO `contract_sites` VALUES (1,1,'Kasaï Oriental','Système d’AEP','MUKEBA','Un Forage, un CE de 100 m3, 3395 de tuyaux PEHD de distribution et refoulement et 12 BF et 3 BP;',1.00,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(2,1,'Kasaï Oriental','Système d’AEP','BENA-KABIMBA','Un Forage, un CE de 100 m3, 4790 ml de tuyaux PEHD de distribution et refoulement et 15 BF et 9 BP;',1.00,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(3,1,'Kasaï Oriental','Système d’AEP','MULOWAYI','Un Forage, un CE de 30 m3, 5490 ml de tuyaux PEHD de distribution et refoulement et 4 BF ;',1.00,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(4,1,'Kasaï Oriental','Système d’AEP','TSHILUNDU','Un Forage, un CE de 100 m3, 3395 ml de tuyaux PEHD de distribution et refoulement et 12 BF et 3 BP;',1.00,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(5,2,'Sankuru','Système d’AEP','DJALO','Système d’AEP',1.00,'2026-10-15 12:57:07','2026-10-16 08:08:45'),(6,2,'Sankuru','Système d’AEP','BAKWA-BUMBA','Système d’AEP',1.00,'2026-10-15 12:57:07','2026-10-16 08:08:45'),(7,2,'Sankuru','Système d’AEP','MUKUMARI','Système d’AEP',1.00,'2026-10-15 12:57:07','2026-10-16 08:08:45'),(8,3,'Maniema','Système d’AEP','DIFUMA 2','Système d’AEP',1.00,'2026-10-15 13:20:10','2026-10-16 08:09:14'),(9,3,'Maniema','Système d’AEP','LOWE','Système d’AEP',1.00,'2026-10-15 13:20:10','2026-10-16 08:09:14'),(10,3,'Maniema','Système d’AEP','KIMBOMBO','Système d’AEP',1.00,'2026-10-15 13:20:10','2026-10-16 08:09:14'),(11,4,'Kasaï','Système d’AEP','KAMWESHA','Système d’AEP',1.00,'2026-10-16 07:55:09','2026-10-16 08:10:14'),(12,4,'Kasaï','Système d’AEP','LOUANGE','Système d’AEP',1.00,'2026-10-16 07:55:09','2026-10-16 08:10:14'),(13,4,'Kasaï','Système d’AEP','KABAMBAYI','Système d’AEP',1.00,'2026-10-16 07:55:09','2026-10-16 08:10:14'),(14,5,'Kwilu','Système d’AEP','LUEKESHI','Système d’AEP',1.00,'2026-10-16 08:07:40','2026-10-16 08:07:55'),(15,5,'Kwilu','Système d’AEP','LUAMBO','Système d’AEP',1.00,'2026-10-16 08:07:40','2026-10-16 08:07:55'),(16,5,'Kwilu','Système d’AEP','KALAMBA MBUJ','Système d’AEP',1.00,'2026-10-16 08:07:40','2026-10-16 08:07:55'),(17,6,'Kwilu','Système d’AEP','KWENGE CENTRE','Système d’AEP',1.00,'2026-10-16 09:47:51','2026-10-16 09:47:51'),(18,6,'Kwilu','Système d’AEP','MUKEDI','Système d’AEP',1.00,'2026-10-16 09:47:51','2026-10-16 09:47:51'),(19,6,'Kwilu','Système d’AEP','MASAMUNA','Système d’AEP',1.00,'2026-10-16 09:47:51','2026-10-16 09:47:51'),(20,7,'Lomami','Système d’AEP','PENGYE','Système d’AEP',1.00,'2026-10-16 09:54:14','2026-10-16 10:06:09'),(21,7,'Lomami','Système d’AEP','TSHILEU/BAKWA MULUMBA','Système d’AEP',1.00,'2026-10-16 09:54:14','2026-10-16 10:06:09'),(22,7,'Lomami','Système d’AEP','KANYIKI MUTEMBWE','Système d’AEP',1.00,'2026-10-16 09:54:14','2026-10-16 10:06:09');
/*!40000 ALTER TABLE `contract_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `phase_id` bigint unsigned NOT NULL,
  `company_id` bigint unsigned NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `signature_date` date DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `duration_months` int unsigned DEFAULT NULL,
  `initial_financing_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `activities` text COLLATE utf8mb4_unicode_ci,
  `work_type_text` text COLLATE utf8mb4_unicode_ci,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `termination_date` date DEFAULT NULL,
  `termination_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contracts_project_reference_unique` (`project_id`,`reference`),
  KEY `contracts_phase_id_foreign` (`phase_id`),
  KEY `contracts_company_id_foreign` (`company_id`),
  KEY `contracts_project_id_phase_id_index` (`project_id`,`phase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
INSERT INTO `contracts` VALUES (1,1,1,1,'068',NULL,'Kasaï Oriental','TRAVAUX',3381983.53,'2025-01-22','2025-04-03','2027-04-03',24,30.00,'4 AEP sur les sites de MPANDA, BENA-KABIMBA, MULOWAYI et TSHILUNDU, dans la Province du Kasai-Oriental;','Système d’AEP',0,NULL,NULL,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(2,1,1,2,'069',NULL,'Sankuru','TRAVAUX',2555335.00,'2025-01-31','2025-06-06','2027-06-06',24,30.00,'3 AEP sur les sites de DJALO, BAKWA-BUMBA, et MUKUMARI dans la province du SANKURU','Système d’AEP',0,NULL,NULL,'2026-10-15 12:57:07','2026-10-16 08:08:45'),(3,1,1,2,'070',NULL,'Maniema','TRAVAUX',2512215.00,'2025-01-31','2025-06-06','2027-06-06',24,30.00,'3 AEP sur les sites DIFUMA 2, LOWE et KIMBOMBO, dans la Province du Maniema','Système d’AEP',0,NULL,NULL,'2026-10-15 13:20:10','2026-10-16 08:09:14'),(4,1,1,1,'071',NULL,'Kasaï','TRAVAUX',2942138.63,'2025-01-22','2025-04-03','2027-04-03',24,30.00,'3 AEP sur les sites de KAMWESHA, LOUANGE et KABAMBAYI secteur, dans le Kasai','Système d’AEP',0,NULL,NULL,'2026-10-16 07:55:09','2026-10-16 08:10:14'),(5,1,1,1,'072',NULL,'Kwilu','TRAVAUX',3591585.03,'2025-01-22','2025-04-03','2027-04-03',24,30.00,'3 AEP surles sites de LUEKESHI, LUAMBO et KALAMBA MBUJI dans la Province du Kasai','Système d’AEP',0,NULL,NULL,'2026-10-16 08:07:40','2026-10-16 08:07:55'),(6,1,1,3,'073',NULL,'Kwilu','TRAVAUX',3052291.32,'2025-01-22','2025-03-26','2027-03-26',24,30.00,'3 AEP sur les sites de KWENGE CENTRE, MUKEDI et MASAMUNA dans la Province du Kwilu','Système d’AEP',0,NULL,NULL,'2026-10-16 09:47:51','2026-10-16 09:47:51'),(7,1,1,2,'091',NULL,'Lomami','TRAVAUX',0.00,'2026-08-19','2026-09-29','2028-03-29',18,0.00,'3 AEP sur les sites de PENGYE, TSHILEU/BAKWA MULUMBA, KANYIKI MUTEMBWE dans la Province de Lomami','Système d’AEP',0,NULL,NULL,'2026-10-16 09:54:14','2026-10-16 10:06:09');
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guarantee_extensions`
--

DROP TABLE IF EXISTS `guarantee_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guarantee_extensions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `performance_guarantee_id` bigint unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `type` enum('RENOUVELLEMENT','PROLONGATION') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROLONGATION',
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `guarantee_extensions_performance_guarantee_id_foreign` (`performance_guarantee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guarantee_extensions`
--

LOCK TABLES `guarantee_extensions` WRITE;
/*!40000 ALTER TABLE `guarantee_extensions` DISABLE KEYS */;
/*!40000 ALTER TABLE `guarantee_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` timestamp NULL DEFAULT NULL,
  `available_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026_10_07_000000_create_prise_schema',1),(2,'2026_10_11_000001_extend_users_for_legacy_accounts',1),(3,'2026_10_11_000002_extend_contract_details',1),(4,'2026_10_12_000003_add_legacy_workflow_fields',1),(5,'2026_10_20_000004_align_with_csharp_features',2),(6,'2026_10_28_000004_convert_tables_to_innodb',3),(7,'2026_10_28_000005_create_organizational_structure',3),(8,'2026_10_28_000006_seed_initial_pools',4),(9,'2026_10_28_000007_create_stock_module',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizational_units`
--

DROP TABLE IF EXISTS `organizational_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizational_units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `org_units_project_code_unique` (`project_id`,`code`),
  KEY `org_units_project_type_idx` (`project_id`,`type`,`is_active`),
  CONSTRAINT `organizational_units_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizational_units`
--

LOCK TABLES `organizational_units` WRITE;
/*!40000 ALTER TABLE `organizational_units` DISABLE KEYS */;
INSERT INTO `organizational_units` VALUES (1,1,'COORDINATION','CN','Coordination nationale','Kinshasa',NULL,1,'2026-10-28 10:54:35','2026-10-28 12:40:00'),(2,2,'COORDINATION','CN','Coordination nationale',NULL,NULL,1,'2026-10-28 10:54:35','2026-10-28 10:54:35'),(3,1,'POOL','MBUJI-MAYI','Antenne MBUJI-MAYI','Kasaï-Oriental',NULL,1,'2026-10-28 12:10:26','2026-10-28 12:10:26'),(4,1,'POOL','KANANGA','Antenne KANANGA','Kasaï-Central',NULL,1,'2026-10-28 12:10:26','2026-10-28 12:10:26'),(5,2,'POOL','GBADOLITE','Antenne GBADOLITE','Nord-Ubangi',NULL,1,'2026-10-28 12:10:26','2026-10-28 12:10:26');
/*!40000 ALTER TABLE `organizational_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_requests`
--

DROP TABLE IF EXISTS `password_reset_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requested_at` timestamp NULL DEFAULT NULL,
  `is_read_by_admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Lien envoyé',
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `password_reset_requests_project_id_is_read_by_admin_index` (`project_id`,`is_read_by_admin`),
  KEY `password_reset_requests_project_id_index` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_requests`
--

LOCK TABLES `password_reset_requests` WRITE;
/*!40000 ALTER TABLE `password_reset_requests` DISABLE KEYS */;
INSERT INTO `password_reset_requests` VALUES (1,1,1,'hermansimbaleva20@gmail.com','2026-10-14 12:44:47',1,'Envoi impossible — réinitialisation manuelle requise',NULL,'2026-10-14 12:44:47','2026-10-15 06:56:02');
/*!40000 ALTER TABLE `password_reset_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performance_guarantees`
--

DROP TABLE IF EXISTS `performance_guarantees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_guarantees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `contract_id` bigint unsigned NOT NULL,
  `company_id` bigint unsigned NOT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(5,2) NOT NULL DEFAULT '5.00',
  `amount` decimal(15,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `observation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_guarantees_contract_id_unique` (`contract_id`),
  KEY `performance_guarantees_project_id_foreign` (`project_id`),
  KEY `performance_guarantees_company_id_foreign` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_guarantees`
--

LOCK TABLES `performance_guarantees` WRITE;
/*!40000 ALTER TABLE `performance_guarantees` DISABLE KEYS */;
INSERT INTO `performance_guarantees` VALUES (1,1,1,1,'','',5.00,169099.18,'2025-04-03','2027-04-03','','2026-10-15 09:08:38','2026-10-15 09:08:38'),(2,1,2,2,'Equity-BCDC','11373839494943',5.00,127766.75,'2025-06-12','2026-07-12','','2026-10-15 12:57:07','2026-10-15 12:57:07'),(3,1,3,2,'Rawbank','115577389202',5.00,125610.75,'2025-06-12','2027-07-01','','2026-10-15 13:20:10','2026-10-15 13:20:10'),(4,1,4,1,'','',5.00,147106.93,'2025-04-03','2027-04-03','','2026-10-16 07:55:09','2026-10-16 07:55:09'),(5,1,5,1,'173883199007','SOFIBANK',5.00,179579.25,'2025-01-02','2026-09-04','','2026-10-16 08:07:40','2026-10-16 08:07:40'),(6,1,6,3,'','',5.00,152614.57,'2025-03-26','2027-03-26','','2026-10-16 09:47:51','2026-10-16 09:47:51'),(7,1,7,2,'','',5.00,149.30,'2026-09-29','2028-03-29','','2026-10-16 09:54:14','2026-10-16 09:54:14');
/*!40000 ALTER TABLE `performance_guarantees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_id` bigint unsigned NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,1,'App\\Models\\User','prise-web','27289fb8c61f9600c54c30771a907bbc8ae14e9d1593f941374d95efcb4ad3f8','[\"*\"]','2026-10-14 13:20:46','2026-10-28 13:20:45','2026-10-14 13:20:45','2026-10-14 13:20:46'),(2,1,'App\\Models\\User','prise-web','25c801a592972507e79c08a761c331b16e67d19d2648fc7e29abb5ccddc16a6b','[\"*\"]','2026-10-14 13:21:46','2026-10-28 13:21:46','2026-10-14 13:21:46','2026-10-14 13:21:46'),(3,2,'App\\Models\\User','prise-web','79cd6036923a37c44292a497c3c1f444c750c15131478ee76c430ac02708cf99','[\"*\"]','2026-10-14 13:23:28','2026-10-28 13:23:28','2026-10-14 13:23:28','2026-10-14 13:23:28'),(4,1,'App\\Models\\User','prise-web','a3de58778bc94c67b1fed55de5f1e140ff796e0400867be1a16b8737ccad12fc','[\"*\"]','2026-10-14 13:27:39','2026-10-28 13:27:38','2026-10-14 13:27:38','2026-10-14 13:27:39'),(5,1,'App\\Models\\User','prise-web','03080256e3461d2dc0df1d7977ce779d4ca264310dee4acee40dde87d67da637','[\"*\"]','2026-10-14 13:49:24','2026-10-28 13:49:24','2026-10-14 13:49:24','2026-10-14 13:49:24'),(6,2,'App\\Models\\User','prise-web','999b5c930e5a4d20dbb996ac562dd1cf0cff048a0380d8b89e3af8970ed6844a','[\"*\"]','2026-10-14 13:50:08','2026-10-28 13:50:08','2026-10-14 13:50:08','2026-10-14 13:50:08'),(7,1,'App\\Models\\User','prise-web','571b31450b31fbb7e2843b00b06ccacd91571455aeb4372bc62fbb0ccac7adcf','[\"*\"]','2026-10-14 14:52:36','2026-10-28 14:00:56','2026-10-14 14:00:56','2026-10-14 14:52:36'),(11,1,'App\\Models\\User','prise-web','01d8c87ec95eaf8bbb1c62f7bbe97c64aa305ebd4cbffaef0b52d99d0aaf8f08','[\"*\"]','2026-10-15 09:36:40','2026-10-29 08:40:08','2026-10-15 08:40:08','2026-10-15 09:36:40'),(12,1,'App\\Models\\User','prise-web','42442a5da6e993285a1c2ccfb6ad3498dc9394ee9310e354282684dbf0bc4325','[\"*\"]','2026-10-15 09:37:20','2026-10-29 09:37:20','2026-10-15 09:37:20','2026-10-15 09:37:20'),(13,1,'App\\Models\\User','prise-web','5f7bf594ef53ac7aebd58f4d8b3171842900a6a5be5ab19ee7e507d6270dd09b','[\"*\"]','2026-10-15 09:37:53','2026-10-29 09:37:53','2026-10-15 09:37:53','2026-10-15 09:37:53'),(15,1,'App\\Models\\User','prise-web','c685d0f49549a4673daeee85f994a0e1e8a90455afcfe285bfced41f49d09b57','[\"*\"]','2026-10-15 09:41:43','2026-10-29 09:41:43','2026-10-15 09:41:43','2026-10-15 09:41:43'),(16,1,'App\\Models\\User','prise-web','d83705fa0f50633978b630367912d32298e0c9bbe11756f12667976ad639ffed','[\"*\"]','2026-10-15 09:51:53','2026-10-29 09:51:53','2026-10-15 09:51:53','2026-10-15 09:51:53'),(18,1,'App\\Models\\User','prise-web','b8c1e841d95453e330c21710912f3993b40b828a8b28c5f43340519f96560752','[\"*\"]','2026-10-17 08:30:38','2026-10-29 13:01:00','2026-10-15 13:01:00','2026-10-17 08:30:38'),(20,1,'App\\Models\\User','prise-web','e8dfc4e8489ecfc4eba74bf338c7d5f987c8a701ef5a41b2d92d888ba4bb910d','[\"*\"]','2026-10-18 15:47:17','2026-11-01 15:45:19','2026-10-18 15:45:19','2026-10-18 15:47:17'),(21,1,'App\\Models\\User','prise-web','0a2efb05c0206bc1178c1b5be5c92a7498afa8766797a0b36c56d3ee7ed1d0b3','[\"*\"]','2026-10-18 16:13:11','2026-11-01 16:00:23','2026-10-18 16:00:23','2026-10-18 16:13:11'),(22,1,'App\\Models\\User','prise-web','4fee4927e182c60fb915b9ba6691b7c638397af0088c7d86dd5d0d4401a73f4e','[\"*\"]','2026-10-19 13:01:50','2026-11-01 16:29:10','2026-10-18 16:29:10','2026-10-19 13:01:50'),(23,1,'App\\Models\\User','prise-web','490b5aee7230e9375bc02ffb313630838f3f717b02df4cc5264d5cd7c332bd80','[\"*\"]','2026-10-18 17:50:38','2026-11-01 16:48:27','2026-10-18 16:48:27','2026-10-18 17:50:38'),(24,1,'App\\Models\\User','prise-web','7eb763e928110ce9a9661ed476a1b67cde8f8f42412ed313fb5e57d395001101','[\"*\"]','2026-10-18 22:31:56','2026-11-01 22:22:26','2026-10-18 22:22:26','2026-10-18 22:31:56'),(25,1,'App\\Models\\User','prise-web','e398150b3bb2d1a59d0833d85e01620def8af6c16d7e28c9bb19b3336da03ce7','[\"*\"]','2026-10-18 22:57:35','2026-11-01 22:51:35','2026-10-18 22:51:35','2026-10-18 22:57:35'),(26,3,'App\\Models\\User','prise-web','151223ecd91abf815c6783b343a5581f56e2fe7470f4d436253c57b7b03aee05','[\"*\"]','2026-10-18 23:00:09','2026-11-01 22:54:42','2026-10-18 22:54:42','2026-10-18 23:00:09'),(27,1,'App\\Models\\User','prise-web','6d32b76fc2f911137d515dc3066071f9668fb830f569417009396b219d50396f','[\"*\"]','2026-10-19 07:46:37','2026-11-02 06:31:46','2026-10-19 06:31:46','2026-10-19 07:46:37'),(28,1,'App\\Models\\User','prise-web','55ce11181eea678c3a63f095fdb2a12adf8b8ee44667c24bb80b4e252e7ca681','[\"*\"]','2026-10-19 13:42:29','2026-11-02 13:09:57','2026-10-19 13:09:57','2026-10-19 13:42:29'),(30,1,'App\\Models\\User','prise-web','640b6d8479a1f3ebc4d0f59aa14e9b19bbdffae60fd0db6216eaa8c281e72a55','[\"*\"]','2026-10-22 15:42:21','2026-11-05 14:18:36','2026-10-22 14:18:36','2026-10-22 15:42:21'),(31,1,'App\\Models\\User','prise-web','8c7c7a8920ad4fc13058b607af44f99de559b3f5ab2b8eb794a21c49f58956cf','[\"*\"]','2026-10-27 09:52:09','2026-11-05 20:11:51','2026-10-22 20:11:51','2026-10-27 09:52:09'),(33,1,'App\\Models\\User','prise-web','8b36d12e1a32d3d0fbdd31d37ca9d99f05e6061e023551077857f11bfd3372bb','[\"*\"]','2026-10-28 13:00:52','2026-11-11 12:50:06','2026-10-28 12:50:06','2026-10-28 13:00:52');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `positions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `positions_project_name_unique` (`project_id`,`name`),
  CONSTRAINT `positions_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,1,'CN','COORDINATION NATIONALE',1,'2026-10-28 12:51:28','2026-10-28 12:51:28'),(2,1,'HNRAF','HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER',1,'2026-10-28 12:52:45','2026-10-28 12:53:23'),(3,1,'COMPTABLE','COMPTABLE',1,'2026-10-28 12:53:12','2026-10-28 12:53:12'),(4,1,'AC','ASSISTANT COMPTABLE',1,'2026-10-28 12:53:51','2026-10-28 12:53:51'),(5,1,'HCPM','HOMOLOGUE NATIONAL EN PASSATION DE MARCHES',1,'2026-10-28 12:54:25','2026-10-28 12:54:25'),(6,1,'APM','ASSISTANT EN PASSATION DES MARCHES',1,'2026-10-28 12:55:40','2026-10-28 12:55:40'),(7,1,'HNSE','HOMOLOGUE NATIONAL EN SUIVI-EVALUATION',1,'2026-10-28 12:59:35','2026-10-28 12:59:35'),(8,1,'CCI','CHEF DE CELLULE INFRASTRUCTURES (AEP)',1,'2026-10-28 13:00:52','2026-10-28 13:00:52');
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progress_entries`
--

DROP TABLE IF EXISTS `progress_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progress_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `contract_site_id` bigint unsigned DEFAULT NULL,
  `situation_date` date NOT NULL,
  `progress` decimal(6,2) NOT NULL,
  `realization_physical` text COLLATE utf8mb4_unicode_ci,
  `paid_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `observation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `progress_entries_contract_id_foreign` (`contract_id`),
  KEY `progress_entries_contract_site_id_situation_date_index` (`contract_site_id`,`situation_date`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progress_entries`
--

LOCK TABLES `progress_entries` WRITE;
/*!40000 ALTER TABLE `progress_entries` DISABLE KEYS */;
INSERT INTO `progress_entries` VALUES (1,1,4,'2026-09-30',78.00,'Un 1er forage terminé 6m3/h, 2ème forage terminé, débit 5,5 m3/h. CE de 100 m3: cuve et coupole achevées BF : réalisé 9 sur 12 prévues',0.00,'Conduites : 5237,4 m posées sur 3395 m prévues dans le contrat soit 1842,4 m de plus que prévu ce qui équivaut à 54 % de dépassement','2026-10-16 10:15:22','2026-10-16 10:42:05'),(2,1,1,'2026-09-30',39.00,'Réalisation d\'un premier forage négatif et d\'un deuxième forage productif, débit 8m3/h d\'après les essais CE',0.00,'Capacité du CE de 100 m3 à 60m3 travaux au niveau de la fouille terminée et pose de conduite : de 5118m sur 3340 prévue Rupture de stock en tuyau pour poursuivre la pose conduite','2026-10-16 10:41:49','2026-10-16 10:41:49'),(3,1,3,'2026-09-30',21.00,'Un forage de 10m3/h après les essais',0.00,'Retard sur l\'exécution du réseau et construction du CE  après deux mois de fin de forage, Attente approbation des plans','2026-10-16 10:45:06','2026-10-16 10:45:06'),(4,1,2,'2026-09-30',1.00,'Réalisation du 1er forage négatif. Prospection et étude en cours pour le captage des sources le plus proches',0.00,'Refaire les études pour verifier les données géophysique enfin de consolider les travaux de forage ou non. Si les etudes sont positives, l\'entreprise doit garantir un personnel qualifie pour les travaux, disposer des equipements adaptés. MCva refaire les études en presence de l\'hydrogeologue, lhydraulicien, maître forreur de l\'entreprise.','2026-10-16 11:04:49','2026-10-16 11:04:49'),(5,2,5,'2026-09-30',24.00,'Forage réalisé productif : 106 m, 16m3/h',0.00,'Le dossier technique a été approuvé pour le réseau sauf le dimensionnement en régime transitoire, attente du dossier de génie civile','2026-10-19 13:58:27','2026-10-19 14:01:45'),(6,2,7,'2026-09-30',28.00,'Après 2 forages loupés, réalisation d\'un 3ème forage réussi, débit 12 m3/h',0.00,'Le dossier technique pour le réseau a été approuvé et attente dossier de génie civile','2026-10-19 14:01:26','2026-10-19 14:01:26'),(7,2,6,'2026-09-30',19.00,'Forage déjà réalisé, débit 12 m3/h',0.00,'Dossier technique pour ce site en élaboration pour envoyer en MC','2026-10-19 14:04:46','2026-10-19 14:04:46');
/*!40000 ALTER TABLE `progress_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_phases`
--

DROP TABLE IF EXISTS `project_phases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_phases` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `number` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_current` tinyint(1) NOT NULL DEFAULT '0',
  `is_archived` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_phases_project_id_number_unique` (`project_id`,`number`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_phases`
--

LOCK TABLES `project_phases` WRITE;
/*!40000 ALTER TABLE `project_phases` DISABLE KEYS */;
INSERT INTO `project_phases` VALUES (1,1,2,'PRISE','Projet de Renforcement des Infranstructures Socio-Economiques dans la Zone Centre de la RDC',1,0,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(2,2,1,'PREDIRE','Programme Régional d\'Appui au Développement des Infranstructures et Valorisations de Ressources en Eau Transfrontalières entre la RCA et RDC',1,0,'2026-10-14 10:49:59','2026-10-14 10:49:59');
/*!40000 ALTER TABLE `project_phases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `projects_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'PRISE','Projet de Renforcement des Infrastructures Socio-Économiques dans la Zone Centre de la RDC','2026-10-14 10:49:59','2026-10-14 10:49:59'),(2,'PREDIRE','Programme Régional d’Appui au Développement des Infrastructures et de Valorisation des Ressources en Eau Transfrontalières entre la RCA et la RDC','2026-10-14 10:49:59','2026-10-14 10:49:59');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provinces`
--

DROP TABLE IF EXISTS `provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provinces` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provinces_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provinces`
--

LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;
INSERT INTO `provinces` VALUES (1,'Kinshasa','2026-10-14 10:19:49','2026-10-14 10:19:49'),(2,'Kongo Central','2026-10-14 10:19:49','2026-10-14 10:19:49'),(3,'Kwango','2026-10-14 10:19:49','2026-10-14 10:19:49'),(4,'Kwilu','2026-10-14 10:19:49','2026-10-14 10:19:49'),(5,'Mai-Ndombe','2026-10-14 10:19:49','2026-10-14 10:19:49'),(6,'Équateur','2026-10-14 10:19:49','2026-10-14 10:19:49'),(7,'Mongala','2026-10-14 10:19:49','2026-10-14 10:19:49'),(8,'Nord-Ubangi','2026-10-14 10:19:49','2026-10-14 10:19:49'),(9,'Sud-Ubangi','2026-10-14 10:19:49','2026-10-14 10:19:49'),(10,'Tshuapa','2026-10-14 10:19:49','2026-10-14 10:19:49'),(11,'Tshopo','2026-10-14 10:19:49','2026-10-14 10:19:49'),(12,'Bas-Uele','2026-10-14 10:19:49','2026-10-14 10:19:49'),(13,'Haut-Uele','2026-10-14 10:19:49','2026-10-14 10:19:49'),(14,'Ituri','2026-10-14 10:19:49','2026-10-14 10:19:49'),(15,'Nord-Kivu','2026-10-14 10:19:49','2026-10-14 10:19:49'),(16,'Sud-Kivu','2026-10-14 10:19:49','2026-10-14 10:19:49'),(17,'Maniema','2026-10-14 10:19:49','2026-10-14 10:19:49'),(18,'Tanganyika','2026-10-14 10:19:49','2026-10-14 10:19:49'),(19,'Haut-Lomami','2026-10-14 10:19:49','2026-10-14 10:19:49'),(20,'Lualaba','2026-10-14 10:19:49','2026-10-14 10:19:49'),(21,'Haut-Katanga','2026-10-14 10:19:49','2026-10-14 10:19:49'),(22,'Kasaï','2026-10-14 10:19:49','2026-10-14 10:19:49'),(23,'Kasaï Central','2026-10-14 10:19:49','2026-10-14 10:19:49'),(24,'Lomami','2026-10-14 10:19:49','2026-10-14 10:19:49'),(25,'Sankuru','2026-10-14 10:19:49','2026-10-14 10:19:49'),(26,'Kasaï Oriental','2026-10-14 10:19:49','2026-10-14 10:19:49');
/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smtp_settings`
--

DROP TABLE IF EXISTS `smtp_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smtp_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `host` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int unsigned NOT NULL DEFAULT '587',
  `sender_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text COLLATE utf8mb4_unicode_ci,
  `use_ssl` tinyint(1) NOT NULL DEFAULT '0',
  `recipient1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `smtp_settings_project_id_unique` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smtp_settings`
--

LOCK TABLES `smtp_settings` WRITE;
/*!40000 ALTER TABLE `smtp_settings` DISABLE KEYS */;
INSERT INTO `smtp_settings` VALUES (1,1,'smtp.gmail.com',587,'hermansimbaleva20@gmail.com','eyJpdiI6IkMwSS9ld0tWaUh0Y0FGZWcyK3hUTnc9PSIsInZhbHVlIjoiN3grN2Y3WVZudzRJNm0yRkNUUVZSNkl2b0pJL21zOVMxRmVWSURRa2E3VT0iLCJtYWMiOiJkYjhiOGI2Y2IxMWI0MjIwZjk5Yjk4NDIwMjg3NjNiZTdkN2IyYjNmZGYwZDU1Nzk2M2ExY2E4YzNhNmU4Y2YzIiwidGFnIjoiIn0=',1,'ghostimbaleva@gmail.com','hermaimbaleva@gmail.com','hermansimbaleva20@gmail.com','hemansimbaleva@gmail.com','2026-10-14 10:49:59','2026-10-15 13:54:15'),(2,2,'smtp.gmail.com',587,'hermansimbaleva20@gmail.com','dcqgsanlpbfkhncc\r\n',0,NULL,NULL,NULL,NULL,'2026-10-14 10:49:59','2026-10-14 10:49:59');
/*!40000 ALTER TABLE `smtp_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_articles`
--

DROP TABLE IF EXISTS `stock_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_articles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `number` int unsigned NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_price` decimal(18,2) NOT NULL DEFAULT '0.00',
  `alert_threshold` decimal(14,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_articles_project_number_unique` (`project_id`,`number`),
  UNIQUE KEY `stock_articles_project_designation_unique` (`project_id`,`designation`),
  CONSTRAINT `stock_articles_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_articles`
--

LOCK TABLES `stock_articles` WRITE;
/*!40000 ALTER TABLE `stock_articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `organizational_unit_id` bigint unsigned NOT NULL,
  `stock_article_id` bigint unsigned NOT NULL,
  `movement_date` date NOT NULL,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(14,2) NOT NULL,
  `origin_destination` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observation` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancel_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `stock_movements_stock_article_id_foreign` (`stock_article_id`),
  KEY `stock_movements_card_idx` (`project_id`,`organizational_unit_id`,`stock_article_id`,`movement_date`),
  CONSTRAINT `stock_movements_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_movements_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_stock_article_id_foreign` FOREIGN KEY (`stock_article_id`) REFERENCES `stock_articles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_reset_tokens`
--

DROP TABLE IF EXISTS `user_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_reset_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `token_hash` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_reset_tokens_project_id_index` (`project_id`),
  KEY `user_reset_tokens_user_id_index` (`user_id`),
  KEY `user_reset_tokens_token_hash_index` (`token_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_reset_tokens`
--

LOCK TABLES `user_reset_tokens` WRITE;
/*!40000 ALTER TABLE `user_reset_tokens` DISABLE KEYS */;
INSERT INTO `user_reset_tokens` VALUES (1,1,1,'21a114ed7f7aa8a72a44e6cec28462ae8df8fcd14ac9f36576c38847fe5965e4','2026-10-15 10:52:43','2026-10-14 12:44:47','2026-10-14 10:52:43','2026-10-14 10:52:43'),(2,2,2,'e1b00f9a510a4299a25de13bae99e9babc9dbe3f5127ad99d7c66406849ed3e3','2026-10-15 10:52:43',NULL,'2026-10-14 10:52:43','2026-10-14 10:52:43'),(3,1,1,'7c39fc39bb75a4ffa2e076e2507414cf171159deabc0d766b0eadf6cbf17bfac','2026-10-15 12:38:27','2026-10-14 12:44:47','2026-10-14 12:38:27','2026-10-14 12:38:27'),(4,2,2,'8ba3622dfe208813a824acba531f55ea44ce5bc16da1686b3509e7e906567685','2026-10-15 12:38:27',NULL,'2026-10-14 12:38:27','2026-10-14 12:38:27'),(5,1,1,'9a5ebe64145c39b6eccdb9434c69ed1d02061c7c8b674f37debab1ab65ebea72','2026-10-14 13:14:47',NULL,'2026-10-14 12:44:47','2026-10-14 12:44:47'),(6,1,1,'3600eb2ce4281bf24e637cbb5cd2cb8e7070fe94b13949095c15ba0f4a99aae2','2026-10-15 13:19:27','2026-10-14 13:20:04','2026-10-14 13:19:27','2026-10-14 13:20:04'),(7,2,2,'325148eb8e48b3245f5e97726ccaa9d8b8aa7f34d8d27eb4067c36c858697d98','2026-10-15 13:19:27','2026-10-14 13:22:40','2026-10-14 13:19:27','2026-10-14 13:22:40');
/*!40000 ALTER TABLE `user_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned DEFAULT NULL,
  `full_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `function` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UTILISATEUR',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `can_view_archives` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_guarantees` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `password_hash` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_salt` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_pending` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_settings` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_users` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete_contracts` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_contracts` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_companies` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_progress` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_payments` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_reports` tinyint(1) NOT NULL DEFAULT '1',
  `can_view_alerts` tinyint(1) NOT NULL DEFAULT '1',
  `can_view_situation` tinyint(1) NOT NULL DEFAULT '1',
  `is_super_admin` tinyint(1) NOT NULL DEFAULT '0',
  `failed_login_count` int unsigned NOT NULL DEFAULT '0',
  `lockout_end` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `organizational_unit_id` bigint unsigned DEFAULT NULL,
  `position_id` bigint unsigned DEFAULT NULL,
  `can_view_stock` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_stock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_project_unique` (`email`,`project_id`),
  KEY `users_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `users_position_id_foreign` (`position_id`),
  CONSTRAINT `users_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'Hermans imbaleva','hermansimbaleva20@gmail.com','$2y$12$ZDFW/BE.THj8BtgmfCfdLeaqccTX5vKkLt.eI06ffx8BpkdO5RjuS','Super-administrateur','Stagiaire en suivi et evaluation','ADMINISTRATEUR',1,1,1,NULL,'2026-10-14 10:52:43','2026-10-28 12:50:06',NULL,NULL,0,1,1,1,1,1,1,1,1,1,1,1,0,NULL,'2026-10-28 12:50:06',NULL,NULL,0,0),(2,2,'Hermans imbaleva','hermansimbaleva20@gmail.com','$2y$12$oR8mh/6lxLFaPX4QwenepeEfz9X0jRC56HCUz9khoI/OnnL6PE.Zu','Super-administrateur','Stagiaire en suivi et evaluation','ADMINISTRATEUR',1,1,1,NULL,'2026-10-14 10:52:43','2026-10-15 09:40:50',NULL,NULL,0,1,1,1,1,1,1,1,1,1,1,1,0,NULL,'2026-10-15 09:40:50',NULL,NULL,0,0),(3,1,'Jorcelin MIKADO','jorcelinmikado@gmail.com','$2y$12$bgjlILP8X.p0Du69DrS.7OzZD6PTOst6b4hV/fczmQHiFlApT3d76','Utilisateur','Stagiaire dans la cellule financière','UTILISATEUR',1,0,1,NULL,'2026-10-18 22:53:27','2026-10-22 15:20:47',NULL,NULL,0,0,0,0,1,1,0,0,1,0,0,0,0,NULL,'2026-10-18 22:54:42',NULL,NULL,0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_types`
--

DROP TABLE IF EXISTS `work_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_types_unique` (`project_id`,`category`,`name`),
  KEY `work_types_project_id_index` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_types`
--

LOCK TABLES `work_types` WRITE;
/*!40000 ALTER TABLE `work_types` DISABLE KEYS */;
INSERT INTO `work_types` VALUES (1,1,'TRAVAUX','Système d’AEP',0,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(2,1,'TRAVAUX','École primaire',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(3,1,'TRAVAUX','Centre de santé',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(4,1,'TRAVAUX','Latrine publique',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(5,1,'TRAVAUX','Espace à vivre',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(6,2,'TRAVAUX','Système d’AEP',0,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(7,2,'TRAVAUX','École primaire',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(8,2,'TRAVAUX','Centre de santé',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(9,2,'TRAVAUX','Latrine publique',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(10,2,'TRAVAUX','Espace à vivre',1,'2026-10-14 10:49:59','2026-10-14 10:49:59');
/*!40000 ALTER TABLE `work_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'prise_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-28 15:06:28
