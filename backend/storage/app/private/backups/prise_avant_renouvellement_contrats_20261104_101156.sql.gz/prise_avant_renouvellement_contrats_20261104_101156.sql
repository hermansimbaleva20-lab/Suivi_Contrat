-- MySQL dump 10.13  Distrib 8.4.7, for Win64 (x86_64)
--
-- Host: localhost    Database: prise_db
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ai_settings`
--

DROP TABLE IF EXISTS `ai_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `provider` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ANTHROPIC',
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'claude-sonnet-5-5',
  `endpoint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_key` text COLLATE utf8mb4_unicode_ci,
  `feature_comments` tinyint(1) NOT NULL DEFAULT '0',
  `feature_alerts` tinyint(1) NOT NULL DEFAULT '0',
  `feature_extraction` tinyint(1) NOT NULL DEFAULT '0',
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ai_settings_project_id_unique` (`project_id`),
  CONSTRAINT `ai_settings_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_settings`
--

LOCK TABLES `ai_settings` WRITE;
/*!40000 ALTER TABLE `ai_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_dispatches`
--

DROP TABLE IF EXISTS `alert_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_dispatches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `category` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alert_key` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipients` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trigger` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `contract_id` bigint unsigned DEFAULT NULL,
  `performance_guarantee_id` bigint unsigned DEFAULT NULL,
  `guarantee_number` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `alert_dispatches_key_idx` (`project_id`,`alert_key`,`status`),
  KEY `alert_dispatches_contract_idx` (`project_id`,`contract_id`),
  CONSTRAINT `alert_dispatches_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_dispatches`
--

LOCK TABLES `alert_dispatches` WRITE;
/*!40000 ALTER TABLE `alert_dispatches` DISABLE KEYS */;
INSERT INTO `alert_dispatches` VALUES (1,1,'DECOMPTE','DECOMPTE:5','DECOMPTE N°2 du contrat 068 : 345 677,00 USD, présenté le 02/11/2026, en attente de validation.','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 08:00:22','2026-11-03 08:00:22',NULL,NULL,NULL,NULL,NULL),(2,1,'CHARROI','CHARROI:1:MAINTENANCE','TOYOTA FORTUNER 1083 IT 23 (Coordination nationale) : Entretien dû : 38 285 km depuis le dernier entretien (échéance tous les 3000 km).','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 08:00:29','2026-11-03 08:00:29',NULL,NULL,NULL,NULL,NULL),(3,1,'CHARROI','CHARROI:1:FUEL','TOYOTA FORTUNER 1083 IT 23 (Coordination nationale) : Réservoir bas : environ 2 L estimés (alerte à 30 L). Lancez la réquisition de carburant.','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 08:00:29','2026-11-03 08:00:29',NULL,NULL,NULL,NULL,NULL),(4,1,'CHARROI','CHARROI:1:INSURANCE','TOYOTA FORTUNER 1083 IT 23 (Coordination nationale) : Aucune assurance enregistrée.','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 08:00:29','2026-11-03 08:00:29',NULL,NULL,NULL,NULL,NULL),(5,1,'GARANTIE','GARANTIE:2:2025-06-12:2026-07-12:R','[PRISE II] Garantie de bonne exécution n° RE16472 — contrat n° 069 — alerte de retard','ghostimbaleva@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com.','AUTO',NULL,'2026-11-03 08:00:34','2026-11-03 08:00:34',2,2,'RE16472','RETARD','Cher partenaire,\n\nNous constatons que votre garantie de bonne exécution n° RE16472 relative au contrat n° 069 est arrivée à échéance depuis le 12/07/2026.\n\nÀ ce jour, aucune prolongation ou preuve de renouvellement de cette garantie n\'a été enregistrée dans notre système.\n\nNous vous demandons de prendre, sans délai, toutes les dispositions nécessaires pour procéder à sa régularisation et nous transmettre le justificatif de prolongation ou de renouvellement dans les meilleurs délais.\n\nNous attirons votre attention sur l\'importance du maintien de la garantie de bonne exécution pendant toute la période requise du contrat.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(6,1,'GARANTIE','GARANTIE:5:2025-01-02:2026-09-04:R','[PRISE II] Garantie de bonne exécution n° RB-245-12 — contrat n° 072 — alerte de retard','germainenkamba@gmail.com','ENVOYE','Message envoyé à germainenkamba@gmail.com.','AUTO',NULL,'2026-11-03 08:00:40','2026-11-03 08:00:40',5,5,'RB-245-12','RETARD','Cher partenaire,\n\nNous constatons que votre garantie de bonne exécution n° RB-245-12 relative au contrat n° 072 est arrivée à échéance depuis le 04/09/2026.\n\nÀ ce jour, aucune prolongation ou preuve de renouvellement de cette garantie n\'a été enregistrée dans notre système.\n\nNous vous demandons de prendre, sans délai, toutes les dispositions nécessaires pour procéder à sa régularisation et nous transmettre le justificatif de prolongation ou de renouvellement dans les meilleurs délais.\n\nNous attirons votre attention sur l\'importance du maintien de la garantie de bonne exécution pendant toute la période requise du contrat.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(7,1,'GARANTIE','GARANTIE:6:2025-03-26:2027-03-26:V','[PRISE II] Garantie de bonne exécution n° RB-906-342 — contrat n° 073 — alerte de vigilance','hermaimbaleva@gmail.com','ENVOYE','Message envoyé à hermaimbaleva@gmail.com.','AUTO',NULL,'2026-11-03 08:00:45','2026-11-03 08:00:45',6,6,'RB-906-342','VIGILANCE','Cher partenaire,\n\nNous vous rappelons que votre garantie de bonne exécution n° RB-906-342 relative au contrat n° 073 arrive à échéance le 26/03/2027.\n\nAu regard de l\'état d\'avancement de la période contractuelle, nous vous invitons à prendre, dans les meilleurs délais, les dispositions nécessaires en vue de la prolongation ou du renouvellement de ladite garantie, afin d\'assurer la continuité de la couverture financière et la poursuite normale des activités du projet.\n\nNous vous remercions de bien vouloir prendre les mesures appropriées et de nous transmettre les justificatifs correspondants.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(8,1,'GARANTIE','GARANTIE:1:2025-04-03:2027-04-03:V','[PRISE II] Garantie de bonne exécution n° RE-675-400 — contrat n° 068 — alerte de vigilance','germainenkamba@gmail.com','ENVOYE','Message envoyé à germainenkamba@gmail.com.','AUTO',NULL,'2026-11-03 08:00:49','2026-11-03 08:00:49',1,1,'RE-675-400','VIGILANCE','Cher partenaire,\n\nNous vous rappelons que votre garantie de bonne exécution n° RE-675-400 relative au contrat n° 068 arrive à échéance le 03/04/2027.\n\nAu regard de l\'état d\'avancement de la période contractuelle, nous vous invitons à prendre, dans les meilleurs délais, les dispositions nécessaires en vue de la prolongation ou du renouvellement de ladite garantie, afin d\'assurer la continuité de la couverture financière et la poursuite normale des activités du projet.\n\nNous vous remercions de bien vouloir prendre les mesures appropriées et de nous transmettre les justificatifs correspondants.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(9,1,'GARANTIE','GARANTIE:4:2025-04-03:2027-04-03:V','[PRISE II] Garantie de bonne exécution n° NT-649-126 — contrat n° 071 — alerte de vigilance','germainenkamba@gmail.com','ENVOYE','Message envoyé à germainenkamba@gmail.com.','AUTO',NULL,'2026-11-03 08:00:56','2026-11-03 08:00:56',4,4,'NT-649-126','VIGILANCE','Cher partenaire,\n\nNous vous rappelons que votre garantie de bonne exécution n° NT-649-126 relative au contrat n° 071 arrive à échéance le 03/04/2027.\n\nAu regard de l\'état d\'avancement de la période contractuelle, nous vous invitons à prendre, dans les meilleurs délais, les dispositions nécessaires en vue de la prolongation ou du renouvellement de ladite garantie, afin d\'assurer la continuité de la couverture financière et la poursuite normale des activités du projet.\n\nNous vous remercions de bien vouloir prendre les mesures appropriées et de nous transmettre les justificatifs correspondants.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(10,1,'GARANTIE','PERSONNEL:GARANTIE:2:2025-06-12:2026-07-12','[PRISE II] Pour attention — garantie n° RE16472 du contrat n° 069 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 08:01:02','2026-11-03 08:01:02',2,2,'RE16472','PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur la garantie de bonne exécution n° RE16472 du contrat n° 069 (SAGEC-KAT, banque Equity-BCDC), en situation de retard : 128,9 % de la période consommés, échéance le 12/07/2026.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(11,1,'GARANTIE','PERSONNEL:GARANTIE:5:2025-01-02:2026-09-04','[PRISE II] Pour attention — garantie n° RB-245-12 du contrat n° 072 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 08:01:09','2026-11-03 08:01:09',5,5,'RB-245-12','PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur la garantie de bonne exécution n° RB-245-12 du contrat n° 072 (SZTC, banque SOFIBANK), en situation de retard : 109,8 % de la période consommés, échéance le 04/09/2026.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(12,1,'GARANTIE','PERSONNEL:GARANTIE:6:2025-03-26:2027-03-26','[PRISE II] Pour attention — garantie n° RB-906-342 du contrat n° 073 (vigilance)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 08:01:15','2026-11-03 08:01:15',6,6,'RB-906-342','PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur la garantie de bonne exécution n° RB-906-342 du contrat n° 073 (CGC, banque EQUITY-BCDC), en situation de vigilance : 80,4 % de la période consommés, échéance le 26/03/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(13,1,'GARANTIE','PERSONNEL:GARANTIE:1:2025-04-03:2027-04-03','[PRISE II] Pour attention — garantie n° RE-675-400 du contrat n° 068 (vigilance)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 08:01:20','2026-11-03 08:01:20',1,1,'RE-675-400','PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur la garantie de bonne exécution n° RE-675-400 du contrat n° 068 (SZTC, banque RAWBANK), en situation de vigilance : 79,3 % de la période consommés, échéance le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(14,1,'GARANTIE','PERSONNEL:GARANTIE:4:2025-04-03:2027-04-03','[PRISE II] Pour attention — garantie n° NT-649-126 du contrat n° 071 (vigilance)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ECHEC','Échec de l’envoi : Connection to \"smtp.gmail.com:587\" timed out.','AUTO',NULL,'2026-11-03 08:01:48','2026-11-03 08:01:48',4,4,'NT-649-126','PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur la garantie de bonne exécution n° NT-649-126 du contrat n° 071 (SZTC, banque SOLIDAIRE), en situation de vigilance : 79,3 % de la période consommés, échéance le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(15,1,'RETARD','PERSONNEL:CONTRAT:1','[PRISE II] Pour attention — contrat n° 068 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-03 08:01:48','2026-11-03 08:01:48',1,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 068 (SZTC), en situation de retard : avancement physique de 34,8 % pour 79,3 % du délai consommé, fin prévue le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(16,1,'RETARD','PERSONNEL:CONTRAT:2','[PRISE II] Pour attention — contrat n° 069 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-03 08:01:48','2026-11-03 08:01:48',2,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 069 (SAGEC-KAT), en situation de retard : avancement physique de 23,7 % pour 70,6 % du délai consommé, fin prévue le 06/06/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(17,1,'RETARD','PERSONNEL:CONTRAT:3','[PRISE II] Pour attention — contrat n° 070 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-03 08:01:48','2026-11-03 08:01:48',3,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 070 (SAGEC-KAT), en situation de retard : avancement physique de 0,0 % pour 70,6 % du délai consommé, fin prévue le 06/06/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(18,1,'RETARD','PERSONNEL:CONTRAT:4','[PRISE II] Pour attention — contrat n° 071 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-03 08:01:48','2026-11-03 08:01:48',4,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 071 (SZTC), en situation de retard : avancement physique de 0,0 % pour 79,3 % du délai consommé, fin prévue le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(19,1,'RETARD','PERSONNEL:CONTRAT:5','[PRISE II] Pour attention — contrat n° 072 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-03 08:01:48','2026-11-03 08:01:48',5,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 072 (SZTC), en situation de retard : avancement physique de 0,0 % pour 79,3 % du délai consommé, fin prévue le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(20,1,'RETARD','PERSONNEL:CONTRAT:6','[PRISE II] Pour attention — contrat n° 073 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-03 08:01:48','2026-11-03 08:01:48',6,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 073 (CGC), en situation de retard : avancement physique de 0,0 % pour 80,4 % du délai consommé, fin prévue le 26/03/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(21,1,'GARANTIE','PERSONNEL:GARANTIE:4:2025-04-03:2027-04-03','[PRISE II] Pour attention — garantie n° NT-649-126 du contrat n° 071 (vigilance)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 09:00:08','2026-11-03 09:00:08',4,4,'NT-649-126','PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur la garantie de bonne exécution n° NT-649-126 du contrat n° 071 (SZTC, banque SOLIDAIRE), en situation de vigilance : 79,3 % de la période consommés, échéance le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\n\nCoordination du projet PRISE II.'),(22,1,'RETARD','PERSONNEL:CONTRAT:1','[PRISE II] Pour attention — contrat n° 068 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 09:00:17','2026-11-03 09:00:17',1,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 068 (SZTC), en situation de retard : avancement physique de 34,8 % pour 79,3 % du délai consommé, fin prévue le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(23,1,'RETARD','PERSONNEL:CONTRAT:2','[PRISE II] Pour attention — contrat n° 069 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 09:00:23','2026-11-03 09:00:23',2,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 069 (SAGEC-KAT), en situation de retard : avancement physique de 23,7 % pour 70,6 % du délai consommé, fin prévue le 06/06/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(24,1,'RETARD','PERSONNEL:CONTRAT:3','[PRISE II] Pour attention — contrat n° 070 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 09:00:29','2026-11-03 09:00:29',3,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 070 (SAGEC-KAT), en situation de retard : avancement physique de 0,0 % pour 70,6 % du délai consommé, fin prévue le 06/06/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(25,1,'RETARD','PERSONNEL:CONTRAT:4','[PRISE II] Pour attention — contrat n° 071 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 09:00:38','2026-11-03 09:00:38',4,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 071 (SZTC), en situation de retard : avancement physique de 0,0 % pour 79,3 % du délai consommé, fin prévue le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(26,1,'RETARD','PERSONNEL:CONTRAT:5','[PRISE II] Pour attention — contrat n° 072 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 09:00:47','2026-11-03 09:00:47',5,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 072 (SZTC), en situation de retard : avancement physique de 0,0 % pour 79,3 % du délai consommé, fin prévue le 03/04/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(27,1,'RETARD','PERSONNEL:CONTRAT:6','[PRISE II] Pour attention — contrat n° 073 (retard)','ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','AUTO',NULL,'2026-11-03 09:00:54','2026-11-03 09:00:54',6,NULL,NULL,'PERSONNEL','Chers collègues,\n\nNous attirons votre attention sur le contrat n° 073 (CGC), en situation de retard : avancement physique de 0,0 % pour 80,4 % du délai consommé, fin prévue le 26/03/2027.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi PRISE II.'),(28,1,'GARANTIE','GARANTIE:2:2025-06-12:2026-07-12:R','[PRISE II] Garantie de bonne exécution n° RE16472 — contrat n° 069 — alerte de retard','ghostimbaleva@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-04 07:41:43','2026-11-04 07:41:43',2,2,'RE16472','RETARD','Cher partenaire,\n\nNous constatons que votre garantie de bonne exécution n° RE16472 relative au contrat n° 069 est arrivée à échéance depuis le 12/07/2026.\n\nÀ ce jour, aucune prolongation ou preuve de renouvellement de cette garantie n\'a été enregistrée dans notre système.\n\nNous vous demandons de prendre, sans délai, toutes les dispositions nécessaires pour procéder à sa régularisation et nous transmettre le justificatif de prolongation ou de renouvellement dans les meilleurs délais.\n\nNous attirons votre attention sur l\'importance du maintien de la garantie de bonne exécution pendant toute la période requise du contrat.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(29,1,'GARANTIE','GARANTIE:5:2025-01-02:2026-09-04:R','[PRISE II] Garantie de bonne exécution n° RB-245-12 — contrat n° 072 — alerte de retard','germainenkamba@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-04 07:41:43','2026-11-04 07:41:43',5,5,'RB-245-12','RETARD','Cher partenaire,\n\nNous constatons que votre garantie de bonne exécution n° RB-245-12 relative au contrat n° 072 est arrivée à échéance depuis le 04/09/2026.\n\nÀ ce jour, aucune prolongation ou preuve de renouvellement de cette garantie n\'a été enregistrée dans notre système.\n\nNous vous demandons de prendre, sans délai, toutes les dispositions nécessaires pour procéder à sa régularisation et nous transmettre le justificatif de prolongation ou de renouvellement dans les meilleurs délais.\n\nNous attirons votre attention sur l\'importance du maintien de la garantie de bonne exécution pendant toute la période requise du contrat.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(30,1,'CONTRAT','CONTRAT:1:RETARD','[PRISE II] Contrat n° 068 — alerte de retard','germainenkamba@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-04 07:41:43','2026-11-04 07:41:43',1,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 068 : l\'avancement physique est de 34,8 % alors que 79,5 % du délai contractuel est consommé (fin prévue le 03/04/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(31,1,'CONTRAT','CONTRAT:2:RETARD','[PRISE II] Contrat n° 069 — alerte de retard','ghostimbaleva@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-04 07:41:43','2026-11-04 07:41:43',2,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 069 : l\'avancement physique est de 23,7 % alors que 70,7 % du délai contractuel est consommé (fin prévue le 06/06/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(32,1,'CONTRAT','CONTRAT:3:RETARD','[PRISE II] Contrat n° 070 — alerte de retard','ghostimbaleva@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-04 07:41:43','2026-11-04 07:41:43',3,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 070 : l\'avancement physique est de 0,0 % alors que 70,7 % du délai contractuel est consommé (fin prévue le 06/06/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(33,1,'CONTRAT','CONTRAT:4:RETARD','[PRISE II] Contrat n° 071 — alerte de retard','germainenkamba@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-04 07:41:43','2026-11-04 07:41:43',4,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 071 : l\'avancement physique est de 0,0 % alors que 79,5 % du délai contractuel est consommé (fin prévue le 03/04/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(34,1,'CONTRAT','CONTRAT:5:RETARD','[PRISE II] Contrat n° 072 — alerte de retard','germainenkamba@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-04 07:41:43','2026-11-04 07:41:43',5,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 072 : l\'avancement physique est de 0,0 % alors que 79,5 % du délai contractuel est consommé (fin prévue le 03/04/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(35,1,'CONTRAT','CONTRAT:6:RETARD','[PRISE II] Contrat n° 073 — alerte de retard','hermaimbaleva@gmail.com','ECHEC','Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','AUTO',NULL,'2026-11-04 07:41:43','2026-11-04 07:41:43',6,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 073 : l\'avancement physique est de 0,0 % alors que 80,6 % du délai contractuel est consommé (fin prévue le 26/03/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(36,1,'GARANTIE','GARANTIE:2:2025-06-12:2026-07-12:R','[PRISE II] Garantie de bonne exécution n° RE16472 — contrat n° 069 — alerte de retard','ghostimbaleva@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com.','AUTO',NULL,'2026-11-04 08:41:51','2026-11-04 08:41:51',2,2,'RE16472','RETARD','Cher partenaire,\n\nNous constatons que votre garantie de bonne exécution n° RE16472 relative au contrat n° 069 est arrivée à échéance depuis le 12/07/2026.\n\nÀ ce jour, aucune prolongation ou preuve de renouvellement de cette garantie n\'a été enregistrée dans notre système.\n\nNous vous demandons de prendre, sans délai, toutes les dispositions nécessaires pour procéder à sa régularisation et nous transmettre le justificatif de prolongation ou de renouvellement dans les meilleurs délais.\n\nNous attirons votre attention sur l\'importance du maintien de la garantie de bonne exécution pendant toute la période requise du contrat.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(37,1,'GARANTIE','GARANTIE:5:2025-01-02:2026-09-04:R','[PRISE II] Garantie de bonne exécution n° RB-245-12 — contrat n° 072 — alerte de retard','germainenkamba@gmail.com','ENVOYE','Message envoyé à germainenkamba@gmail.com.','AUTO',NULL,'2026-11-04 08:41:56','2026-11-04 08:41:56',5,5,'RB-245-12','RETARD','Cher partenaire,\n\nNous constatons que votre garantie de bonne exécution n° RB-245-12 relative au contrat n° 072 est arrivée à échéance depuis le 04/09/2026.\n\nÀ ce jour, aucune prolongation ou preuve de renouvellement de cette garantie n\'a été enregistrée dans notre système.\n\nNous vous demandons de prendre, sans délai, toutes les dispositions nécessaires pour procéder à sa régularisation et nous transmettre le justificatif de prolongation ou de renouvellement dans les meilleurs délais.\n\nNous attirons votre attention sur l\'importance du maintien de la garantie de bonne exécution pendant toute la période requise du contrat.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(38,1,'CONTRAT','CONTRAT:1:RETARD','[PRISE II] Contrat n° 068 — alerte de retard','germainenkamba@gmail.com','ENVOYE','Message envoyé à germainenkamba@gmail.com.','AUTO',NULL,'2026-11-04 08:42:02','2026-11-04 08:42:02',1,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 068 : l\'avancement physique est de 34,8 % alors que 79,5 % du délai contractuel est consommé (fin prévue le 03/04/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(39,1,'CONTRAT','CONTRAT:2:RETARD','[PRISE II] Contrat n° 069 — alerte de retard','ghostimbaleva@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com.','AUTO',NULL,'2026-11-04 08:42:09','2026-11-04 08:42:09',2,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 069 : l\'avancement physique est de 23,7 % alors que 70,7 % du délai contractuel est consommé (fin prévue le 06/06/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(40,1,'CONTRAT','CONTRAT:3:RETARD','[PRISE II] Contrat n° 070 — alerte de retard','ghostimbaleva@gmail.com','ENVOYE','Message envoyé à ghostimbaleva@gmail.com.','AUTO',NULL,'2026-11-04 08:42:15','2026-11-04 08:42:15',3,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 070 : l\'avancement physique est de 0,0 % alors que 70,7 % du délai contractuel est consommé (fin prévue le 06/06/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(41,1,'CONTRAT','CONTRAT:4:RETARD','[PRISE II] Contrat n° 071 — alerte de retard','germainenkamba@gmail.com','ENVOYE','Message envoyé à germainenkamba@gmail.com.','AUTO',NULL,'2026-11-04 08:42:22','2026-11-04 08:42:22',4,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 071 : l\'avancement physique est de 0,0 % alors que 79,5 % du délai contractuel est consommé (fin prévue le 03/04/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(42,1,'CONTRAT','CONTRAT:5:RETARD','[PRISE II] Contrat n° 072 — alerte de retard','germainenkamba@gmail.com','ENVOYE','Message envoyé à germainenkamba@gmail.com.','AUTO',NULL,'2026-11-04 08:42:27','2026-11-04 08:42:27',5,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 072 : l\'avancement physique est de 0,0 % alors que 79,5 % du délai contractuel est consommé (fin prévue le 03/04/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II'),(43,1,'CONTRAT','CONTRAT:6:RETARD','[PRISE II] Contrat n° 073 — alerte de retard','hermaimbaleva@gmail.com','ENVOYE','Message envoyé à hermaimbaleva@gmail.com.','AUTO',NULL,'2026-11-04 08:42:32','2026-11-04 08:42:32',6,NULL,NULL,'RETARD','Cher partenaire,\n\nNous constatons un retard dans l\'exécution du contrat n° 073 : l\'avancement physique est de 0,0 % alors que 80,6 % du délai contractuel est consommé (fin prévue le 26/03/2027).\n\nNous vous demandons de prendre, sans délai, les mesures correctives nécessaires et de nous transmettre un planning de rattrapage.\n\nNous comptons sur votre diligence.\n\nCordialement.\n\nLa Coordination nationale du projet PRISE II');
/*!40000 ALTER TABLE `alert_dispatches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_recipients`
--

DROP TABLE IF EXISTS `alert_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_recipients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organizational_unit_id` bigint unsigned DEFAULT NULL,
  `categories` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `position_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alert_recipients_email_unique` (`project_id`,`email`),
  KEY `alert_recipients_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `alert_recipients_position_id_foreign` (`position_id`),
  CONSTRAINT `alert_recipients_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE SET NULL,
  CONSTRAINT `alert_recipients_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `alert_recipients_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_recipients`
--

LOCK TABLES `alert_recipients` WRITE;
/*!40000 ALTER TABLE `alert_recipients` DISABLE KEYS */;
INSERT INTO `alert_recipients` VALUES (1,1,'ghostimbaleva@gmail.com',NULL,NULL,'RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE',1,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(2,1,'hermaimbaleva@gmail.com',NULL,NULL,'RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE',1,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(3,1,'hermansimbaleva20@gmail.com','Hermans IMBALEVA',NULL,'RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE',1,'2026-10-29 06:11:37','2026-11-03 08:47:08',7),(5,1,'hemaimbaleva@gmail.com',NULL,NULL,'RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE',1,'2026-11-02 14:41:31','2026-11-02 14:41:31',NULL),(6,2,'germainenkamba@gmail.com',NULL,NULL,'RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE',1,'2026-11-03 07:19:22','2026-11-03 07:19:22',NULL),(7,2,'hermaimbaleva@gmail.com',NULL,NULL,'RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE',1,'2026-11-03 07:20:06','2026-11-03 07:20:06',NULL);
/*!40000 ALTER TABLE `alert_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_rules`
--

DROP TABLE IF EXISTS `alert_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_rules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `category` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `interval_days` smallint unsigned NOT NULL DEFAULT '7',
  `max_sends` smallint unsigned NOT NULL DEFAULT '3',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `levels` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alert_rules_category_unique` (`project_id`,`category`),
  CONSTRAINT `alert_rules_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_rules`
--

LOCK TABLES `alert_rules` WRITE;
/*!40000 ALTER TABLE `alert_rules` DISABLE KEYS */;
INSERT INTO `alert_rules` VALUES (1,2,'RETARD',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(2,2,'GARANTIE',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(3,2,'DECOMPTE',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(4,2,'STOCK',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(5,2,'CHARROI',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(6,2,'GROUPE',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(7,1,'RETARD',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(8,1,'GARANTIE',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(9,1,'DECOMPTE',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(10,1,'STOCK',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(11,1,'CHARROI',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL),(12,1,'GROUPE',1,7,3,'2026-10-29 06:11:37','2026-10-29 06:11:37',NULL);
/*!40000 ALTER TABLE `alert_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_templates`
--

DROP TABLE IF EXISTS `alert_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alert_templates_code_unique` (`project_id`,`code`),
  CONSTRAINT `alert_templates_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_templates`
--

LOCK TABLES `alert_templates` WRITE;
/*!40000 ALTER TABLE `alert_templates` DISABLE KEYS */;
INSERT INTO `alert_templates` VALUES (1,1,'GARANTIE_PERSONNEL','[{projet}] Pour attention — garantie n° {numero_garantie} du contrat n° {contrat} ({niveau})','Chers collègues,\n\nNous attirons votre attention sur la garantie de bonne exécution n° {numero_garantie} du contrat n° {contrat} ({entreprise}, banque {banque}), en situation de {niveau} : {jours_consommes} de la période consommés, échéance le {echeance}.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\n\nCoordination du projet {projet}.',1,'2026-11-03 08:24:49','2026-11-03 08:24:49'),(3,1,'DECOMPTE_RAPPEL','[{projet}] Rappel — {decompte} du contrat n° {contrat} à valider','Bonjour,\n\nLe {decompte} du contrat n° {contrat} ({entreprise}), d\'un montant de {montant} USD, vous a été transmis le {transmis_le} par {saisi_par} et attend toujours votre décision.\n\nMerci de le valider ou de le rejeter dans l\'application de suivi : {lien}\n\nCe rappel vous est envoyé chaque jour tant que le décompte n\'a pas été traité.\n\nCoordination du projet {projet}',1,'2026-11-03 09:05:10','2026-11-03 09:05:10'),(4,1,'CONTRAT_PERSONNEL','[{projet}] Pour attention — contrat n° {contrat} ({niveau})','Chers collègues,\n\nNous attirons votre attention sur le contrat n° {contrat} ({entreprise}), en situation de {niveau} : avancement physique de {avancement} pour {jours_consommes} du délai consommé, fin prévue le {date_fin}.\n\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\n\nCoordination du projet {projet}.',1,'2026-11-03 09:06:49','2026-11-03 09:06:49');
/*!40000 ALTER TABLE `alert_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alerts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `contract_id` bigint unsigned DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `alerts_project_id_foreign` (`project_id`),
  KEY `alerts_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `machine_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `organizational_unit_id` bigint unsigned DEFAULT NULL,
  `old_values` longtext COLLATE utf8mb4_unicode_ci,
  `new_values` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  KEY `audit_logs_action_index` (`action`),
  KEY `audit_logs_project_id_index` (`project_id`),
  KEY `audit_logs_organizational_unit_id_index` (`organizational_unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=298 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,1,'DEMANDE_REINITIALISATION','User','1','Lien non envoyé à hermansimbaleva20@gmail.com : Paramètres SMTP incomplets : renseignez le serveur et l’adresse d’expédition dans Paramètres.','DESKTOP-GHOST','2026-10-14 12:44:47','2026-10-14 12:44:47',NULL,NULL,NULL),(2,1,1,'REINITIALISATION_MOT_DE_PASSE','User','1','Mot de passe défini à l’aide d’un lien de réinitialisation à usage unique.','DESKTOP-GHOST','2026-10-14 13:20:05','2026-10-14 13:20:05',NULL,NULL,NULL),(3,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 13:20:45','2026-10-14 13:20:45',NULL,NULL,NULL),(4,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 13:21:46','2026-10-14 13:21:46',NULL,NULL,NULL),(5,2,2,'REINITIALISATION_MOT_DE_PASSE','User','2','Mot de passe défini à l’aide d’un lien de réinitialisation à usage unique.','DESKTOP-GHOST','2026-10-14 13:22:41','2026-10-14 13:22:41',NULL,NULL,NULL),(6,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-14 13:23:28','2026-10-14 13:23:28',NULL,NULL,NULL),(7,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 13:27:38','2026-10-14 13:27:38',NULL,NULL,NULL),(8,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 13:49:24','2026-10-14 13:49:24',NULL,NULL,NULL),(9,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-14 13:50:08','2026-10-14 13:50:08',NULL,NULL,NULL),(10,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-14 14:00:56','2026-10-14 14:00:56',NULL,NULL,NULL),(11,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 06:49:40','2026-10-15 06:49:40',NULL,NULL,NULL),(12,1,1,'NOTIFICATION_MDP_LUE','PasswordResetRequest','1','Notification de rÃ©initialisation marquÃ©e comme lue.','DESKTOP-GHOST','2026-10-15 06:56:02','2026-10-15 06:56:02',NULL,NULL,NULL),(13,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-15 06:58:20','2026-10-15 06:58:20',NULL,NULL,NULL),(14,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 07:00:33','2026-10-15 07:00:33',NULL,NULL,NULL),(15,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 08:40:08','2026-10-15 08:40:08',NULL,NULL,NULL),(16,1,1,'CREATION','Company','1','Entreprise SZTC créée.','DESKTOP-GHOST','2026-10-15 08:58:09','2026-10-15 08:58:09',NULL,NULL,NULL),(17,1,1,'COORDONNEES','Company','1','Coordonnées de l’entreprise SZTC mises à jour.','DESKTOP-GHOST','2026-10-15 08:58:26','2026-10-15 08:58:26',NULL,NULL,NULL),(18,1,1,'CREATION','Company','2','Entreprise SAGEC-KAT créée.','DESKTOP-GHOST','2026-10-15 08:58:58','2026-10-15 08:58:58',NULL,NULL,NULL),(19,1,1,'CREATION','Company','3','Entreprise CGC créée.','DESKTOP-GHOST','2026-10-15 09:00:05','2026-10-15 09:00:05',NULL,NULL,NULL),(20,1,1,'CREATION','Contract','1','Contrat 068 créé avec 4 site(s).','DESKTOP-GHOST','2026-10-15 09:08:38','2026-10-15 09:08:38',NULL,NULL,NULL),(21,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 09:37:20','2026-10-15 09:37:20',NULL,NULL,NULL),(22,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 09:37:53','2026-10-15 09:37:53',NULL,NULL,NULL),(23,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-15 09:40:50','2026-10-15 09:40:50',NULL,NULL,NULL),(24,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 09:41:43','2026-10-15 09:41:43',NULL,NULL,NULL),(25,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 09:51:53','2026-10-15 09:51:53',NULL,NULL,NULL),(26,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 12:20:37','2026-10-15 12:20:37',NULL,NULL,NULL),(27,1,1,'CREATION','Contract','2','Contrat 069 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-15 12:57:07','2026-10-15 12:57:07',NULL,NULL,NULL),(28,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-15 13:01:00','2026-10-15 13:01:00',NULL,NULL,NULL),(29,1,1,'CREATION','Contract','3','Contrat 070 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-15 13:20:10','2026-10-15 13:20:10',NULL,NULL,NULL),(30,1,1,'MODIFICATION','Contract','3','Contrat 070 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-15 13:24:48','2026-10-15 13:24:48',NULL,NULL,NULL),(31,1,1,'TEST_SMTP','SmtpSetting','1','Aucun destinataire valide n’est configuré.','DESKTOP-GHOST','2026-10-15 13:30:23','2026-10-15 13:30:23',NULL,NULL,NULL),(32,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:32:19','2026-10-15 13:32:19',NULL,NULL,NULL),(33,1,1,'TEST_SMTP','SmtpSetting','1','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c3eda61fb26sm132808166b.69 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-10-15 13:32:44','2026-10-15 13:32:44',NULL,NULL,NULL),(34,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:34:19','2026-10-15 13:34:19',NULL,NULL,NULL),(35,1,1,'TEST_SMTP','SmtpSetting','1','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c3ed6be6ddasm138225366b.7 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-10-15 13:34:23','2026-10-15 13:34:23',NULL,NULL,NULL),(36,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261015_143425.sql.gz.','DESKTOP-GHOST','2026-10-15 13:34:25','2026-10-15 13:34:25',NULL,NULL,NULL),(37,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261015_143436.sql.gz.','DESKTOP-GHOST','2026-10-15 13:34:36','2026-10-15 13:34:36',NULL,NULL,NULL),(38,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:43:47','2026-10-15 13:43:47',NULL,NULL,NULL),(39,1,1,'TEST_SMTP','SmtpSetting','1','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c3ed6be6546sm135422966b.4 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-10-15 13:43:52','2026-10-15 13:43:52',NULL,NULL,NULL),(40,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:45:13','2026-10-15 13:45:13',NULL,NULL,NULL),(41,1,1,'TEST_SMTP','SmtpSetting','1','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c3eda620c30sm135172766b.66 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-10-15 13:45:21','2026-10-15 13:45:21',NULL,NULL,NULL),(42,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261015_144636.sql.gz.','DESKTOP-GHOST','2026-10-15 13:46:36','2026-10-15 13:46:36',NULL,NULL,NULL),(43,1,1,'PARAMETRES_SMTP','SmtpSetting','1','ParamÃ¨tres SMTP enregistrÃ©s.','DESKTOP-GHOST','2026-10-15 13:54:15','2026-10-15 13:54:15',NULL,NULL,NULL),(44,1,1,'TEST_SMTP','SmtpSetting','1','Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-15 13:54:24','2026-10-15 13:54:24',NULL,NULL,NULL),(45,1,1,'TEST_SMTP','SmtpSetting','1','Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-15 13:54:31','2026-10-15 13:54:31',NULL,NULL,NULL),(46,1,1,'ALERTE_GARANTIE','PerformanceGuarantee','2','Alerte « 069 » envoyée manuellement. Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-15 13:55:02','2026-10-15 13:55:02',NULL,NULL,NULL),(47,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-16 06:57:04','2026-10-16 06:57:04',NULL,NULL,NULL),(48,1,1,'CREATION','Contract','4','Contrat 071 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-16 07:55:09','2026-10-16 07:55:09',NULL,NULL,NULL),(49,1,1,'CREATION','Contract','5','Contrat 072 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-16 08:07:40','2026-10-16 08:07:40',NULL,NULL,NULL),(50,1,1,'MODIFICATION','Contract','5','Contrat 072 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:07:55','2026-10-16 08:07:55',NULL,NULL,NULL),(51,1,1,'MODIFICATION','Contract','1','Contrat 068 modifié avec 4 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:08:25','2026-10-16 08:08:25',NULL,NULL,NULL),(52,1,1,'MODIFICATION','Contract','2','Contrat 069 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:08:45','2026-10-16 08:08:45',NULL,NULL,NULL),(53,1,1,'MODIFICATION','Contract','3','Contrat 070 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:09:14','2026-10-16 08:09:14',NULL,NULL,NULL),(54,1,1,'MODIFICATION','Contract','4','Contrat 071 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 08:10:14','2026-10-16 08:10:14',NULL,NULL,NULL),(55,1,1,'CREATION','Contract','6','Contrat 073 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-16 09:47:51','2026-10-16 09:47:51',NULL,NULL,NULL),(56,1,1,'CREATION','Contract','7','Contrat 091 créé avec 3 site(s).','DESKTOP-GHOST','2026-10-16 09:54:14','2026-10-16 09:54:14',NULL,NULL,NULL),(57,1,1,'MODIFICATION','Contract','7','Contrat 091 modifié avec 3 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 10:06:09','2026-10-16 10:06:09',NULL,NULL,NULL),(58,1,1,'CREATION','ProgressEntry','1','Situation du contrat 068 : 16/10/2026, avancement 78 %.','DESKTOP-GHOST','2026-10-16 10:15:22','2026-10-16 10:15:22',NULL,NULL,NULL),(59,1,1,'MODIFICATION','Contract','1','Contrat 068 modifié avec 4 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 10:24:34','2026-10-16 10:24:34',NULL,NULL,NULL),(60,1,1,'CREATION','ProgressEntry','2','Situation du contrat 068 : 30/09/2026, avancement 39 %.','DESKTOP-GHOST','2026-10-16 10:41:49','2026-10-16 10:41:49',NULL,NULL,NULL),(61,1,1,'MODIFICATION','ProgressEntry','1','Contrat 068. Ancienne situation : date 16/10/2026, avancement 78 %. Nouvelle : date 30/09/2026, avancement 78 %.','DESKTOP-GHOST','2026-10-16 10:42:06','2026-10-16 10:42:06',NULL,NULL,NULL),(62,1,1,'CREATION','ProgressEntry','3','Situation du contrat 068 : 30/09/2026, avancement 21 %.','DESKTOP-GHOST','2026-10-16 10:45:06','2026-10-16 10:45:06',NULL,NULL,NULL),(63,1,1,'CREATION','ProgressEntry','4','Situation du contrat 068 : 30/09/2026, avancement 1 %.','DESKTOP-GHOST','2026-10-16 11:04:49','2026-10-16 11:04:49',NULL,NULL,NULL),(64,1,1,'MODIFICATION','Contract','1','Contrat 068 modifié avec 4 site(s) enregistré(s).','DESKTOP-GHOST','2026-10-16 11:06:29','2026-10-16 11:06:29',NULL,NULL,NULL),(65,1,1,'CREATION','ContractPayment','1','Paiement du contrat 068, date 30/09/2026, montant 352 268,82.','DESKTOP-GHOST','2026-10-16 12:29:46','2026-10-16 12:29:46',NULL,NULL,NULL),(66,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 15:45:19','2026-10-18 15:45:19',NULL,NULL,NULL),(67,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 16:00:23','2026-10-18 16:00:23',NULL,NULL,NULL),(68,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 16:29:10','2026-10-18 16:29:10',NULL,NULL,NULL),(69,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 16:48:27','2026-10-18 16:48:27',NULL,NULL,NULL),(70,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 22:22:26','2026-10-18 22:22:26',NULL,NULL,NULL),(71,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 22:51:35','2026-10-18 22:51:35',NULL,NULL,NULL),(72,1,3,'DEMANDE_INSCRIPTION','User','3','Demande d’inscription de jorcelinmikado@gmail.com, en attente de validation.','DESKTOP-GHOST','2026-10-18 22:53:27','2026-10-18 22:53:27',NULL,NULL,NULL),(73,1,1,'APPROBATION_COMPTE','User','3','Compte jorcelinmikado@gmail.com approuvÃ© (lecture seule). Ajustez les habilitations si nÃ©cessaire.','DESKTOP-GHOST','2026-10-18 22:53:58','2026-10-18 22:53:58',NULL,NULL,NULL),(74,1,3,'CONNEXION','User','3','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-18 22:54:42','2026-10-18 22:54:42',NULL,NULL,NULL),(75,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises Ã  jour.','DESKTOP-GHOST','2026-10-18 22:56:10','2026-10-18 22:56:10',NULL,NULL,NULL),(76,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises Ã  jour.','DESKTOP-GHOST','2026-10-18 22:57:35','2026-10-18 22:57:35',NULL,NULL,NULL),(77,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-19 06:31:46','2026-10-19 06:31:46',NULL,NULL,NULL),(78,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261019_084637.sql.gz.','DESKTOP-GHOST','2026-10-19 07:46:37','2026-10-19 07:46:37',NULL,NULL,NULL),(79,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-19 13:09:57','2026-10-19 13:09:57',NULL,NULL,NULL),(80,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-19 13:54:26','2026-10-19 13:54:26',NULL,NULL,NULL),(81,1,1,'CREATION','ProgressEntry','5','Situation du contrat 069 : 30/09/2026, avancement 24 %.','DESKTOP-GHOST','2026-10-19 13:58:27','2026-10-19 13:58:27',NULL,NULL,NULL),(82,1,1,'CREATION','ProgressEntry','6','Situation du contrat 069 : 30/09/2026, avancement 28 %.','DESKTOP-GHOST','2026-10-19 14:01:26','2026-10-19 14:01:26',NULL,NULL,NULL),(83,1,1,'MODIFICATION','ProgressEntry','5','Contrat 069. Ancienne situation : date 30/09/2026, avancement 24 %. Nouvelle : date 30/09/2026, avancement 24 %.','DESKTOP-GHOST','2026-10-19 14:01:45','2026-10-19 14:01:45',NULL,NULL,NULL),(84,1,1,'CREATION','ProgressEntry','7','Situation du contrat 069 : 30/09/2026, avancement 19 %.','DESKTOP-GHOST','2026-10-19 14:04:46','2026-10-19 14:04:46',NULL,NULL,NULL),(85,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-22 14:18:36','2026-10-22 14:18:36',NULL,NULL,NULL),(86,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises Ã  jour.','DESKTOP-GHOST','2026-10-22 15:20:47','2026-10-22 15:20:47',NULL,NULL,NULL),(87,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-22 20:11:51','2026-10-22 20:11:51',NULL,NULL,NULL),(88,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 09:41:12','2026-10-28 09:41:12',NULL,NULL,NULL),(89,1,1,'ALERTE_RETARD','Contract','3','Alerte « 070 » envoyée manuellement. Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-28 12:37:06','2026-10-28 12:37:06',NULL,NULL,NULL),(90,1,1,'ALERTE_RETARD','Contract','2','Alerte « 069 » envoyée manuellement. Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-10-28 12:37:12','2026-10-28 12:37:12',NULL,NULL,NULL),(91,1,1,'MODIFICATION_UNITE','OrganizationalUnit','1','Unité Coordination nationale modifiée.','DESKTOP-GHOST','2026-10-28 12:40:00','2026-10-28 12:40:00',NULL,'{\"id\":1,\"project_id\":1,\"type\":\"COORDINATION\",\"code\":\"CN\",\"name\":\"Coordination nationale\",\"province\":null,\"description\":null,\"is_active\":1}','{\"id\":1,\"project_id\":1,\"type\":\"COORDINATION\",\"code\":\"CN\",\"name\":\"Coordination nationale\",\"province\":\"Kinshasa\",\"description\":null,\"is_active\":1}'),(92,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 12:50:06','2026-10-28 12:50:06',NULL,NULL,NULL),(93,1,1,'CREATION_POSTE','Position','1','Poste CN créé.','DESKTOP-GHOST','2026-10-28 12:51:28','2026-10-28 12:51:28',NULL,NULL,'{\"name\":\"CN\",\"description\":\"COORDINATION NATIONALE\",\"project_id\":1,\"is_active\":true,\"id\":1}'),(94,1,1,'CREATION_POSTE','Position','2','Poste HNRAF créé.','DESKTOP-GHOST','2026-10-28 12:52:45','2026-10-28 12:52:45',NULL,NULL,'{\"name\":\"HNRAF\",\"description\":\"MANDAT DE L’HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"project_id\":1,\"is_active\":true,\"id\":2}'),(95,1,1,'CREATION_POSTE','Position','3','Poste COMPTABLE créé.','DESKTOP-GHOST','2026-10-28 12:53:12','2026-10-28 12:53:12',NULL,NULL,'{\"name\":\"COMPTABLE\",\"description\":\"COMPTABLE\",\"project_id\":1,\"is_active\":true,\"id\":3}'),(96,1,1,'MODIFICATION_POSTE','Position','2','Poste HNRAF modifié.','DESKTOP-GHOST','2026-10-28 12:53:23','2026-10-28 12:53:23',NULL,'{\"id\":2,\"project_id\":1,\"name\":\"HNRAF\",\"description\":\"MANDAT DE L’HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"is_active\":1}','{\"id\":2,\"project_id\":1,\"name\":\"HNRAF\",\"description\":\"HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"is_active\":1}'),(97,1,1,'CREATION_POSTE','Position','4','Poste AC créé.','DESKTOP-GHOST','2026-10-28 12:53:51','2026-10-28 12:53:51',NULL,NULL,'{\"name\":\"AC\",\"description\":\"ASSISTANT COMPTABLE\",\"project_id\":1,\"is_active\":true,\"id\":4}'),(98,1,1,'CREATION_POSTE','Position','5','Poste HCPM créé.','DESKTOP-GHOST','2026-10-28 12:54:25','2026-10-28 12:54:25',NULL,NULL,'{\"name\":\"HCPM\",\"description\":\"HOMOLOGUE NATIONAL EN PASSATION DE MARCHES\",\"project_id\":1,\"is_active\":true,\"id\":5}'),(99,1,1,'MODIFICATION_UNITE','OrganizationalUnit','1','Unité Coordination nationale modifiée.','DESKTOP-GHOST','2026-10-28 12:54:50','2026-10-28 12:54:50',NULL,'{\"id\":1,\"project_id\":1,\"type\":\"COORDINATION\",\"code\":\"CN\",\"name\":\"Coordination nationale\",\"province\":\"Kinshasa\",\"description\":null,\"is_active\":1}','{\"id\":1,\"project_id\":1,\"type\":\"COORDINATION\",\"code\":\"CN\",\"name\":\"Coordination nationale\",\"province\":\"Kinshasa\",\"description\":null,\"is_active\":1}'),(100,1,1,'CREATION_POSTE','Position','6','Poste APM créé.','DESKTOP-GHOST','2026-10-28 12:55:40','2026-10-28 12:55:40',NULL,NULL,'{\"name\":\"APM\",\"description\":\"ASSISTANT EN PASSATION DES MARCHES\",\"project_id\":1,\"is_active\":true,\"id\":6}'),(101,1,1,'CREATION_POSTE','Position','7','Poste HNSE créé.','DESKTOP-GHOST','2026-10-28 12:59:35','2026-10-28 12:59:35',NULL,NULL,'{\"name\":\"HNSE\",\"description\":\"HOMOLOGUE NATIONAL EN SUIVI-EVALUATION\",\"project_id\":1,\"is_active\":true,\"id\":7}'),(102,1,1,'CREATION_POSTE','Position','8','Poste CCI créé.','DESKTOP-GHOST','2026-10-28 13:00:52','2026-10-28 13:00:52',NULL,NULL,'{\"name\":\"CCI\",\"description\":\"CHEF DE CELLULE INFRASTRUCTURES (AEP)\",\"project_id\":1,\"is_active\":true,\"id\":8}'),(103,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 13:38:15','2026-10-28 13:38:15',NULL,NULL,NULL),(104,1,1,'EXPORT_RAPPORT','FleetReport','VEHICULE','Export Excel : Rapport carburant des véhicules — toutes les unités — du 01/10/2026 au 28/10/2026.','DESKTOP-GHOST','2026-10-28 13:38:39','2026-10-28 13:38:39',NULL,NULL,NULL),(105,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 14:10:58','2026-10-28 14:10:58',NULL,NULL,NULL),(106,1,1,'MODIFICATION_POSTE','Position','4','Poste AC modifié.','DESKTOP-GHOST','2026-10-28 14:15:08','2026-10-28 14:15:08',1,'{\"id\":4,\"project_id\":1,\"organizational_unit_id\":null,\"name\":\"AC\",\"description\":\"ASSISTANT COMPTABLE\",\"is_active\":1}','{\"id\":4,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"AC\",\"description\":\"ASSISTANT COMPTABLE\",\"is_active\":1}'),(107,1,1,'MODIFICATION_POSTE','Position','6','Poste APM modifié.','DESKTOP-GHOST','2026-10-28 14:15:17','2026-10-28 14:15:17',1,'{\"id\":6,\"project_id\":1,\"organizational_unit_id\":null,\"name\":\"APM\",\"description\":\"ASSISTANT EN PASSATION DES MARCHES\",\"is_active\":1}','{\"id\":6,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"APM\",\"description\":\"ASSISTANT EN PASSATION DES MARCHES\",\"is_active\":1}'),(108,1,1,'MODIFICATION_POSTE','Position','8','Poste CCI modifié.','DESKTOP-GHOST','2026-10-28 14:15:29','2026-10-28 14:15:29',1,'{\"id\":8,\"project_id\":1,\"organizational_unit_id\":null,\"name\":\"CCI\",\"description\":\"CHEF DE CELLULE INFRASTRUCTURES (AEP)\",\"is_active\":1}','{\"id\":8,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"CCI\",\"description\":\"CHEF DE CELLULE INFRASTRUCTURES (AEP)\",\"is_active\":1}'),(109,1,1,'MODIFICATION_POSTE','Position','1','Poste CN modifié.','DESKTOP-GHOST','2026-10-28 14:15:40','2026-10-28 14:15:40',1,'{\"id\":1,\"project_id\":1,\"organizational_unit_id\":null,\"name\":\"CN\",\"description\":\"COORDINATION NATIONALE\",\"is_active\":1}','{\"id\":1,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"CN\",\"description\":\"COORDINATION NATIONALE\",\"is_active\":1}'),(110,1,1,'MODIFICATION_POSTE','Position','3','Poste COMPTABLE modifié.','DESKTOP-GHOST','2026-10-28 14:15:50','2026-10-28 14:15:50',1,'{\"id\":3,\"project_id\":1,\"organizational_unit_id\":null,\"name\":\"COMPTABLE\",\"description\":\"COMPTABLE\",\"is_active\":1}','{\"id\":3,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"COMPTABLE\",\"description\":\"COMPTABLE\",\"is_active\":1}'),(111,1,1,'MODIFICATION_POSTE','Position','1','Poste CN modifié.','DESKTOP-GHOST','2026-10-28 14:16:05','2026-10-28 14:16:05',1,'{\"id\":1,\"project_id\":1,\"organizational_unit_id\":1,\"name\":\"CN\",\"description\":\"COORDINATION NATIONALE\",\"is_active\":1}','{\"id\":1,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"CN\",\"description\":\"COORDINATEUR NATIONALE\",\"is_active\":1}'),(112,1,1,'MODIFICATION_POSTE','Position','3','Poste COMPTABLE modifié.','DESKTOP-GHOST','2026-10-28 14:16:19','2026-10-28 14:16:19',1,'{\"id\":3,\"project_id\":1,\"organizational_unit_id\":1,\"name\":\"COMPTABLE\",\"description\":\"COMPTABLE\",\"is_active\":1}','{\"id\":3,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"COMPTABLE\",\"description\":\"COMPTABLE\",\"is_active\":1}'),(113,1,1,'MODIFICATION_POSTE','Position','5','Poste HCPM modifié.','DESKTOP-GHOST','2026-10-28 14:16:32','2026-10-28 14:16:32',1,'{\"id\":5,\"project_id\":1,\"organizational_unit_id\":null,\"name\":\"HCPM\",\"description\":\"HOMOLOGUE NATIONAL EN PASSATION DE MARCHES\",\"is_active\":1}','{\"id\":5,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"HCPM\",\"description\":\"HOMOLOGUE NATIONAL EN PASSATION DE MARCHES\",\"is_active\":1}'),(114,1,1,'MODIFICATION_POSTE','Position','2','Poste HNRAF modifié.','DESKTOP-GHOST','2026-10-28 14:16:40','2026-10-28 14:16:40',1,'{\"id\":2,\"project_id\":1,\"organizational_unit_id\":null,\"name\":\"HNRAF\",\"description\":\"HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"is_active\":1}','{\"id\":2,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"HNRAF\",\"description\":\"HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"is_active\":1}'),(115,1,1,'MODIFICATION_POSTE','Position','7','Poste HNSE modifié.','DESKTOP-GHOST','2026-10-28 14:16:52','2026-10-28 14:16:52',1,'{\"id\":7,\"project_id\":1,\"organizational_unit_id\":null,\"name\":\"HNSE\",\"description\":\"HOMOLOGUE NATIONAL EN SUIVI-EVALUATION\",\"is_active\":1}','{\"id\":7,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"HNSE\",\"description\":\"HOMOLOGUE NATIONAL EN SUIVI-EVALUATION\",\"is_active\":1}'),(116,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 14:19:54','2026-10-28 14:19:54',NULL,NULL,NULL),(117,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261028_152502.sql.gz.','DESKTOP-GHOST','2026-10-28 14:25:02','2026-10-28 14:25:02',1,NULL,NULL),(118,1,1,'CREATION_POSTE','Position','9','Poste SI créé.','DESKTOP-GHOST','2026-10-28 14:27:23','2026-10-28 14:27:23',1,NULL,'{\"organizational_unit_id\":\"1\",\"name\":\"SI\",\"description\":\"SECRETAIRE INFORMATICIEN\",\"project_id\":1,\"is_active\":true,\"id\":9}'),(119,1,1,'CREATION_POSTE','Position','10','Poste SECA créé.','DESKTOP-GHOST','2026-10-28 14:27:48','2026-10-28 14:27:48',1,NULL,'{\"organizational_unit_id\":\"1\",\"name\":\"SECA\",\"description\":\"SECRETAIRE CAISSIER\",\"project_id\":1,\"is_active\":true,\"id\":10}'),(120,1,1,'CREATION_POSTE','Position','11','Poste LOGISTICIEN créé.','DESKTOP-GHOST','2026-10-28 14:28:40','2026-10-28 14:28:40',1,NULL,'{\"organizational_unit_id\":\"1\",\"name\":\"LOGISTICIEN\",\"description\":\"CHAUFFEUR LOGISTICIEN\",\"project_id\":1,\"is_active\":true,\"id\":11}'),(121,1,1,'CREATION_POSTE','Position','12','Poste CHAUFFEUR COURSIER créé.','DESKTOP-GHOST','2026-10-28 14:29:16','2026-10-28 14:29:16',1,NULL,'{\"organizational_unit_id\":\"1\",\"name\":\"CHAUFFEUR COURSIER\",\"description\":\"CHAUFFEUR COURSIER\",\"project_id\":1,\"is_active\":true,\"id\":12}'),(122,1,1,'CREATION_POSTE','Position','13','Poste C.A KANANGA créé.','DESKTOP-GHOST','2026-10-28 14:31:10','2026-10-28 14:31:10',1,NULL,'{\"organizational_unit_id\":\"4\",\"name\":\"C.A KANANGA\",\"description\":\"INGENIEUR AEP (CHEF D\'ANTENNE KANANGA)\",\"project_id\":1,\"is_active\":true,\"id\":13}'),(123,1,1,'CREATION_POSTE','Position','14','Poste ISE KANANGA créé.','DESKTOP-GHOST','2026-10-28 14:32:16','2026-10-28 14:32:16',1,NULL,'{\"organizational_unit_id\":\"4\",\"name\":\"ISE KANANGA\",\"description\":\"INGENIEUR EN SUIVI-EVALUATION (POOL OUEST)\",\"project_id\":1,\"is_active\":true,\"id\":14}'),(124,1,1,'CREATION_POSTE','Position','15','Poste ISE MBUJI-MAYI créé.','DESKTOP-GHOST','2026-10-28 14:33:00','2026-10-28 14:33:00',1,NULL,'{\"organizational_unit_id\":\"3\",\"name\":\"ISE MBUJI-MAYI\",\"description\":\"INGENIEUR EN SUIVI-EVALUATION (POOL EST)\",\"project_id\":1,\"is_active\":true,\"id\":15}'),(125,1,1,'CREATION_POSTE','Position','16','Poste C.A MBUJI-MAYI créé.','DESKTOP-GHOST','2026-10-28 14:35:24','2026-10-28 14:35:24',1,NULL,'{\"organizational_unit_id\":\"3\",\"name\":\"C.A MBUJI-MAYI\",\"description\":\"CHEF D\'ANTENNE MBUJI-MAYI(POOL EST)\",\"project_id\":1,\"is_active\":true,\"id\":16}'),(126,1,1,'MODIFICATION_POSTE','Position','13','Poste C.A KANANGA modifié.','DESKTOP-GHOST','2026-10-28 14:36:04','2026-10-28 14:36:04',1,'{\"id\":13,\"project_id\":1,\"organizational_unit_id\":4,\"name\":\"C.A KANANGA\",\"description\":\"INGENIEUR AEP (CHEF D\'ANTENNE KANANGA)\",\"is_active\":1}','{\"id\":13,\"project_id\":1,\"organizational_unit_id\":\"4\",\"name\":\"C.A KANANGA\",\"description\":\"CHEF D\'ANTENNE KANANGA (POOL OUEST)\",\"is_active\":1}'),(127,1,1,'CREATION_POSTE','Position','17','Poste SECA créé.','DESKTOP-GHOST','2026-10-28 14:38:00','2026-10-28 14:38:00',1,NULL,'{\"organizational_unit_id\":\"4\",\"name\":\"SECA\",\"description\":\"SECRETAIRE-CAISSIER (POOL OUEST)\",\"project_id\":1,\"is_active\":true,\"id\":17}'),(128,1,1,'CREATION_POSTE','Position','18','Poste SECA créé.','DESKTOP-GHOST','2026-10-28 14:38:22','2026-10-28 14:38:22',1,NULL,'{\"organizational_unit_id\":\"3\",\"name\":\"SECA\",\"description\":\"SECRETAIRE-CAISSIER (POOL EST)\",\"project_id\":1,\"is_active\":true,\"id\":18}'),(129,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 16:54:09','2026-10-28 16:54:09',NULL,NULL,NULL),(130,1,1,'CREATION','Decompte','1','DECOMPTE N°1 du contrat 069 (SAGEC-KAT) : 450 340,00 USD, transmis au comptable.','DESKTOP-GHOST','2026-10-28 16:58:45','2026-10-28 16:58:45',1,NULL,'{\"project_id\":1,\"contract_id\":2,\"line_no\":1,\"number\":\"DECOMPTE N°1\",\"operation_date\":\"2026-10-28\",\"gross_amount\":450340,\"advance_rate\":0.3,\"guarantee_rate\":0.05,\"status\":\"EN_ATTENTE\",\"observation\":null,\"submitted_by\":1,\"created_at\":\"2026-10-28T17:58:45.028165Z\",\"updated_at\":\"2026-10-28T17:58:45.028184Z\"}'),(131,1,1,'AFFECTATION_UTILISATEUR','User','3','Affectation de jorcelinmikado@gmail.com mise à jour.','DESKTOP-GHOST','2026-10-28 17:01:02','2026-10-28 17:01:02',1,'{\"organizational_unit_id\":null,\"position_id\":null}','{\"organizational_unit_id\":\"1\",\"position_id\":\"3\"}'),(132,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises à jour.','DESKTOP-GHOST','2026-10-28 17:02:40','2026-10-28 17:02:40',1,NULL,NULL),(133,1,3,'CONNEXION','User','3','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 17:03:48','2026-10-28 17:03:48',NULL,NULL,NULL),(134,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises à jour.','DESKTOP-GHOST','2026-10-28 17:05:20','2026-10-28 17:05:20',1,NULL,NULL),(135,1,3,'CREATION','Decompte','2','DECOMPTE N°2 du contrat 069 (SAGEC-KAT) : 1 200 345,00 USD, transmis au comptable.','DESKTOP-GHOST','2026-10-28 17:07:47','2026-10-28 17:07:47',1,NULL,'{\"project_id\":1,\"contract_id\":2,\"line_no\":2,\"number\":\"DECOMPTE N°2\",\"operation_date\":\"2026-10-28\",\"gross_amount\":1200345,\"advance_rate\":0.3,\"guarantee_rate\":0.05,\"status\":\"EN_ATTENTE\",\"observation\":null,\"submitted_by\":3,\"created_at\":\"2026-10-28T18:07:47.213355Z\",\"updated_at\":\"2026-10-28T18:07:47.213389Z\"}'),(136,1,4,'DEMANDE_INSCRIPTION','User','4','Demande d’inscription de bukatitivalentin@gmail.com, en attente de validation.','DESKTOP-GHOST','2026-10-28 17:10:51','2026-10-28 17:10:51',NULL,NULL,NULL),(137,1,1,'APPROBATION_COMPTE','User','4','Compte bukatitivalentin@gmail.com approuvé (lecture seule). Ajustez les habilitations si nécessaire.','DESKTOP-GHOST','2026-10-28 17:11:19','2026-10-28 17:11:19',1,NULL,NULL),(138,1,4,'CONNEXION','User','4','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 17:11:57','2026-10-28 17:11:57',NULL,NULL,NULL),(139,1,1,'HABILITATIONS','User','4','Habilitations de bukatitivalentin@gmail.com mises à jour.','DESKTOP-GHOST','2026-10-28 17:15:29','2026-10-28 17:15:29',1,NULL,NULL),(140,1,1,'MODIFICATION_POSTE','Position','4','Poste ASSISTANT COMPTABLE modifié.','DESKTOP-GHOST','2026-10-28 17:21:51','2026-10-28 17:21:51',1,'{\"id\":4,\"project_id\":1,\"organizational_unit_id\":1,\"name\":\"AC\",\"description\":\"ASSISTANT COMPTABLE\",\"is_active\":1}','{\"id\":4,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"ASSISTANT COMPTABLE\",\"description\":\"ASSISTANT COMPTABLE\",\"is_active\":1}'),(141,1,1,'MODIFICATION_POSTE','Position','8','Poste CHEF DE CELLULE INFRASTRUCTURES (AEP) modifié.','DESKTOP-GHOST','2026-10-28 17:22:20','2026-10-28 17:22:20',1,'{\"id\":8,\"project_id\":1,\"organizational_unit_id\":1,\"name\":\"CCI\",\"description\":\"CHEF DE CELLULE INFRASTRUCTURES (AEP)\",\"is_active\":1}','{\"id\":8,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"CHEF DE CELLULE INFRASTRUCTURES (AEP)\",\"description\":\"CHEF DE CELLULE INFRASTRUCTURES (AEP)\",\"is_active\":1}'),(142,1,1,'MODIFICATION_POSTE','Position','9','Poste SECRETAIREINFORMATICIEN modifié.','DESKTOP-GHOST','2026-10-28 17:23:15','2026-10-28 17:23:15',1,'{\"id\":9,\"project_id\":1,\"organizational_unit_id\":1,\"name\":\"SI\",\"description\":\"SECRETAIRE INFORMATICIEN\",\"is_active\":1}','{\"id\":9,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"SECRETAIREINFORMATICIEN\",\"description\":\"SECRETAIRE INFORMATICIEN\",\"is_active\":1}'),(143,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261028_182407.sql.gz.','DESKTOP-GHOST','2026-10-28 17:24:07','2026-10-28 17:24:07',1,NULL,NULL),(144,1,5,'DEMANDE_INSCRIPTION','User','5','Demande d’inscription de ruthmusikitela45@gmail.com, en attente de validation.','DESKTOP-GHOST','2026-10-28 17:29:41','2026-10-28 17:29:41',NULL,NULL,NULL),(145,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 17:30:57','2026-10-28 17:30:57',NULL,NULL,NULL),(146,1,1,'APPROBATION_COMPTE','User','5','Compte ruthmusikitela45@gmail.com approuvé (lecture seule). Ajustez les habilitations si nécessaire.','DESKTOP-GHOST','2026-10-28 17:31:03','2026-10-28 17:31:03',1,NULL,NULL),(147,1,1,'HABILITATIONS','User','5','Habilitations de ruthmusikitela45@gmail.com mises à jour.','DESKTOP-GHOST','2026-10-28 17:31:44','2026-10-28 17:31:44',1,NULL,NULL),(148,1,5,'CONNEXION','User','5','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 17:32:39','2026-10-28 17:32:39',NULL,NULL,NULL),(149,1,1,'MODIFICATION_POSTE','Position','1','Poste CN modifié.','DESKTOP-GHOST','2026-10-28 17:38:05','2026-10-28 17:38:05',1,'{\"id\":1,\"project_id\":1,\"organizational_unit_id\":1,\"name\":\"CN\",\"description\":\"COORDINATEUR NATIONALE\",\"is_active\":1}','{\"id\":1,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"CN\",\"description\":\"COORDINATEUR NATIONALE\",\"is_active\":1}'),(150,1,1,'CREATION','FleetAsset','1','Véhicule « TOYOTA FORTUNER » ajouté au parc.','DESKTOP-GHOST','2026-10-28 17:44:23','2026-10-28 17:44:23',1,NULL,'{\"kind\":\"VEHICULE\",\"name\":\"TOYOTA FORTUNER\",\"registration\":\"1083 IT 23\",\"organizational_unit_id\":1,\"tank_capacity\":120,\"consumption_rate\":0.2,\"fuel_price\":1.37,\"fuel_alert_level\":30,\"maintenance_interval\":3000,\"maintenance_warning\":2500,\"initial_meter\":4578}'),(151,1,1,'EXPORT_RAPPORT','FleetReport','VEHICULE','Export Excel : Rapport carburant des véhicules — toutes les unités — du 01/10/2026 au 28/10/2026.','DESKTOP-GHOST','2026-10-28 17:46:21','2026-10-28 17:46:21',1,NULL,NULL),(152,1,4,'CONNEXION','User','4','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-28 17:47:33','2026-10-28 17:47:33',NULL,NULL,NULL),(153,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 06:49:30','2026-10-29 06:49:30',NULL,NULL,NULL),(154,1,1,'AJOUT_DOCUMENT','ContractDocument','1','Document TDR_PRISE_PREDIRE_version_amelioree.pdf ajouté au contrat 068.','DESKTOP-GHOST','2026-10-29 06:51:21','2026-10-29 06:51:21',1,NULL,NULL),(155,1,1,'SUPPRESSION_DOCUMENT','ContractDocument','1','Document TDR_PRISE_PREDIRE_version_amelioree.pdf supprimé du contrat 068.','DESKTOP-GHOST','2026-10-29 06:51:37','2026-10-29 06:51:37',1,NULL,NULL),(156,1,1,'CREATION','FleetLog','1','Course vers AERO  NDJILI du 29/10/2026 — TOYOTA FORTUNER : 140 km.','DESKTOP-GHOST','2026-10-29 07:09:20','2026-10-29 07:09:20',1,NULL,'{\"log_date\":\"2026-10-29\",\"meter_start\":42723,\"meter_end\":42863,\"fuel_level_before\":30,\"fuel_purchased\":null,\"lubricant\":2,\"fuel_price\":1.37,\"requester\":\"RAF\",\"destination\":\"AERO  NDJILI\",\"purpose\":\"Récupérer la délégation BAD\",\"departure_time\":\"08:45\",\"arrival_time\":\"16:10\",\"observation\":null}'),(157,1,5,'CONNEXION','User','5','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 07:12:41','2026-10-29 07:12:41',NULL,NULL,NULL),(158,1,1,'MODIFICATION_POSTE','Position','2','Poste HRAF modifié.','DESKTOP-GHOST','2026-10-29 08:13:18','2026-10-29 08:13:18',1,'{\"id\":2,\"project_id\":1,\"organizational_unit_id\":1,\"name\":\"HNRAF\",\"description\":\"HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"is_active\":1}','{\"id\":2,\"project_id\":1,\"organizational_unit_id\":\"1\",\"name\":\"HRAF\",\"description\":\"HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER\",\"is_active\":1}'),(159,1,4,'CONNEXION','User','4','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 08:47:23','2026-10-29 08:47:23',NULL,NULL,NULL),(160,1,6,'DEMANDE_INSCRIPTION','User','6','Demande d’inscription de glody@gmail.com, en attente de validation.','DESKTOP-GHOST','2026-10-29 08:52:53','2026-10-29 08:52:53',NULL,NULL,NULL),(161,1,1,'APPROBATION_COMPTE','User','6','Compte glody@gmail.com approuvé (lecture seule). Ajustez les habilitations si nécessaire.','DESKTOP-GHOST','2026-10-29 08:55:34','2026-10-29 08:55:34',1,NULL,NULL),(162,1,1,'HABILITATIONS','User','6','Habilitations de glody@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-29 08:56:45','2026-10-29 08:56:45',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":true,\"can_view_situation\":true,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":false,\"can_manage_stock\":false,\"can_view_fleet\":false,\"can_manage_fleet\":false,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":false,\"can_view_fleet\":true,\"can_manage_fleet\":false,\"can_authorize_fleet\":true,\"can_validate_decomptes\":true,\"can_view_pools\":false,\"role\":\"UTILISATEUR\"}'),(163,1,6,'CONNEXION','User','6','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 08:57:15','2026-10-29 08:57:15',NULL,NULL,NULL),(164,1,1,'CREATION','Decompte','3','DECOMPTE N°1 du contrat 068 (SZTC) : 236 789,00 USD, transmis au comptable.','DESKTOP-GHOST','2026-10-29 09:01:21','2026-10-29 09:01:21',1,NULL,'{\"project_id\":1,\"contract_id\":1,\"line_no\":1,\"number\":\"DECOMPTE N°1\",\"operation_date\":\"2026-10-29\",\"gross_amount\":236789,\"advance_rate\":0.3,\"guarantee_rate\":0.05,\"status\":\"EN_ATTENTE\",\"observation\":null,\"submitted_by\":1,\"created_at\":\"2026-10-29T10:01:21.376149Z\",\"updated_at\":\"2026-10-29T10:01:21.376166Z\"}'),(165,1,6,'VALIDATION','Decompte','3','DECOMPTE N°1 du contrat 068 validé par le comptable.','DESKTOP-GHOST','2026-10-29 09:11:21','2026-10-29 09:11:21',1,'{\"status\":\"EN_ATTENTE\"}','{\"status\":\"VALIDE\",\"decided_by\":6,\"decided_at\":\"2026-10-29 10:11:21\",\"decision_comment\":null}'),(166,1,1,'EXPORT_RAPPORT','Report','PRISE','Export Excel du rapport au 29/10/2026.','DESKTOP-GHOST','2026-10-29 10:04:43','2026-10-29 10:04:43',1,NULL,NULL),(167,1,6,'VALIDATION','Decompte','1','DECOMPTE N°1 du contrat 069 validé par le comptable le 29/10/2026.','DESKTOP-GHOST','2026-10-29 10:33:54','2026-10-29 10:33:54',1,'{\"status\":\"EN_ATTENTE\"}','{\"status\":\"VALIDE\",\"decided_by\":6,\"decided_at\":\"2026-10-29 11:33:54\",\"decision_date\":\"2026-10-29\",\"decision_comment\":null}'),(168,1,6,'VALIDATION','Decompte','2','DECOMPTE N°2 du contrat 069 validé par le comptable le 29/10/2026.','DESKTOP-GHOST','2026-10-29 10:33:58','2026-10-29 10:33:58',1,'{\"status\":\"EN_ATTENTE\"}','{\"status\":\"VALIDE\",\"decided_by\":6,\"decided_at\":\"2026-10-29 11:33:58\",\"decision_date\":\"2026-10-29\",\"decision_comment\":null}'),(169,1,4,'CONNEXION','User','4','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 10:37:05','2026-10-29 10:37:05',NULL,NULL,NULL),(170,1,6,'CONNEXION','User','6','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 12:20:23','2026-10-29 12:20:23',NULL,NULL,NULL),(171,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-10-29 13:10:23','2026-10-29 13:10:23',NULL,NULL,NULL),(172,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 13:18:00','2026-10-29 13:18:00',NULL,NULL,NULL),(173,1,1,'CREATION','Decompte','4','DECOMPTE N°2 du contrat 071 (SZTC) : 760 987,00 USD, transmis au comptable.','DESKTOP-GHOST','2026-10-29 13:30:28','2026-10-29 13:30:28',1,NULL,'{\"project_id\":1,\"contract_id\":4,\"line_no\":1,\"number\":\"DECOMPTE N°2\",\"operation_date\":\"2026-10-29\",\"gross_amount\":760987,\"advance_rate\":0.3,\"guarantee_rate\":0.05,\"status\":\"EN_ATTENTE\",\"observation\":null,\"submitted_by\":1,\"created_at\":\"2026-10-29T14:30:28.206100Z\",\"updated_at\":\"2026-10-29T14:30:28.206108Z\"}'),(174,1,6,'VALIDATION','Decompte','4','DECOMPTE N°2 du contrat 071 validé par le comptable le 29/10/2026.','DESKTOP-GHOST','2026-10-29 13:31:49','2026-10-29 13:31:49',1,'{\"status\":\"EN_ATTENTE\"}','{\"status\":\"VALIDE\",\"decided_by\":6,\"decided_at\":\"2026-10-29 14:31:49\",\"decision_date\":\"2026-10-29\",\"decision_comment\":null}'),(175,1,1,'CREATION_POSTE','Position','19','Poste CHAUFFEUR créé.','DESKTOP-GHOST','2026-10-29 13:37:52','2026-10-29 13:37:52',1,NULL,'{\"organizational_unit_id\":\"4\",\"name\":\"CHAUFFEUR\",\"description\":\"CHAFFEUR POOL-OUEST\",\"project_id\":1,\"is_active\":true,\"id\":19}'),(176,1,1,'CREATION_POSTE','Position','20','Poste CHAUFFEUR créé.','DESKTOP-GHOST','2026-10-29 13:38:12','2026-10-29 13:38:12',1,NULL,'{\"organizational_unit_id\":\"3\",\"name\":\"CHAUFFEUR\",\"description\":\"CHAUFFEUR POOL-EST\",\"project_id\":1,\"is_active\":true,\"id\":20}'),(177,1,1,'CREATION_POSTE','Position','21','Poste ENVIRONNEMENTALISTE créé.','DESKTOP-GHOST','2026-10-29 13:40:18','2026-10-29 13:40:18',1,NULL,'{\"organizational_unit_id\":\"4\",\"name\":\"ENVIRONNEMENTALISTE\",\"description\":\"ENVIRONNEMENTALISTE POOL-OUEST\",\"project_id\":1,\"is_active\":true,\"id\":21}'),(178,1,1,'CREATION_POSTE','Position','22','Poste ENVIRONNEMENTALISTE créé.','DESKTOP-GHOST','2026-10-29 13:40:38','2026-10-29 13:40:38',1,NULL,'{\"organizational_unit_id\":\"3\",\"name\":\"ENVIRONNEMENTALISTE\",\"description\":\"ENVIRONNEMENTALISTE POOL-EST\",\"project_id\":1,\"is_active\":true,\"id\":22}'),(179,1,1,'ETAT_FIGE','ReportSnapshot','1','État « Octobre 2026 » figé au 29/10/2026 (7 contrat(s)).','DESKTOP-GHOST','2026-10-29 13:45:01','2026-10-29 13:45:01',1,NULL,NULL),(180,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261029_144640.sql.gz.','DESKTOP-GHOST','2026-10-29 13:46:40','2026-10-29 13:46:40',1,NULL,NULL),(181,1,5,'CONNEXION','User','5','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 14:06:21','2026-10-29 14:06:21',NULL,NULL,NULL),(182,1,4,'CONNEXION','User','4','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-29 14:07:47','2026-10-29 14:07:47',NULL,NULL,NULL),(183,1,1,'REINITIALISATION_ADMIN','User','4','Mot de passe temporaire généré pour bukatitivalentin@gmail.com.','DESKTOP-GHOST','2026-10-29 14:38:57','2026-10-29 14:38:57',1,NULL,NULL),(184,1,1,'HABILITATIONS','User','4','Habilitations de bukatitivalentin@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-29 14:40:29','2026-10-29 14:40:29',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"role\":\"UTILISATEUR\"}'),(185,1,1,'HABILITATIONS','User','4','Habilitations de bukatitivalentin@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-30 07:30:10','2026-10-30 07:30:10',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"CA\",\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"CA\",\"role\":\"UTILISATEUR\"}'),(186,1,7,'DEMANDE_INSCRIPTION','User','7','Demande d’inscription de gracemukoko@gmail.com, en attente de validation.','DESKTOP-GHOST','2026-10-30 07:40:31','2026-10-30 07:40:31',NULL,NULL,NULL),(187,1,1,'APPROBATION_COMPTE','User','7','Compte gracemukoko@gmail.com approuvé (lecture seule). Ajustez les habilitations si nécessaire.','DESKTOP-GHOST','2026-10-30 07:41:09','2026-10-30 07:41:09',1,NULL,NULL),(188,1,1,'HABILITATIONS','User','7','Habilitations de gracemukoko@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-30 07:43:02','2026-10-30 07:43:02',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":true,\"can_view_situation\":true,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":false,\"can_manage_stock\":false,\"can_view_fleet\":false,\"can_manage_fleet\":false,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":null,\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":true,\"can_view_situation\":true,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":false,\"can_view_fleet\":true,\"can_manage_fleet\":false,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":null,\"role\":\"UTILISATEUR\"}'),(189,1,7,'CONNEXION','User','7','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-30 07:44:04','2026-10-30 07:44:04',NULL,NULL,NULL),(190,1,1,'HABILITATIONS','User','7','Habilitations de gracemukoko@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-30 07:51:46','2026-10-30 07:51:46',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":true,\"can_view_situation\":true,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":false,\"can_view_fleet\":true,\"can_manage_fleet\":false,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":null,\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":true,\"can_view_situation\":true,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":false,\"can_view_fleet\":true,\"can_manage_fleet\":false,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":null,\"role\":\"UTILISATEUR\"}'),(191,1,1,'HABILITATIONS','User','4','Habilitations de bukatitivalentin@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-30 07:53:51','2026-10-30 07:53:51',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"CA\",\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"CA\",\"role\":\"UTILISATEUR\"}'),(192,1,5,'CONNEXION','User','5','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-30 08:00:07','2026-10-30 08:00:07',NULL,NULL,NULL),(193,1,1,'HABILITATIONS','User','5','Habilitations de ruthmusikitela45@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-30 08:01:28','2026-10-30 08:01:28',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":true,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":null,\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":true,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"COMPTABLE\",\"role\":\"UTILISATEUR\"}'),(194,1,1,'HABILITATIONS','User','5','Habilitations de ruthmusikitela45@gmail.com mises à jour (utilisateur simple, consultation des pools au niveau national).','DESKTOP-GHOST','2026-10-30 08:03:23','2026-10-30 08:03:23',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":true,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"COMPTABLE\",\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":true,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":true,\"logistics_authority\":\"COMPTABLE\",\"role\":\"UTILISATEUR\"}'),(195,1,8,'DEMANDE_INSCRIPTION','User','8','Demande d’inscription de ghostimbaleva@gmail.com, en attente de validation.','DESKTOP-GHOST','2026-10-30 08:10:08','2026-10-30 08:10:08',NULL,NULL,NULL),(196,1,1,'APPROBATION_COMPTE','User','8','Compte ghostimbaleva@gmail.com approuvé (lecture seule). Ajustez les habilitations si nécessaire.','DESKTOP-GHOST','2026-10-30 08:10:30','2026-10-30 08:10:30',1,NULL,NULL),(197,1,1,'HABILITATIONS','User','8','Habilitations de ghostimbaleva@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-30 08:13:50','2026-10-30 08:13:50',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":true,\"can_view_situation\":true,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":false,\"can_manage_stock\":false,\"can_view_fleet\":false,\"can_manage_fleet\":false,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":null,\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":true,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":true,\"can_view_situation\":true,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"CA\",\"role\":\"UTILISATEUR\"}'),(198,1,8,'CONNEXION','User','8','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-30 08:14:47','2026-10-30 08:14:47',NULL,NULL,NULL),(199,1,1,'HABILITATIONS','User','8','Habilitations de ghostimbaleva@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-10-30 08:15:34','2026-10-30 08:15:34',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":true,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":true,\"can_view_situation\":true,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"CA\",\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":true,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts\":true,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"CA\",\"role\":\"UTILISATEUR\"}'),(200,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-30 09:01:56','2026-10-30 09:01:56',NULL,NULL,NULL),(201,1,1,'ALERTE_GARANTIE','PerformanceGuarantee','2','Alerte « 069 » envoyée manuellement. Message envoyé à ghostimbaleva@gmail.com, hemansimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-10-30 09:03:25','2026-10-30 09:03:25',1,NULL,NULL),(202,1,1,'ALERTE_GARANTIE','PerformanceGuarantee','5','Alerte « 072 » envoyée manuellement. Message envoyé à ghostimbaleva@gmail.com, hemansimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-10-30 09:03:34','2026-10-30 09:03:34',1,NULL,NULL),(203,1,1,'MODIFICATION_GARANTIE','PerformanceGuarantee','6','Ancienne valeur : Banque=; compte=; taux=5; début=26/03/2025; fin=26/03/2027; observation=. Nouvelle valeur : Banque=; taux=5; début=26/03/2025; fin=26/03/2027','DESKTOP-GHOST','2026-10-30 09:37:04','2026-10-30 09:37:04',1,NULL,NULL),(204,1,1,'COORDONNEES','Company','3','Coordonnées de l’entreprise CGC mises à jour.','DESKTOP-GHOST','2026-10-30 12:37:59','2026-10-30 12:37:59',1,NULL,NULL),(205,1,1,'COORDONNEES','Company','2','Coordonnées de l’entreprise SAGEC-KAT mises à jour.','DESKTOP-GHOST','2026-10-30 12:38:41','2026-10-30 12:38:41',1,NULL,NULL),(206,1,1,'COORDONNEES','Company','2','Coordonnées de l’entreprise SAGEC-KAT mises à jour.','DESKTOP-GHOST','2026-10-30 12:40:12','2026-10-30 12:40:12',1,NULL,NULL),(207,1,1,'COORDONNEES','Company','1','Coordonnées de l’entreprise SZTC mises à jour.','DESKTOP-GHOST','2026-10-30 12:42:05','2026-10-30 12:42:05',1,NULL,NULL),(208,1,1,'MODIFICATION_GARANTIE','PerformanceGuarantee','2','Ancienne valeur : Banque=Equity-BCDC; compte=11373839494943; taux=5; début=12/06/2025; fin=12/07/2026; observation=. Nouvelle valeur : Banque=Equity-BCDC; taux=5; début=12/06/2025; fin=12/07/2026','DESKTOP-GHOST','2026-10-30 12:45:09','2026-10-30 12:45:09',1,NULL,NULL),(209,1,1,'MODIFICATION_GARANTIE','PerformanceGuarantee','5','Ancienne valeur : Banque=173883199007; compte=SOFIBANK; taux=5; début=02/01/2025; fin=04/09/2026; observation=. Nouvelle valeur : Banque=SOFIBANK; taux=5; début=02/01/2025; fin=04/09/2026','DESKTOP-GHOST','2026-10-30 12:45:35','2026-10-30 12:45:35',1,NULL,NULL),(210,1,1,'MODIFICATION_GARANTIE','PerformanceGuarantee','6','Ancienne valeur : Banque=; compte=; taux=5; début=26/03/2025; fin=26/03/2027; observation=. Nouvelle valeur : Banque=EQUITY-BCDC; taux=5; début=26/03/2025; fin=26/03/2027','DESKTOP-GHOST','2026-10-30 12:46:24','2026-10-30 12:46:24',1,NULL,NULL),(211,1,1,'MODIFICATION_GARANTIE','PerformanceGuarantee','1','Ancienne valeur : Banque=; compte=; taux=5; début=03/04/2025; fin=03/04/2027; observation=. Nouvelle valeur : Banque=RAWBANK; taux=5; début=03/04/2025; fin=03/04/2027','DESKTOP-GHOST','2026-10-30 12:47:07','2026-10-30 12:47:07',1,NULL,NULL),(212,1,1,'MODIFICATION_GARANTIE','PerformanceGuarantee','4','Ancienne valeur : Banque=; compte=; taux=5; début=03/04/2025; fin=03/04/2027; observation=. Nouvelle valeur : Banque=SOLIDAIRE; taux=5; début=03/04/2025; fin=03/04/2027','DESKTOP-GHOST','2026-10-30 12:47:58','2026-10-30 12:47:58',1,NULL,NULL),(213,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261030_140423.sql.gz.','DESKTOP-GHOST','2026-10-30 13:04:23','2026-10-30 13:04:23',1,NULL,NULL),(214,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-30 14:25:35','2026-10-30 14:25:35',NULL,NULL,NULL),(215,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-10-31 16:00:08','2026-10-31 16:00:08',NULL,NULL,NULL),(216,1,1,'EXPORT_RAPPORT','Report','PRISE','Export Excel du rapport au 31/10/2026.','DESKTOP-GHOST','2026-10-31 16:20:04','2026-10-31 16:20:04',1,NULL,NULL),(217,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-11-02 12:47:41','2026-11-02 12:47:41',NULL,NULL,NULL),(218,1,1,'EXPORT_RAPPORT','Report','PRISE','Export Excel du rapport au 02/11/2026.','DESKTOP-GHOST','2026-11-02 13:10:47','2026-11-02 13:10:47',1,NULL,NULL),(219,1,1,'CREATION','Decompte','5','DECOMPTE N°2 du contrat 068 (SZTC) : 345 677,00 USD, transmis au comptable.','DESKTOP-GHOST','2026-11-02 13:13:44','2026-11-02 13:13:44',1,NULL,'{\"project_id\":1,\"contract_id\":1,\"line_no\":2,\"number\":\"DECOMPTE N°2\",\"operation_date\":\"2026-11-02\",\"gross_amount\":345677,\"advance_rate\":0.3,\"guarantee_rate\":0.05,\"status\":\"EN_ATTENTE\",\"observation\":null,\"submitted_by\":1,\"created_at\":\"2026-11-02T14:13:44.110707Z\",\"updated_at\":\"2026-11-02T14:13:44.110737Z\"}'),(220,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-11-02 13:30:45','2026-11-02 13:30:45',NULL,NULL,NULL),(221,1,1,'SAUVEGARDE_SQL','Database','PRISE','Sauvegarde manuelle : prise_20261102_150512.sql.gz.','DESKTOP-GHOST','2026-11-02 14:05:13','2026-11-02 14:05:13',1,NULL,NULL),(222,1,1,'PARAMETRES_SMTP','SmtpSetting','1','Paramètres SMTP enregistrés.','DESKTOP-GHOST','2026-11-02 14:30:25','2026-11-02 14:30:25',1,NULL,NULL),(223,1,1,'TEST_SMTP','SmtpSetting','1','Message envoyé à ghostimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com, hemansimbaleva@gmail.com.','DESKTOP-GHOST','2026-11-02 14:30:36','2026-11-02 14:30:36',1,NULL,NULL),(224,1,1,'PARAMETRES_SMTP','SmtpSetting','1','Paramètres SMTP enregistrés.','DESKTOP-GHOST','2026-11-02 14:32:09','2026-11-02 14:32:09',1,NULL,NULL),(225,1,1,'CREATION_POSTE','Position','23','Poste Ingénieur AEP créé.','DESKTOP-GHOST','2026-11-03 07:08:56','2026-11-03 07:08:56',1,NULL,'{\"organizational_unit_id\":\"4\",\"name\":\"Ingénieur AEP\",\"description\":\"INGENIEUR AEP KANANGA\",\"project_id\":1,\"is_active\":true,\"id\":23}'),(226,1,1,'CREATION_POSTE','Position','24','Poste Ingénieur AEP créé.','DESKTOP-GHOST','2026-11-03 07:09:26','2026-11-03 07:09:26',1,NULL,'{\"organizational_unit_id\":\"3\",\"name\":\"Ingénieur AEP\",\"description\":\"INGENIEUR AEP MBUJI-MAYI\",\"project_id\":1,\"is_active\":true,\"id\":24}'),(227,1,1,'MODIFICATION_POSTE','Position','15','Poste ESE MBUJI-MAYI modifié.','DESKTOP-GHOST','2026-11-03 07:10:06','2026-11-03 07:10:06',1,'{\"id\":15,\"project_id\":1,\"organizational_unit_id\":3,\"name\":\"ISE MBUJI-MAYI\",\"description\":\"INGENIEUR EN SUIVI-EVALUATION (POOL EST)\",\"is_active\":1}','{\"id\":15,\"project_id\":1,\"organizational_unit_id\":\"3\",\"name\":\"ESE MBUJI-MAYI\",\"description\":\"EXPERT EN SUIVI-EVALUATION (POOL EST)\",\"is_active\":1}'),(228,1,1,'MODIFICATION_POSTE','Position','14','Poste ESE KANANGA modifié.','DESKTOP-GHOST','2026-11-03 07:10:23','2026-11-03 07:10:23',1,'{\"id\":14,\"project_id\":1,\"organizational_unit_id\":4,\"name\":\"ISE KANANGA\",\"description\":\"INGENIEUR EN SUIVI-EVALUATION (POOL OUEST)\",\"is_active\":1}','{\"id\":14,\"project_id\":1,\"organizational_unit_id\":\"4\",\"name\":\"ESE KANANGA\",\"description\":\"EXPERT EN SUIVI-EVALUATION (POOL OUEST)\",\"is_active\":1}'),(229,1,1,'MODIFICATION_POSTE','Position','13','Poste C.P KANANGA modifié.','DESKTOP-GHOST','2026-11-03 07:10:49','2026-11-03 07:10:49',1,'{\"id\":13,\"project_id\":1,\"organizational_unit_id\":4,\"name\":\"C.A KANANGA\",\"description\":\"CHEF D\'ANTENNE KANANGA (POOL OUEST)\",\"is_active\":1}','{\"id\":13,\"project_id\":1,\"organizational_unit_id\":\"4\",\"name\":\"C.P KANANGA\",\"description\":\"CHEF DE POOL KANANGA (POOL OUEST)\",\"is_active\":1}'),(230,1,1,'MODIFICATION_POSTE','Position','16','Poste C.P MBUJI-MAYI modifié.','DESKTOP-GHOST','2026-11-03 07:11:14','2026-11-03 07:11:14',1,'{\"id\":16,\"project_id\":1,\"organizational_unit_id\":3,\"name\":\"C.A MBUJI-MAYI\",\"description\":\"CHEF D\'ANTENNE MBUJI-MAYI(POOL EST)\",\"is_active\":1}','{\"id\":16,\"project_id\":1,\"organizational_unit_id\":\"3\",\"name\":\"C.P MBUJI-MAYI\",\"description\":\"CHEF DE POOL MBUJI-MAYI(POOL EST)\",\"is_active\":1}'),(231,1,1,'SUPPRESSION','AlertRecipient','4','Destinataire du projet hemansimbaleva@gmail.com supprimé.','DESKTOP-GHOST','2026-11-03 07:16:19','2026-11-03 07:16:19',1,'{\"id\":4,\"project_id\":1,\"email\":\"hemansimbaleva@gmail.com\",\"name\":null,\"organizational_unit_id\":null,\"categories\":\"RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE\",\"is_active\":1,\"created_at\":\"2026-10-29 07:11:37\",\"updated_at\":\"2026-10-29 07:11:37\"}',NULL),(232,2,2,'CONNEXION','User','2','Ouverture de session web dans le projet PREDIRE.','DESKTOP-GHOST','2026-11-03 07:17:59','2026-11-03 07:17:59',NULL,NULL,NULL),(233,2,2,'CREATION','AlertRecipient','6','Destinataire du projet germainenkamba@gmail.com ajouté.','DESKTOP-GHOST','2026-11-03 07:19:22','2026-11-03 07:19:22',2,NULL,'{\"email\":\"germainenkamba@gmail.com\",\"name\":null,\"categories\":\"RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE\"}'),(234,2,2,'CREATION','AlertRecipient','7','Destinataire du projet hermaimbaleva@gmail.com ajouté.','DESKTOP-GHOST','2026-11-03 07:20:06','2026-11-03 07:20:06',2,NULL,'{\"email\":\"hermaimbaleva@gmail.com\",\"name\":null,\"categories\":\"RETARD,GARANTIE,DECOMPTE,STOCK,CHARROI,GROUPE\"}'),(235,2,2,'TEST_SMTP','SmtpSetting','2','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c4cfd2d9b69sm12765466b.10 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-11-03 07:20:12','2026-11-03 07:20:12',2,NULL,NULL),(236,2,2,'PARAMETRES_SMTP','SmtpSetting','2','Paramètres SMTP enregistrés.','DESKTOP-GHOST','2026-11-03 07:20:38','2026-11-03 07:20:38',2,NULL,NULL),(237,2,2,'TEST_SMTP','SmtpSetting','2','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c4cebf3cadbsm62851566b.50 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-11-03 07:20:44','2026-11-03 07:20:44',2,NULL,NULL),(238,2,2,'TEST_SMTP','SmtpSetting','2','Échec de l’envoi : Failed to authenticate on SMTP server with username \"hermansimbaleva20@gmail.com\" using the following authenticators: \"LOGIN\", \"PLAIN\", \"XOAUTH2\". Authenticator \"LOGIN\" returned \"Expected response code \"235\" but got code \"535\", with message \"535-5.7.8 Username and Password not accepted. For more information, go to\r\n535 5.7.8  https://support.google.com/mail/?p=BadCredentials a640c23a62f3a-c4cebebfabasm62965466b.28 - gsmtp\".\". Authenticator \"PLAIN\" returned \"Expected response code \"235\" but got empty code.\". Authenticator \"XOAUTH2\" returned \"Expected response code \"235\" but got empty code.\".','DESKTOP-GHOST','2026-11-03 07:22:12','2026-11-03 07:22:12',2,NULL,NULL),(239,2,2,'PARAMETRES_SMTP','SmtpSetting','2','Paramètres SMTP enregistrés.','DESKTOP-GHOST','2026-11-03 07:22:20','2026-11-03 07:22:20',2,NULL,NULL),(240,2,2,'TEST_SMTP','SmtpSetting','2','Message envoyé à germainenkamba@gmail.com, hermaimbaleva@gmail.com.','DESKTOP-GHOST','2026-11-03 07:22:35','2026-11-03 07:22:35',2,NULL,NULL),(241,1,NULL,'ALERTE_DECOMPTE','AlertDispatch','DECOMPTE','[PRISE] Décomptes à valider : 1 alerte(s) — envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 08:00:23','2026-11-03 08:00:23',NULL,NULL,NULL),(242,1,NULL,'ALERTE_CHARROI','AlertDispatch','CHARROI','[PRISE] Charroi (réservoir, entretien, assurance, carnet) : 3 alerte(s) — envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 08:00:29','2026-11-03 08:00:29',NULL,NULL,NULL),(243,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','2','[PRISE II] Garantie de bonne exécution n° RE16472 — contrat n° 069 — alerte de retard — relance n° 1 à ghostimbaleva@gmail.com : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com.','DESKTOP-GHOST','2026-11-03 08:00:34','2026-11-03 08:00:34',NULL,NULL,NULL),(244,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','5','[PRISE II] Garantie de bonne exécution n° RB-245-12 — contrat n° 072 — alerte de retard — relance n° 1 à germainenkamba@gmail.com : envoyé (envoi planifié). Message envoyé à germainenkamba@gmail.com.','DESKTOP-GHOST','2026-11-03 08:00:40','2026-11-03 08:00:40',NULL,NULL,NULL),(245,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','6','[PRISE II] Garantie de bonne exécution n° RB-906-342 — contrat n° 073 — alerte de vigilance — relance n° 1 à hermaimbaleva@gmail.com : envoyé (envoi planifié). Message envoyé à hermaimbaleva@gmail.com.','DESKTOP-GHOST','2026-11-03 08:00:45','2026-11-03 08:00:45',NULL,NULL,NULL),(246,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','1','[PRISE II] Garantie de bonne exécution n° RE-675-400 — contrat n° 068 — alerte de vigilance — relance n° 1 à germainenkamba@gmail.com : envoyé (envoi planifié). Message envoyé à germainenkamba@gmail.com.','DESKTOP-GHOST','2026-11-03 08:00:49','2026-11-03 08:00:49',NULL,NULL,NULL),(247,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','4','[PRISE II] Garantie de bonne exécution n° NT-649-126 — contrat n° 071 — alerte de vigilance — relance n° 1 à germainenkamba@gmail.com : envoyé (envoi planifié). Message envoyé à germainenkamba@gmail.com.','DESKTOP-GHOST','2026-11-03 08:00:56','2026-11-03 08:00:56',NULL,NULL,NULL),(248,1,NULL,'ALERTE_PERSONNEL','PerformanceGuarantee','2','[PRISE II] Pour attention — garantie n° RE16472 du contrat n° 069 (retard) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 08:01:02','2026-11-03 08:01:02',NULL,NULL,NULL),(249,1,NULL,'ALERTE_PERSONNEL','PerformanceGuarantee','5','[PRISE II] Pour attention — garantie n° RB-245-12 du contrat n° 072 (retard) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 08:01:09','2026-11-03 08:01:09',NULL,NULL,NULL),(250,1,NULL,'ALERTE_PERSONNEL','PerformanceGuarantee','6','[PRISE II] Pour attention — garantie n° RB-906-342 du contrat n° 073 (vigilance) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 08:01:15','2026-11-03 08:01:15',NULL,NULL,NULL),(251,1,NULL,'ALERTE_PERSONNEL','PerformanceGuarantee','1','[PRISE II] Pour attention — garantie n° RE-675-400 du contrat n° 068 (vigilance) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 08:01:20','2026-11-03 08:01:20',NULL,NULL,NULL),(252,1,NULL,'ALERTE_PERSONNEL','PerformanceGuarantee','4','[PRISE II] Pour attention — garantie n° NT-649-126 du contrat n° 071 (vigilance) — rappel au personnel du projet : échec (envoi planifié). Échec de l’envoi : Connection to \"smtp.gmail.com:587\" timed out.','DESKTOP-GHOST','2026-11-03 08:01:48','2026-11-03 08:01:48',NULL,NULL,NULL),(253,1,NULL,'ALERTE_PERSONNEL','Contract','1','[PRISE II] Pour attention — contrat n° 068 (retard) — rappel au personnel du projet : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-03 08:01:48','2026-11-03 08:01:48',NULL,NULL,NULL),(254,1,NULL,'ALERTE_PERSONNEL','Contract','2','[PRISE II] Pour attention — contrat n° 069 (retard) — rappel au personnel du projet : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-03 08:01:48','2026-11-03 08:01:48',NULL,NULL,NULL),(255,1,NULL,'ALERTE_PERSONNEL','Contract','3','[PRISE II] Pour attention — contrat n° 070 (retard) — rappel au personnel du projet : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-03 08:01:48','2026-11-03 08:01:48',NULL,NULL,NULL),(256,1,NULL,'ALERTE_PERSONNEL','Contract','4','[PRISE II] Pour attention — contrat n° 071 (retard) — rappel au personnel du projet : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-03 08:01:48','2026-11-03 08:01:48',NULL,NULL,NULL),(257,1,NULL,'ALERTE_PERSONNEL','Contract','5','[PRISE II] Pour attention — contrat n° 072 (retard) — rappel au personnel du projet : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-03 08:01:48','2026-11-03 08:01:48',NULL,NULL,NULL),(258,1,NULL,'ALERTE_PERSONNEL','Contract','6','[PRISE II] Pour attention — contrat n° 073 (retard) — rappel au personnel du projet : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-03 08:01:48','2026-11-03 08:01:48',NULL,NULL,NULL),(259,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-11-03 08:11:09','2026-11-03 08:11:09',NULL,NULL,NULL),(260,1,6,'CONNEXION','User','6','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-11-03 08:11:36','2026-11-03 08:11:36',NULL,NULL,NULL),(261,1,6,'VALIDATION','Decompte','5','DECOMPTE N°2 du contrat 068 validé par le comptable le 03/11/2026.','DESKTOP-GHOST','2026-11-03 08:11:53','2026-11-03 08:11:53',1,'{\"status\":\"EN_ATTENTE\"}','{\"status\":\"VALIDE\",\"decided_by\":6,\"decided_at\":\"2026-11-03 09:11:53\",\"decision_date\":\"2026-11-03\",\"decision_comment\":null}'),(262,1,1,'MODIFICATION','AlertTemplate','GARANTIE_PERSONNEL','Modèle « Personnel du projet — garantie à suivre » modifié.','DESKTOP-GHOST','2026-11-03 08:24:49','2026-11-03 08:24:49',1,'{\"subject\":\"[{projet}] Pour attention — garantie n° {numero_garantie} du contrat n° {contrat} ({niveau})\",\"body\":\"Chers collègues,\\n\\nNous attirons votre attention sur la garantie de bonne exécution n° {numero_garantie} du contrat n° {contrat} ({entreprise}, banque {banque}), en situation de {niveau} : {jours_consommes} de la période consommés, échéance le {echeance}.\\n\\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\\n\\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi {projet}.\"}','{\"subject\":\"[{projet}] Pour attention — garantie n° {numero_garantie} du contrat n° {contrat} ({niveau})\",\"body\":\"Chers collègues,\\n\\nNous attirons votre attention sur la garantie de bonne exécution n° {numero_garantie} du contrat n° {contrat} ({entreprise}, banque {banque}), en situation de {niveau} : {jours_consommes} de la période consommés, échéance le {echeance}.\\n\\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à la prolongation ou au renouvellement de la garantie.\\n\\nCoordination du projet {projet}.\"}'),(263,1,1,'MODIFICATION','AlertRecipient','3','Destinataire du projet hermansimbaleva20@gmail.com modifié.','DESKTOP-GHOST','2026-11-03 08:47:08','2026-11-03 08:47:08',1,'{\"email\":\"hermansimbaleva20@gmail.com\",\"name\":null,\"position_id\":null}','{\"email\":\"hermansimbaleva20@gmail.com\",\"name\":\"Hermans IMBALEVA\",\"position_id\":7}'),(264,1,NULL,'ALERTE_PERSONNEL','PerformanceGuarantee','4','[PRISE II] Pour attention — garantie n° NT-649-126 du contrat n° 071 (vigilance) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 09:00:08','2026-11-03 09:00:08',NULL,NULL,NULL),(265,1,NULL,'ALERTE_PERSONNEL','Contract','1','[PRISE II] Pour attention — contrat n° 068 (retard) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 09:00:17','2026-11-03 09:00:17',NULL,NULL,NULL),(266,1,NULL,'ALERTE_PERSONNEL','Contract','2','[PRISE II] Pour attention — contrat n° 069 (retard) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 09:00:23','2026-11-03 09:00:23',NULL,NULL,NULL),(267,1,NULL,'ALERTE_PERSONNEL','Contract','3','[PRISE II] Pour attention — contrat n° 070 (retard) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 09:00:29','2026-11-03 09:00:29',NULL,NULL,NULL),(268,1,NULL,'ALERTE_PERSONNEL','Contract','4','[PRISE II] Pour attention — contrat n° 071 (retard) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 09:00:38','2026-11-03 09:00:38',NULL,NULL,NULL),(269,1,NULL,'ALERTE_PERSONNEL','Contract','5','[PRISE II] Pour attention — contrat n° 072 (retard) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 09:00:47','2026-11-03 09:00:47',NULL,NULL,NULL),(270,1,NULL,'ALERTE_PERSONNEL','Contract','6','[PRISE II] Pour attention — contrat n° 073 (retard) — rappel au personnel du projet : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com, hemaimbaleva@gmail.com, hermaimbaleva@gmail.com, hermansimbaleva20@gmail.com.','DESKTOP-GHOST','2026-11-03 09:00:54','2026-11-03 09:00:54',NULL,NULL,NULL),(271,1,1,'MODIFICATION','AlertTemplate','DECOMPTE_RAPPEL','Modèle « Chef de cellule infrastructures — décompte à valider » modifié.','DESKTOP-GHOST','2026-11-03 09:04:23','2026-11-03 09:04:23',1,'{\"subject\":\"[{projet}] Rappel — {decompte} du contrat n° {contrat} à valider\",\"body\":\"Bonjour,\\n\\nLe {decompte} du contrat n° {contrat} ({entreprise}), d\'un montant de {montant} USD, vous a été transmis le {transmis_le} par {saisi_par} et attend toujours votre décision.\\n\\nMerci de le valider ou de le rejeter dans l\'application de suivi : {lien}\\n\\nCe rappel vous est envoyé chaque jour tant que le décompte n\'a pas été traité.\\n\\nApplication de suivi {projet}\"}','{\"subject\":\"[{projet}] Rappel — {decompte} du contrat n° {contrat} à valider\",\"body\":\"Bonjour,\\n\\nLe {decompte} du contrat n° {contrat} ({entreprise}), d\'un montant de {montant} USD, vous a été transmis le {transmis_le} par {saisi_par} et attend toujours votre décision.\\n\\nMerci de le valider ou de le rejeter dans l\'application de suivi : {lien}\\n\\nCe rappel vous est envoyé chaque jour tant que le décompte n\'a pas été traité.\\n\\nCoordination du projet {projet}\"}'),(272,1,1,'MODIFICATION','AlertTemplate','DECOMPTE_RAPPEL','Modèle « Chef de cellule infrastructures — décompte à valider » rétabli par défaut.','DESKTOP-GHOST','2026-11-03 09:04:30','2026-11-03 09:04:30',1,'{\"subject\":\"[{projet}] Rappel — {decompte} du contrat n° {contrat} à valider\",\"body\":\"Bonjour,\\n\\nLe {decompte} du contrat n° {contrat} ({entreprise}), d\'un montant de {montant} USD, vous a été transmis le {transmis_le} par {saisi_par} et attend toujours votre décision.\\n\\nMerci de le valider ou de le rejeter dans l\'application de suivi : {lien}\\n\\nCe rappel vous est envoyé chaque jour tant que le décompte n\'a pas été traité.\\n\\nCoordination du projet {projet}\"}','{\"subject\":\"[{projet}] Rappel — {decompte} du contrat n° {contrat} à valider\",\"body\":\"Bonjour,\\n\\nLe {decompte} du contrat n° {contrat} ({entreprise}), d\'un montant de {montant} USD, vous a été transmis le {transmis_le} par {saisi_par} et attend toujours votre décision.\\n\\nMerci de le valider ou de le rejeter dans l\'application de suivi : {lien}\\n\\nCe rappel vous est envoyé chaque jour tant que le décompte n\'a pas été traité.\\n\\nApplication de suivi {projet}\"}'),(273,1,1,'MODIFICATION','AlertTemplate','DECOMPTE_RAPPEL','Modèle « Chef de cellule infrastructures — décompte à valider » modifié.','DESKTOP-GHOST','2026-11-03 09:05:10','2026-11-03 09:05:10',1,'{\"subject\":\"[{projet}] Rappel — {decompte} du contrat n° {contrat} à valider\",\"body\":\"Bonjour,\\n\\nLe {decompte} du contrat n° {contrat} ({entreprise}), d\'un montant de {montant} USD, vous a été transmis le {transmis_le} par {saisi_par} et attend toujours votre décision.\\n\\nMerci de le valider ou de le rejeter dans l\'application de suivi : {lien}\\n\\nCe rappel vous est envoyé chaque jour tant que le décompte n\'a pas été traité.\\n\\nApplication de suivi {projet}\"}','{\"subject\":\"[{projet}] Rappel — {decompte} du contrat n° {contrat} à valider\",\"body\":\"Bonjour,\\n\\nLe {decompte} du contrat n° {contrat} ({entreprise}), d\'un montant de {montant} USD, vous a été transmis le {transmis_le} par {saisi_par} et attend toujours votre décision.\\n\\nMerci de le valider ou de le rejeter dans l\'application de suivi : {lien}\\n\\nCe rappel vous est envoyé chaque jour tant que le décompte n\'a pas été traité.\\n\\nCoordination du projet {projet}\"}'),(274,1,1,'MODIFICATION','AlertTemplate','CONTRAT_PERSONNEL','Modèle « Personnel du projet — contrat à suivre » modifié.','DESKTOP-GHOST','2026-11-03 09:06:49','2026-11-03 09:06:49',1,'{\"subject\":\"[{projet}] Pour attention — contrat n° {contrat} ({niveau})\",\"body\":\"Chers collègues,\\n\\nNous attirons votre attention sur le contrat n° {contrat} ({entreprise}), en situation de {niveau} : avancement physique de {avancement} pour {jours_consommes} du délai consommé, fin prévue le {date_fin}.\\n\\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\\n\\nCe rappel vous est envoyé une fois par semaine par l\'application de suivi {projet}.\"}','{\"subject\":\"[{projet}] Pour attention — contrat n° {contrat} ({niveau})\",\"body\":\"Chers collègues,\\n\\nNous attirons votre attention sur le contrat n° {contrat} ({entreprise}), en situation de {niveau} : avancement physique de {avancement} pour {jours_consommes} du délai consommé, fin prévue le {date_fin}.\\n\\nMerci d\'accorder une attention particulière à ce dossier jusqu\'à l\'amélioration de l\'avancement physique.\\n\\nCoordination du projet {projet}.\"}'),(275,1,1,'HABILITATIONS','User','3','Habilitations de jorcelinmikado@gmail.com mises à jour (utilisateur simple).','DESKTOP-GHOST','2026-11-03 13:36:18','2026-11-03 13:36:18',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":true,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":true,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":false,\"can_view_fleet\":true,\"can_manage_fleet\":false,\"can_authorize_fleet\":false,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":null,\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":true,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":true,\"can_view_reports\":false,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":false,\"can_view_fleet\":true,\"can_manage_fleet\":false,\"can_authorize_fleet\":false,\"can_validate_decomptes\":true,\"can_view_pools\":false,\"logistics_authority\":null,\"role\":\"UTILISATEUR\"}'),(276,1,1,'CREATION','ContractPayment','7','Paiement du contrat 068, date 03/11/2026, montant 153 912,85.','DESKTOP-GHOST','2026-11-03 13:40:43','2026-11-03 13:40:43',1,NULL,NULL),(277,1,1,'CONNEXION','User','1','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-11-04 07:37:12','2026-11-04 07:37:12',NULL,NULL,NULL),(278,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','2','[PRISE II] Garantie de bonne exécution n° RE16472 — contrat n° 069 — alerte de retard — relance n° 2 à ghostimbaleva@gmail.com : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-04 07:41:43','2026-11-04 07:41:43',NULL,NULL,NULL),(279,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','5','[PRISE II] Garantie de bonne exécution n° RB-245-12 — contrat n° 072 — alerte de retard — relance n° 2 à germainenkamba@gmail.com : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-04 07:41:43','2026-11-04 07:41:43',NULL,NULL,NULL),(280,1,NULL,'ALERTE_RETARD','Contract','1','[PRISE II] Contrat n° 068 — alerte de retard à germainenkamba@gmail.com : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-04 07:41:43','2026-11-04 07:41:43',NULL,NULL,NULL),(281,1,NULL,'ALERTE_RETARD','Contract','2','[PRISE II] Contrat n° 069 — alerte de retard à ghostimbaleva@gmail.com : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-04 07:41:43','2026-11-04 07:41:43',NULL,NULL,NULL),(282,1,NULL,'ALERTE_RETARD','Contract','3','[PRISE II] Contrat n° 070 — alerte de retard à ghostimbaleva@gmail.com : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-04 07:41:43','2026-11-04 07:41:43',NULL,NULL,NULL),(283,1,NULL,'ALERTE_RETARD','Contract','4','[PRISE II] Contrat n° 071 — alerte de retard à germainenkamba@gmail.com : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-04 07:41:43','2026-11-04 07:41:43',NULL,NULL,NULL),(284,1,NULL,'ALERTE_RETARD','Contract','5','[PRISE II] Contrat n° 072 — alerte de retard à germainenkamba@gmail.com : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-04 07:41:43','2026-11-04 07:41:43',NULL,NULL,NULL),(285,1,NULL,'ALERTE_RETARD','Contract','6','[PRISE II] Contrat n° 073 — alerte de retard à hermaimbaleva@gmail.com : échec (envoi planifié). Échec de l’envoi : Connection could not be established with host \"smtp.gmail.com:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for smtp.gmail.com failed: Hôte inconnu','DESKTOP-GHOST','2026-11-04 07:41:43','2026-11-04 07:41:43',NULL,NULL,NULL),(286,1,1,'CREATION','Decompte','6','DECOMPTE N°1 du contrat 070 (SAGEC-KAT) : 450 567,00 USD, transmis au chef de cellule infrastructures.','DESKTOP-GHOST','2026-11-04 07:55:11','2026-11-04 07:55:11',1,NULL,'{\"project_id\":1,\"contract_id\":3,\"line_no\":1,\"number\":\"DECOMPTE N°1\",\"operation_date\":\"2026-11-04\",\"gross_amount\":450567,\"advance_rate\":0.3,\"guarantee_rate\":0.05,\"status\":\"EN_ATTENTE\",\"observation\":null,\"submitted_by\":1,\"created_at\":\"2026-11-04T07:55:11.821782Z\",\"updated_at\":\"2026-11-04T07:55:11.821817Z\"}'),(287,1,1,'HABILITATIONS','User','6','Habilitations de glody@gmail.com mises à jour (utilisateur simple, consultation des pools au niveau national).','DESKTOP-GHOST','2026-11-04 07:59:57','2026-11-04 07:59:57',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":false,\"can_view_fleet\":true,\"can_manage_fleet\":false,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":false,\"logistics_authority\":\"COMPTABLE\",\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts\":false,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":false,\"can_manage_stock\":false,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":true,\"can_view_pools\":true,\"logistics_authority\":\"COMPTABLE\",\"role\":\"UTILISATEUR\"}'),(288,1,5,'CONNEXION','User','5','Ouverture de session web dans le projet PRISE.','DESKTOP-GHOST','2026-11-04 08:08:03','2026-11-04 08:08:03',NULL,NULL,NULL),(289,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','2','[PRISE II] Garantie de bonne exécution n° RE16472 — contrat n° 069 — alerte de retard — relance n° 2 à ghostimbaleva@gmail.com : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com.','DESKTOP-GHOST','2026-11-04 08:41:51','2026-11-04 08:41:51',NULL,NULL,NULL),(290,1,NULL,'ALERTE_GARANTIE','PerformanceGuarantee','5','[PRISE II] Garantie de bonne exécution n° RB-245-12 — contrat n° 072 — alerte de retard — relance n° 2 à germainenkamba@gmail.com : envoyé (envoi planifié). Message envoyé à germainenkamba@gmail.com.','DESKTOP-GHOST','2026-11-04 08:41:56','2026-11-04 08:41:56',NULL,NULL,NULL),(291,1,NULL,'ALERTE_RETARD','Contract','1','[PRISE II] Contrat n° 068 — alerte de retard à germainenkamba@gmail.com : envoyé (envoi planifié). Message envoyé à germainenkamba@gmail.com.','DESKTOP-GHOST','2026-11-04 08:42:02','2026-11-04 08:42:02',NULL,NULL,NULL),(292,1,NULL,'ALERTE_RETARD','Contract','2','[PRISE II] Contrat n° 069 — alerte de retard à ghostimbaleva@gmail.com : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com.','DESKTOP-GHOST','2026-11-04 08:42:09','2026-11-04 08:42:09',NULL,NULL,NULL),(293,1,NULL,'ALERTE_RETARD','Contract','3','[PRISE II] Contrat n° 070 — alerte de retard à ghostimbaleva@gmail.com : envoyé (envoi planifié). Message envoyé à ghostimbaleva@gmail.com.','DESKTOP-GHOST','2026-11-04 08:42:15','2026-11-04 08:42:15',NULL,NULL,NULL),(294,1,NULL,'ALERTE_RETARD','Contract','4','[PRISE II] Contrat n° 071 — alerte de retard à germainenkamba@gmail.com : envoyé (envoi planifié). Message envoyé à germainenkamba@gmail.com.','DESKTOP-GHOST','2026-11-04 08:42:22','2026-11-04 08:42:22',NULL,NULL,NULL),(295,1,NULL,'ALERTE_RETARD','Contract','5','[PRISE II] Contrat n° 072 — alerte de retard à germainenkamba@gmail.com : envoyé (envoi planifié). Message envoyé à germainenkamba@gmail.com.','DESKTOP-GHOST','2026-11-04 08:42:27','2026-11-04 08:42:27',NULL,NULL,NULL),(296,1,NULL,'ALERTE_RETARD','Contract','6','[PRISE II] Contrat n° 073 — alerte de retard à hermaimbaleva@gmail.com : envoyé (envoi planifié). Message envoyé à hermaimbaleva@gmail.com.','DESKTOP-GHOST','2026-11-04 08:42:32','2026-11-04 08:42:32',NULL,NULL,NULL),(297,1,1,'HABILITATIONS','User','5','Habilitations de ruthmusikitela45@gmail.com mises à jour (utilisateur simple, consultation des pools au niveau national).','DESKTOP-GHOST','2026-11-04 08:55:20','2026-11-04 08:55:20',1,'{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":false,\"can_view_alerts_contracts\":true,\"can_view_alerts_guarantees\":true,\"can_view_alerts_logistics\":true,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":true,\"logistics_authority\":\"COMPTABLE\",\"role\":\"UTILISATEUR\"}','{\"can_manage_settings\":false,\"can_manage_users\":false,\"can_delete_contracts\":false,\"can_manage_contracts\":false,\"can_manage_companies\":false,\"can_manage_progress\":false,\"can_manage_payments\":false,\"can_view_reports\":true,\"can_view_alerts_contracts\":false,\"can_view_alerts_guarantees\":false,\"can_view_alerts_logistics\":true,\"can_view_situation\":false,\"can_view_archives\":false,\"can_manage_guarantees\":false,\"can_view_stock\":true,\"can_manage_stock\":true,\"can_view_fleet\":true,\"can_manage_fleet\":true,\"can_authorize_fleet\":true,\"can_validate_decomptes\":false,\"can_view_pools\":true,\"logistics_authority\":\"COMPTABLE\",\"role\":\"UTILISATEUR\"}');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observation` text COLLATE utf8mb4_unicode_ci,
  `guarantee_bank` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantee_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guarantee_observation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_project_id_name_unique` (`project_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,1,'SZTC','Kinshasa','','germainenkamba@gmail.com','','','','','2026-10-15 08:58:09','2026-10-30 12:42:05'),(2,1,'SAGEC-KAT','Kinshasa','0829443004','ghostimbaleva@gmail.com','','','','','2026-10-15 08:58:58','2026-10-30 12:40:12'),(3,1,'CGC','Kinshasa','','hermaimbaleva@gmail.com','','','','','2026-10-15 09:00:05','2026-10-30 12:37:59');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_amendments`
--

DROP TABLE IF EXISTS `contract_amendments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_amendments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `duration_days` int NOT NULL DEFAULT '0',
  `added_months` int unsigned NOT NULL DEFAULT '0',
  `previous_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_amendments_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_amendments`
--

LOCK TABLES `contract_amendments` WRITE;
/*!40000 ALTER TABLE `contract_amendments` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_amendments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_decomptes`
--

DROP TABLE IF EXISTS `contract_decomptes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_decomptes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `contract_id` bigint unsigned NOT NULL,
  `line_no` int unsigned NOT NULL,
  `number` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kind` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DECOMPTE',
  `operation_date` date NOT NULL,
  `gross_amount` decimal(15,2) NOT NULL,
  `advance_rate` decimal(6,4) NOT NULL DEFAULT '0.0000',
  `guarantee_rate` decimal(6,4) NOT NULL DEFAULT '0.0000',
  `status` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EN_ATTENTE',
  `observation` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_by` bigint unsigned DEFAULT NULL,
  `decided_by` bigint unsigned DEFAULT NULL,
  `decided_at` timestamp NULL DEFAULT NULL,
  `decision_date` date DEFAULT NULL,
  `decision_comment` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `decomptes_contract_line_unique` (`contract_id`,`line_no`),
  KEY `decomptes_project_status_idx` (`project_id`,`status`),
  CONSTRAINT `contract_decomptes_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contract_decomptes_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_decomptes`
--

LOCK TABLES `contract_decomptes` WRITE;
/*!40000 ALTER TABLE `contract_decomptes` DISABLE KEYS */;
INSERT INTO `contract_decomptes` VALUES (1,1,2,1,'DECOMPTE N°1','DECOMPTE','2026-10-28',450340.00,0.3000,0.0500,'VALIDE',NULL,1,6,'2026-10-29 10:33:54','2026-10-29',NULL,'2026-10-28 16:58:45','2026-10-29 10:33:54'),(2,1,2,2,'DECOMPTE N°2','DECOMPTE','2026-10-28',1200345.00,0.3000,0.0500,'VALIDE',NULL,3,6,'2026-10-29 10:33:58','2026-10-29',NULL,'2026-10-28 17:07:47','2026-10-29 10:33:58'),(3,1,1,1,'DECOMPTE N°1','DECOMPTE','2026-10-29',236789.00,0.3000,0.0500,'VALIDE',NULL,1,6,'2026-10-29 09:11:21','2026-10-29',NULL,'2026-10-29 09:01:21','2026-10-29 09:11:21'),(4,1,4,1,'DECOMPTE N°2','DECOMPTE','2026-10-29',760987.00,0.3000,0.0500,'VALIDE',NULL,1,6,'2026-10-29 13:31:49','2026-10-29',NULL,'2026-10-29 13:30:28','2026-10-29 13:31:49'),(5,1,1,2,'DECOMPTE N°2','DECOMPTE','2026-11-02',345677.00,0.3000,0.0500,'VALIDE',NULL,1,6,'2026-11-03 08:11:53','2026-11-03',NULL,'2026-11-02 13:13:44','2026-11-03 08:11:53'),(6,1,3,1,'DECOMPTE N°1','DECOMPTE','2026-11-04',450567.00,0.3000,0.0500,'EN_ATTENTE',NULL,1,NULL,NULL,NULL,NULL,'2026-11-04 07:55:11','2026-11-04 07:55:11');
/*!40000 ALTER TABLE `contract_decomptes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_documents`
--

DROP TABLE IF EXISTS `contract_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `original_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storage_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint unsigned NOT NULL DEFAULT '0',
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_documents_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_documents`
--

LOCK TABLES `contract_documents` WRITE;
/*!40000 ALTER TABLE `contract_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_payments`
--

DROP TABLE IF EXISTS `contract_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `decompte_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contract_payments_decompte_id_unique` (`decompte_id`),
  KEY `contract_payments_contract_id_foreign` (`contract_id`),
  CONSTRAINT `contract_payments_decompte_id_foreign` FOREIGN KEY (`decompte_id`) REFERENCES `contract_decomptes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_payments`
--

LOCK TABLES `contract_payments` WRITE;
/*!40000 ALTER TABLE `contract_payments` DISABLE KEYS */;
INSERT INTO `contract_payments` VALUES (1,1,'2026-09-30',352268.82,'','','2026-10-16 12:29:46','2026-10-16 12:29:46',NULL),(2,1,'2026-10-29',153912.85,'DECOMPTE N°1','Montant payé du décompte validé par le comptable.','2026-10-29 09:11:21','2026-10-29 09:11:21',3),(3,2,'2026-10-28',292721.00,'DECOMPTE N°1','Montant payé du décompte validé par le comptable.','2026-10-29 10:33:54','2026-10-29 10:33:54',1),(4,2,'2026-10-28',780224.25,'DECOMPTE N°2','Montant payé du décompte validé par le comptable.','2026-10-29 10:33:58','2026-10-29 10:33:58',2),(5,4,'2026-10-29',494641.55,'DECOMPTE N°2','Montant payé du décompte validé par le comptable.','2026-10-29 13:31:49','2026-10-29 13:31:49',4),(6,1,'2026-11-02',224690.05,'DECOMPTE N°2','Montant payé du décompte validé par le comptable.','2026-11-03 08:11:53','2026-11-03 08:11:53',5),(7,1,'2026-11-03',153912.85,'','','2026-11-03 13:40:43','2026-11-03 13:40:43',NULL);
/*!40000 ALTER TABLE `contract_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_sites`
--

DROP TABLE IF EXISTS `contract_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_sites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `province` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `work_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` decimal(15,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_sites_contract_id_foreign` (`contract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_sites`
--

LOCK TABLES `contract_sites` WRITE;
/*!40000 ALTER TABLE `contract_sites` DISABLE KEYS */;
INSERT INTO `contract_sites` VALUES (1,1,'Kasaï Oriental','Système d’AEP','MUKEBA','Un Forage, un CE de 100 m3, 3395 de tuyaux PEHD de distribution et refoulement et 12 BF et 3 BP;',1.00,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(2,1,'Kasaï Oriental','Système d’AEP','BENA-KABIMBA','Un Forage, un CE de 100 m3, 4790 ml de tuyaux PEHD de distribution et refoulement et 15 BF et 9 BP;',1.00,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(3,1,'Kasaï Oriental','Système d’AEP','MULOWAYI','Un Forage, un CE de 30 m3, 5490 ml de tuyaux PEHD de distribution et refoulement et 4 BF ;',1.00,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(4,1,'Kasaï Oriental','Système d’AEP','TSHILUNDU','Un Forage, un CE de 100 m3, 3395 ml de tuyaux PEHD de distribution et refoulement et 12 BF et 3 BP;',1.00,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(5,2,'Sankuru','Système d’AEP','DJALO','Système d’AEP',1.00,'2026-10-15 12:57:07','2026-10-16 08:08:45'),(6,2,'Sankuru','Système d’AEP','BAKWA-BUMBA','Système d’AEP',1.00,'2026-10-15 12:57:07','2026-10-16 08:08:45'),(7,2,'Sankuru','Système d’AEP','MUKUMARI','Système d’AEP',1.00,'2026-10-15 12:57:07','2026-10-16 08:08:45'),(8,3,'Maniema','Système d’AEP','DIFUMA 2','Système d’AEP',1.00,'2026-10-15 13:20:10','2026-10-16 08:09:14'),(9,3,'Maniema','Système d’AEP','LOWE','Système d’AEP',1.00,'2026-10-15 13:20:10','2026-10-16 08:09:14'),(10,3,'Maniema','Système d’AEP','KIMBOMBO','Système d’AEP',1.00,'2026-10-15 13:20:10','2026-10-16 08:09:14'),(11,4,'Kasaï','Système d’AEP','KAMWESHA','Système d’AEP',1.00,'2026-10-16 07:55:09','2026-10-16 08:10:14'),(12,4,'Kasaï','Système d’AEP','LOUANGE','Système d’AEP',1.00,'2026-10-16 07:55:09','2026-10-16 08:10:14'),(13,4,'Kasaï','Système d’AEP','KABAMBAYI','Système d’AEP',1.00,'2026-10-16 07:55:09','2026-10-16 08:10:14'),(14,5,'Kwilu','Système d’AEP','LUEKESHI','Système d’AEP',1.00,'2026-10-16 08:07:40','2026-10-16 08:07:55'),(15,5,'Kwilu','Système d’AEP','LUAMBO','Système d’AEP',1.00,'2026-10-16 08:07:40','2026-10-16 08:07:55'),(16,5,'Kwilu','Système d’AEP','KALAMBA MBUJ','Système d’AEP',1.00,'2026-10-16 08:07:40','2026-10-16 08:07:55'),(17,6,'Kwilu','Système d’AEP','KWENGE CENTRE','Système d’AEP',1.00,'2026-10-16 09:47:51','2026-10-16 09:47:51'),(18,6,'Kwilu','Système d’AEP','MUKEDI','Système d’AEP',1.00,'2026-10-16 09:47:51','2026-10-16 09:47:51'),(19,6,'Kwilu','Système d’AEP','MASAMUNA','Système d’AEP',1.00,'2026-10-16 09:47:51','2026-10-16 09:47:51'),(20,7,'Lomami','Système d’AEP','PENGYE','Système d’AEP',1.00,'2026-10-16 09:54:14','2026-10-16 10:06:09'),(21,7,'Lomami','Système d’AEP','TSHILEU/BAKWA MULUMBA','Système d’AEP',1.00,'2026-10-16 09:54:14','2026-10-16 10:06:09'),(22,7,'Lomami','Système d’AEP','KANYIKI MUTEMBWE','Système d’AEP',1.00,'2026-10-16 09:54:14','2026-10-16 10:06:09');
/*!40000 ALTER TABLE `contract_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `phase_id` bigint unsigned NOT NULL,
  `company_id` bigint unsigned NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `signature_date` date DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `duration_months` int unsigned DEFAULT NULL,
  `initial_financing_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `activities` text COLLATE utf8mb4_unicode_ci,
  `work_type_text` text COLLATE utf8mb4_unicode_ci,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `termination_date` date DEFAULT NULL,
  `termination_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contracts_project_reference_unique` (`project_id`,`reference`),
  KEY `contracts_phase_id_foreign` (`phase_id`),
  KEY `contracts_company_id_foreign` (`company_id`),
  KEY `contracts_project_id_phase_id_index` (`project_id`,`phase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
INSERT INTO `contracts` VALUES (1,1,1,1,'068',NULL,'Kasaï Oriental','TRAVAUX',3381983.53,'2025-01-22','2025-04-03','2027-04-03',24,30.00,'4 AEP sur les sites de MPANDA, BENA-KABIMBA, MULOWAYI et TSHILUNDU, dans la Province du Kasai-Oriental;','Système d’AEP',0,NULL,NULL,'2026-10-15 09:08:38','2026-10-16 11:06:29'),(2,1,1,2,'069',NULL,'Sankuru','TRAVAUX',2555335.00,'2025-01-31','2025-06-06','2027-06-06',24,30.00,'3 AEP sur les sites de DJALO, BAKWA-BUMBA, et MUKUMARI dans la province du SANKURU','Système d’AEP',0,NULL,NULL,'2026-10-15 12:57:07','2026-10-16 08:08:45'),(3,1,1,2,'070',NULL,'Maniema','TRAVAUX',2512215.00,'2025-01-31','2025-06-06','2027-06-06',24,30.00,'3 AEP sur les sites DIFUMA 2, LOWE et KIMBOMBO, dans la Province du Maniema','Système d’AEP',0,NULL,NULL,'2026-10-15 13:20:10','2026-10-16 08:09:14'),(4,1,1,1,'071',NULL,'Kasaï','TRAVAUX',2942138.63,'2025-01-22','2025-04-03','2027-04-03',24,30.00,'3 AEP sur les sites de KAMWESHA, LOUANGE et KABAMBAYI secteur, dans le Kasai','Système d’AEP',0,NULL,NULL,'2026-10-16 07:55:09','2026-10-16 08:10:14'),(5,1,1,1,'072',NULL,'Kwilu','TRAVAUX',3591585.03,'2025-01-22','2025-04-03','2027-04-03',24,30.00,'3 AEP surles sites de LUEKESHI, LUAMBO et KALAMBA MBUJI dans la Province du Kasai','Système d’AEP',0,NULL,NULL,'2026-10-16 08:07:40','2026-10-16 08:07:55'),(6,1,1,3,'073',NULL,'Kwilu','TRAVAUX',3052291.32,'2025-01-22','2025-03-26','2027-03-26',24,30.00,'3 AEP sur les sites de KWENGE CENTRE, MUKEDI et MASAMUNA dans la Province du Kwilu','Système d’AEP',0,NULL,NULL,'2026-10-16 09:47:51','2026-10-16 09:47:51'),(7,1,1,2,'091',NULL,'Lomami','TRAVAUX',0.00,'2026-08-19','2026-09-29','2028-03-29',18,0.00,'3 AEP sur les sites de PENGYE, TSHILEU/BAKWA MULUMBA, KANYIKI MUTEMBWE dans la Province de Lomami','Système d’AEP',0,NULL,NULL,'2026-10-16 09:54:14','2026-10-16 10:06:09');
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fleet_assets`
--

DROP TABLE IF EXISTS `fleet_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fleet_assets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `organizational_unit_id` bigint unsigned NOT NULL,
  `kind` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tank_capacity` decimal(8,2) NOT NULL DEFAULT '120.00',
  `consumption_rate` decimal(8,3) DEFAULT NULL,
  `fuel_price` decimal(8,3) NOT NULL DEFAULT '1.370',
  `fuel_alert_level` decimal(8,2) DEFAULT NULL,
  `maintenance_interval` int unsigned NOT NULL,
  `maintenance_warning` int unsigned NOT NULL,
  `initial_meter` decimal(12,1) NOT NULL DEFAULT '0.0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fleet_assets_project_name_unique` (`project_id`,`name`),
  KEY `fleet_assets_organizational_unit_id_foreign` (`organizational_unit_id`),
  CONSTRAINT `fleet_assets_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fleet_assets_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fleet_assets`
--

LOCK TABLES `fleet_assets` WRITE;
/*!40000 ALTER TABLE `fleet_assets` DISABLE KEYS */;
INSERT INTO `fleet_assets` VALUES (1,1,1,'VEHICULE','TOYOTA FORTUNER','1083 IT 23',120.00,0.200,1.370,30.00,3000,2500,4578.0,1,'2026-10-28 17:44:23','2026-10-28 17:44:23');
/*!40000 ALTER TABLE `fleet_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fleet_insurances`
--

DROP TABLE IF EXISTS `fleet_insurances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fleet_insurances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `organizational_unit_id` bigint unsigned NOT NULL,
  `fleet_asset_id` bigint unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` decimal(14,2) DEFAULT NULL,
  `observation` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fleet_insurances_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `fleet_insurances_fleet_asset_id_foreign` (`fleet_asset_id`),
  KEY `fleet_ins_asset_end_idx` (`project_id`,`fleet_asset_id`,`end_date`),
  CONSTRAINT `fleet_insurances_fleet_asset_id_foreign` FOREIGN KEY (`fleet_asset_id`) REFERENCES `fleet_assets` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fleet_insurances_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fleet_insurances_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fleet_insurances`
--

LOCK TABLES `fleet_insurances` WRITE;
/*!40000 ALTER TABLE `fleet_insurances` DISABLE KEYS */;
/*!40000 ALTER TABLE `fleet_insurances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fleet_logs`
--

DROP TABLE IF EXISTS `fleet_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fleet_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `organizational_unit_id` bigint unsigned NOT NULL,
  `fleet_asset_id` bigint unsigned NOT NULL,
  `log_date` date NOT NULL,
  `requester` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `destination` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purpose` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `departure_time` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `arrival_time` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meter_start` decimal(12,1) NOT NULL,
  `meter_end` decimal(12,1) NOT NULL,
  `fuel_level_before` decimal(8,2) DEFAULT NULL,
  `fuel_purchased` decimal(8,2) DEFAULT NULL,
  `fuel_price` decimal(8,3) DEFAULT NULL,
  `lubricant` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'PLEIN',
  `observation` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `assigned_to` bigint unsigned DEFAULT NULL,
  `authorized_by` bigint unsigned DEFAULT NULL,
  `authorized_at` timestamp NULL DEFAULT NULL,
  `objected_by` bigint unsigned DEFAULT NULL,
  `objected_at` timestamp NULL DEFAULT NULL,
  `objection_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancel_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fleet_logs_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `fleet_logs_fleet_asset_id_foreign` (`fleet_asset_id`),
  KEY `fleet_logs_asset_date_idx` (`project_id`,`fleet_asset_id`,`log_date`),
  KEY `fleet_logs_unit_date_idx` (`project_id`,`organizational_unit_id`,`log_date`),
  KEY `fleet_logs_assignee_idx` (`assigned_to`,`authorized_at`),
  CONSTRAINT `fleet_logs_fleet_asset_id_foreign` FOREIGN KEY (`fleet_asset_id`) REFERENCES `fleet_assets` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fleet_logs_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fleet_logs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fleet_logs`
--

LOCK TABLES `fleet_logs` WRITE;
/*!40000 ALTER TABLE `fleet_logs` DISABLE KEYS */;
INSERT INTO `fleet_logs` VALUES (1,1,1,1,'2026-10-29','RAF','AERO  NDJILI','Récupérer la délégation BAD','08:45','16:10',42723.0,42863.0,30.00,NULL,1.370,'2 L',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-29 07:09:20','2026-10-29 07:09:20');
/*!40000 ALTER TABLE `fleet_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fleet_maintenances`
--

DROP TABLE IF EXISTS `fleet_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fleet_maintenances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `organizational_unit_id` bigint unsigned NOT NULL,
  `fleet_asset_id` bigint unsigned NOT NULL,
  `maintenance_date` date NOT NULL,
  `meter_reading` decimal(12,1) NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` decimal(14,2) DEFAULT NULL,
  `provider` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observation` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fleet_maintenances_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `fleet_maintenances_fleet_asset_id_foreign` (`fleet_asset_id`),
  KEY `fleet_maint_asset_date_idx` (`project_id`,`fleet_asset_id`,`maintenance_date`),
  CONSTRAINT `fleet_maintenances_fleet_asset_id_foreign` FOREIGN KEY (`fleet_asset_id`) REFERENCES `fleet_assets` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fleet_maintenances_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fleet_maintenances_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fleet_maintenances`
--

LOCK TABLES `fleet_maintenances` WRITE;
/*!40000 ALTER TABLE `fleet_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `fleet_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guarantee_extensions`
--

DROP TABLE IF EXISTS `guarantee_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guarantee_extensions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `performance_guarantee_id` bigint unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `type` enum('RENOUVELLEMENT','PROLONGATION') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROLONGATION',
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `guarantee_extensions_performance_guarantee_id_foreign` (`performance_guarantee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guarantee_extensions`
--

LOCK TABLES `guarantee_extensions` WRITE;
/*!40000 ALTER TABLE `guarantee_extensions` DISABLE KEYS */;
/*!40000 ALTER TABLE `guarantee_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` timestamp NULL DEFAULT NULL,
  `available_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026_10_07_000000_create_prise_schema',1),(2,'2026_10_11_000001_extend_users_for_legacy_accounts',1),(3,'2026_10_11_000002_extend_contract_details',1),(4,'2026_10_12_000003_add_legacy_workflow_fields',1),(5,'2026_10_20_000004_align_with_csharp_features',2),(6,'2026_10_28_000004_convert_tables_to_innodb',3),(7,'2026_10_28_000005_create_organizational_structure',3),(8,'2026_10_28_000006_seed_initial_pools',4),(9,'2026_10_28_000007_create_stock_module',5),(10,'2026_10_28_000008_create_fleet_module',6),(11,'2026_10_28_000009_logistics_refinements',7),(12,'2026_10_28_000010_create_contract_decomptes',8),(13,'2026_10_29_000001_reporting_and_alert_settings',9),(14,'2026_10_29_000002_ai_and_decompte_release',10),(15,'2026_10_29_000003_roles_notifications_fleet_visa',11),(16,'2026_10_29_000004_decompte_decision_date',12),(17,'2026_10_29_000005_logistics_authority',13),(18,'2026_10_30_000001_stock_articles_by_unit',14),(19,'2026_10_30_000002_guarantee_alert_sequences',15),(20,'2026_10_30_000003_alert_templates_and_history',16),(21,'2026_11_02_000001_project_recipients_single_list',17),(22,'2026_11_03_000001_recipient_position_and_decompte_validator',18),(23,'2026_11_04_000001_split_alert_permissions',19);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizational_units`
--

DROP TABLE IF EXISTS `organizational_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizational_units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `org_units_project_code_unique` (`project_id`,`code`),
  KEY `org_units_project_type_idx` (`project_id`,`type`,`is_active`),
  CONSTRAINT `organizational_units_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizational_units`
--

LOCK TABLES `organizational_units` WRITE;
/*!40000 ALTER TABLE `organizational_units` DISABLE KEYS */;
INSERT INTO `organizational_units` VALUES (1,1,'COORDINATION','CN','Coordination nationale','Kinshasa',NULL,1,'2026-10-28 10:54:35','2026-10-28 12:40:00'),(2,2,'COORDINATION','CN','Coordination nationale',NULL,NULL,1,'2026-10-28 10:54:35','2026-10-28 10:54:35'),(3,1,'POOL','MBUJI-MAYI','Antenne MBUJI-MAYI','Kasaï-Oriental',NULL,1,'2026-10-28 12:10:26','2026-10-28 12:10:26'),(4,1,'POOL','KANANGA','Antenne KANANGA','Kasaï-Central',NULL,1,'2026-10-28 12:10:26','2026-10-28 12:10:26'),(5,2,'POOL','GBADOLITE','Antenne GBADOLITE','Nord-Ubangi',NULL,1,'2026-10-28 12:10:26','2026-10-28 12:10:26');
/*!40000 ALTER TABLE `organizational_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_requests`
--

DROP TABLE IF EXISTS `password_reset_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requested_at` timestamp NULL DEFAULT NULL,
  `is_read_by_admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Lien envoyé',
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `password_reset_requests_project_id_is_read_by_admin_index` (`project_id`,`is_read_by_admin`),
  KEY `password_reset_requests_project_id_index` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_requests`
--

LOCK TABLES `password_reset_requests` WRITE;
/*!40000 ALTER TABLE `password_reset_requests` DISABLE KEYS */;
INSERT INTO `password_reset_requests` VALUES (1,1,1,'hermansimbaleva20@gmail.com','2026-10-14 12:44:47',1,'Envoi impossible — réinitialisation manuelle requise',NULL,'2026-10-14 12:44:47','2026-10-15 06:56:02');
/*!40000 ALTER TABLE `password_reset_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performance_guarantees`
--

DROP TABLE IF EXISTS `performance_guarantees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_guarantees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `contract_id` bigint unsigned NOT NULL,
  `company_id` bigint unsigned NOT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(5,2) NOT NULL DEFAULT '5.00',
  `amount` decimal(15,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `observation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `alerts_paused_at` datetime DEFAULT NULL,
  `alerts_paused_by` bigint unsigned DEFAULT NULL,
  `alerts_pause_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alerts_per_week` tinyint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `performance_guarantees_contract_id_unique` (`contract_id`),
  KEY `performance_guarantees_project_id_foreign` (`project_id`),
  KEY `performance_guarantees_company_id_foreign` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_guarantees`
--

LOCK TABLES `performance_guarantees` WRITE;
/*!40000 ALTER TABLE `performance_guarantees` DISABLE KEYS */;
INSERT INTO `performance_guarantees` VALUES (1,1,1,1,'RAWBANK','RE-675-400',5.00,169099.18,'2025-04-03','2027-04-03','','2026-10-15 09:08:38','2026-10-30 12:47:07',NULL,NULL,NULL,NULL),(2,1,2,2,'Equity-BCDC','RE16472',5.00,127766.75,'2025-06-12','2026-07-12','','2026-10-15 12:57:07','2026-10-30 12:45:09',NULL,NULL,NULL,NULL),(3,1,3,2,'Rawbank','115577389202',5.00,125610.75,'2025-06-12','2027-07-01','','2026-10-15 13:20:10','2026-10-15 13:20:10',NULL,NULL,NULL,NULL),(4,1,4,1,'SOLIDAIRE','NT-649-126',5.00,147106.93,'2025-04-03','2027-04-03','','2026-10-16 07:55:09','2026-10-30 12:47:58',NULL,NULL,NULL,NULL),(5,1,5,1,'SOFIBANK','RB-245-12',5.00,179579.25,'2025-01-02','2026-09-04','','2026-10-16 08:07:40','2026-10-30 12:45:35',NULL,NULL,NULL,NULL),(6,1,6,3,'EQUITY-BCDC','RB-906-342',5.00,152614.57,'2025-03-26','2027-03-26','','2026-10-16 09:47:51','2026-10-30 12:46:24',NULL,NULL,NULL,NULL),(7,1,7,2,'','',5.00,149.30,'2026-09-29','2028-03-29','','2026-10-16 09:54:14','2026-10-16 09:54:14',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `performance_guarantees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_id` bigint unsigned NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,1,'App\\Models\\User','prise-web','27289fb8c61f9600c54c30771a907bbc8ae14e9d1593f941374d95efcb4ad3f8','[\"*\"]','2026-10-14 13:20:46','2026-10-28 13:20:45','2026-10-14 13:20:45','2026-10-14 13:20:46'),(2,1,'App\\Models\\User','prise-web','25c801a592972507e79c08a761c331b16e67d19d2648fc7e29abb5ccddc16a6b','[\"*\"]','2026-10-14 13:21:46','2026-10-28 13:21:46','2026-10-14 13:21:46','2026-10-14 13:21:46'),(3,2,'App\\Models\\User','prise-web','79cd6036923a37c44292a497c3c1f444c750c15131478ee76c430ac02708cf99','[\"*\"]','2026-10-14 13:23:28','2026-10-28 13:23:28','2026-10-14 13:23:28','2026-10-14 13:23:28'),(4,1,'App\\Models\\User','prise-web','a3de58778bc94c67b1fed55de5f1e140ff796e0400867be1a16b8737ccad12fc','[\"*\"]','2026-10-14 13:27:39','2026-10-28 13:27:38','2026-10-14 13:27:38','2026-10-14 13:27:39'),(5,1,'App\\Models\\User','prise-web','03080256e3461d2dc0df1d7977ce779d4ca264310dee4acee40dde87d67da637','[\"*\"]','2026-10-14 13:49:24','2026-10-28 13:49:24','2026-10-14 13:49:24','2026-10-14 13:49:24'),(6,2,'App\\Models\\User','prise-web','999b5c930e5a4d20dbb996ac562dd1cf0cff048a0380d8b89e3af8970ed6844a','[\"*\"]','2026-10-14 13:50:08','2026-10-28 13:50:08','2026-10-14 13:50:08','2026-10-14 13:50:08'),(7,1,'App\\Models\\User','prise-web','571b31450b31fbb7e2843b00b06ccacd91571455aeb4372bc62fbb0ccac7adcf','[\"*\"]','2026-10-14 14:52:36','2026-10-28 14:00:56','2026-10-14 14:00:56','2026-10-14 14:52:36'),(11,1,'App\\Models\\User','prise-web','01d8c87ec95eaf8bbb1c62f7bbe97c64aa305ebd4cbffaef0b52d99d0aaf8f08','[\"*\"]','2026-10-15 09:36:40','2026-10-29 08:40:08','2026-10-15 08:40:08','2026-10-15 09:36:40'),(12,1,'App\\Models\\User','prise-web','42442a5da6e993285a1c2ccfb6ad3498dc9394ee9310e354282684dbf0bc4325','[\"*\"]','2026-10-15 09:37:20','2026-10-29 09:37:20','2026-10-15 09:37:20','2026-10-15 09:37:20'),(13,1,'App\\Models\\User','prise-web','5f7bf594ef53ac7aebd58f4d8b3171842900a6a5be5ab19ee7e507d6270dd09b','[\"*\"]','2026-10-15 09:37:53','2026-10-29 09:37:53','2026-10-15 09:37:53','2026-10-15 09:37:53'),(15,1,'App\\Models\\User','prise-web','c685d0f49549a4673daeee85f994a0e1e8a90455afcfe285bfced41f49d09b57','[\"*\"]','2026-10-15 09:41:43','2026-10-29 09:41:43','2026-10-15 09:41:43','2026-10-15 09:41:43'),(16,1,'App\\Models\\User','prise-web','d83705fa0f50633978b630367912d32298e0c9bbe11756f12667976ad639ffed','[\"*\"]','2026-10-15 09:51:53','2026-10-29 09:51:53','2026-10-15 09:51:53','2026-10-15 09:51:53'),(18,1,'App\\Models\\User','prise-web','b8c1e841d95453e330c21710912f3993b40b828a8b28c5f43340519f96560752','[\"*\"]','2026-10-17 08:30:38','2026-10-29 13:01:00','2026-10-15 13:01:00','2026-10-17 08:30:38'),(20,1,'App\\Models\\User','prise-web','e8dfc4e8489ecfc4eba74bf338c7d5f987c8a701ef5a41b2d92d888ba4bb910d','[\"*\"]','2026-10-18 15:47:17','2026-11-01 15:45:19','2026-10-18 15:45:19','2026-10-18 15:47:17'),(21,1,'App\\Models\\User','prise-web','0a2efb05c0206bc1178c1b5be5c92a7498afa8766797a0b36c56d3ee7ed1d0b3','[\"*\"]','2026-10-18 16:13:11','2026-11-01 16:00:23','2026-10-18 16:00:23','2026-10-18 16:13:11'),(22,1,'App\\Models\\User','prise-web','4fee4927e182c60fb915b9ba6691b7c638397af0088c7d86dd5d0d4401a73f4e','[\"*\"]','2026-10-19 13:01:50','2026-11-01 16:29:10','2026-10-18 16:29:10','2026-10-19 13:01:50'),(23,1,'App\\Models\\User','prise-web','490b5aee7230e9375bc02ffb313630838f3f717b02df4cc5264d5cd7c332bd80','[\"*\"]','2026-10-18 17:50:38','2026-11-01 16:48:27','2026-10-18 16:48:27','2026-10-18 17:50:38'),(24,1,'App\\Models\\User','prise-web','7eb763e928110ce9a9661ed476a1b67cde8f8f42412ed313fb5e57d395001101','[\"*\"]','2026-10-18 22:31:56','2026-11-01 22:22:26','2026-10-18 22:22:26','2026-10-18 22:31:56'),(25,1,'App\\Models\\User','prise-web','e398150b3bb2d1a59d0833d85e01620def8af6c16d7e28c9bb19b3336da03ce7','[\"*\"]','2026-10-18 22:57:35','2026-11-01 22:51:35','2026-10-18 22:51:35','2026-10-18 22:57:35'),(26,3,'App\\Models\\User','prise-web','151223ecd91abf815c6783b343a5581f56e2fe7470f4d436253c57b7b03aee05','[\"*\"]','2026-10-18 23:00:09','2026-11-01 22:54:42','2026-10-18 22:54:42','2026-10-18 23:00:09'),(27,1,'App\\Models\\User','prise-web','6d32b76fc2f911137d515dc3066071f9668fb830f569417009396b219d50396f','[\"*\"]','2026-10-19 07:46:37','2026-11-02 06:31:46','2026-10-19 06:31:46','2026-10-19 07:46:37'),(28,1,'App\\Models\\User','prise-web','55ce11181eea678c3a63f095fdb2a12adf8b8ee44667c24bb80b4e252e7ca681','[\"*\"]','2026-10-19 13:42:29','2026-11-02 13:09:57','2026-10-19 13:09:57','2026-10-19 13:42:29'),(30,1,'App\\Models\\User','prise-web','640b6d8479a1f3ebc4d0f59aa14e9b19bbdffae60fd0db6216eaa8c281e72a55','[\"*\"]','2026-10-22 15:42:21','2026-11-05 14:18:36','2026-10-22 14:18:36','2026-10-22 15:42:21'),(31,1,'App\\Models\\User','prise-web','8c7c7a8920ad4fc13058b607af44f99de559b3f5ab2b8eb794a21c49f58956cf','[\"*\"]','2026-10-27 09:52:09','2026-11-05 20:11:51','2026-10-22 20:11:51','2026-10-27 09:52:09'),(34,1,'App\\Models\\User','prise-web','1e715d02e0e324669d810774c2de953052b33d25ecc89976a188a624894742bf','[\"*\"]','2026-10-28 13:53:21','2026-11-11 13:38:15','2026-10-28 13:38:15','2026-10-28 13:53:21'),(36,1,'App\\Models\\User','prise-web','2e3bd650248414e635b147c3b9f1c8e813d9361585a911094b6f79e870912298','[\"*\"]','2026-10-28 16:47:34','2026-11-11 14:19:54','2026-10-28 14:19:54','2026-10-28 16:47:34'),(40,1,'App\\Models\\User','prise-web','6c45e1a03d5a287d597e4e6a794a92b07aa951cde58dd643fb223f5972eadbbc','[\"*\"]','2026-10-28 18:33:00','2026-11-11 17:30:57','2026-10-28 17:30:57','2026-10-28 18:33:00'),(57,1,'App\\Models\\User','prise-web','da64b9dbd6c708641e539c5eb8cc519673fa5f1f19f8b62d6fda3003312d5019','[\"*\"]','2026-10-31 15:11:56','2026-11-13 14:25:35','2026-10-30 14:25:35','2026-10-31 15:11:56'),(58,1,'App\\Models\\User','prise-web','84ca9d912e27ea5b6916c134e450b99ba768e53b06971a4dba7a6917d8c21697','[\"*\"]','2026-10-31 16:38:09','2026-11-14 16:00:08','2026-10-31 16:00:08','2026-10-31 16:38:09'),(61,2,'App\\Models\\User','prise-web','e8b9dca7afdd95f93e6e65e5010d395e4b4c1260f2d45cfbd43a4306041704b6','[\"*\"]','2026-11-03 08:03:36','2026-11-17 07:17:59','2026-11-03 07:17:59','2026-11-03 08:03:36'),(62,1,'App\\Models\\User','prise-web','dd12edda1747c175b90a5b4e873aacb9cab324e0de934bea87f0c22a25314802','[\"*\"]','2026-11-03 23:04:49','2026-11-17 08:11:09','2026-11-03 08:11:09','2026-11-03 23:04:49'),(63,6,'App\\Models\\User','prise-web','3d9374b8b6b41a7c15be5b405d85c6063bbdfae2382ff0ef8c0c1ea4ba9a1911','[\"*\"]','2026-11-04 08:38:18','2026-11-17 08:11:36','2026-11-03 08:11:36','2026-11-04 08:38:18'),(64,1,'App\\Models\\User','prise-web','1ffaa9dcd5f0cd2c6e61d9ff909a0bc029a3576d3d9e11d24adf1cd9148a7c63','[\"*\"]','2026-11-04 09:11:32','2026-11-18 07:37:12','2026-11-04 07:37:12','2026-11-04 09:11:32'),(65,5,'App\\Models\\User','prise-web','68e67b2c79594f5bd3c15a65f8e2e59be9f8dfdad6a403bdf00c75524a659755','[\"*\"]','2026-11-04 09:11:28','2026-11-18 08:08:03','2026-11-04 08:08:03','2026-11-04 09:11:28');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `positions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `organizational_unit_id` bigint unsigned DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `positions_project_unit_name_unique` (`project_id`,`organizational_unit_id`,`name`),
  KEY `positions_organizational_unit_id_foreign` (`organizational_unit_id`),
  CONSTRAINT `positions_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE SET NULL,
  CONSTRAINT `positions_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,1,1,'CN','COORDINATEUR NATIONALE',1,'2026-10-28 12:51:28','2026-10-28 14:16:05'),(2,1,1,'HRAF','HOMOLOGUE RESPONSABLE ADMINISTRATIF ET FINANCIER',1,'2026-10-28 12:52:45','2026-10-29 08:13:18'),(3,1,1,'COMPTABLE','COMPTABLE',1,'2026-10-28 12:53:12','2026-10-28 14:15:50'),(4,1,1,'ASSISTANT COMPTABLE','ASSISTANT COMPTABLE',1,'2026-10-28 12:53:51','2026-10-28 17:21:51'),(5,1,1,'HCPM','HOMOLOGUE NATIONAL EN PASSATION DE MARCHES',1,'2026-10-28 12:54:25','2026-10-28 14:16:32'),(6,1,1,'APM','ASSISTANT EN PASSATION DES MARCHES',1,'2026-10-28 12:55:40','2026-10-28 14:15:17'),(7,1,1,'HNSE','HOMOLOGUE NATIONAL EN SUIVI-EVALUATION',1,'2026-10-28 12:59:35','2026-10-28 14:16:52'),(8,1,1,'CHEF DE CELLULE INFRASTRUCTURES (AEP)','CHEF DE CELLULE INFRASTRUCTURES (AEP)',1,'2026-10-28 13:00:52','2026-10-28 17:22:20'),(9,1,1,'SECRETAIREINFORMATICIEN','SECRETAIRE INFORMATICIEN',1,'2026-10-28 14:27:23','2026-10-28 17:23:15'),(10,1,1,'SECA','SECRETAIRE CAISSIER',1,'2026-10-28 14:27:48','2026-10-28 14:27:48'),(11,1,1,'LOGISTICIEN','CHAUFFEUR LOGISTICIEN',1,'2026-10-28 14:28:40','2026-10-28 14:28:40'),(12,1,1,'CHAUFFEUR COURSIER','CHAUFFEUR COURSIER',1,'2026-10-28 14:29:16','2026-10-28 14:29:16'),(13,1,4,'C.P KANANGA','CHEF DE POOL KANANGA (POOL OUEST)',1,'2026-10-28 14:31:10','2026-11-03 07:10:49'),(14,1,4,'ESE KANANGA','EXPERT EN SUIVI-EVALUATION (POOL OUEST)',1,'2026-10-28 14:32:16','2026-11-03 07:10:23'),(15,1,3,'ESE MBUJI-MAYI','EXPERT EN SUIVI-EVALUATION (POOL EST)',1,'2026-10-28 14:33:00','2026-11-03 07:10:06'),(16,1,3,'C.P MBUJI-MAYI','CHEF DE POOL MBUJI-MAYI(POOL EST)',1,'2026-10-28 14:35:24','2026-11-03 07:11:14'),(17,1,4,'SECA','SECRETAIRE-CAISSIER (POOL OUEST)',1,'2026-10-28 14:38:00','2026-10-28 14:38:00'),(18,1,3,'SECA','SECRETAIRE-CAISSIER (POOL EST)',1,'2026-10-28 14:38:22','2026-10-28 14:38:22'),(19,1,4,'CHAUFFEUR','CHAFFEUR POOL-OUEST',1,'2026-10-29 13:37:52','2026-10-29 13:37:52'),(20,1,3,'CHAUFFEUR','CHAUFFEUR POOL-EST',1,'2026-10-29 13:38:12','2026-10-29 13:38:12'),(21,1,4,'ENVIRONNEMENTALISTE','ENVIRONNEMENTALISTE POOL-OUEST',1,'2026-10-29 13:40:18','2026-10-29 13:40:18'),(22,1,3,'ENVIRONNEMENTALISTE','ENVIRONNEMENTALISTE POOL-EST',1,'2026-10-29 13:40:38','2026-10-29 13:40:38'),(23,1,4,'Ingénieur AEP','INGENIEUR AEP KANANGA',1,'2026-11-03 07:08:56','2026-11-03 07:08:56'),(24,1,3,'Ingénieur AEP','INGENIEUR AEP MBUJI-MAYI',1,'2026-11-03 07:09:26','2026-11-03 07:09:26');
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progress_entries`
--

DROP TABLE IF EXISTS `progress_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progress_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `contract_site_id` bigint unsigned DEFAULT NULL,
  `situation_date` date NOT NULL,
  `progress` decimal(6,2) NOT NULL,
  `realization_physical` text COLLATE utf8mb4_unicode_ci,
  `paid_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `observation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `progress_entries_contract_id_foreign` (`contract_id`),
  KEY `progress_entries_contract_site_id_situation_date_index` (`contract_site_id`,`situation_date`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progress_entries`
--

LOCK TABLES `progress_entries` WRITE;
/*!40000 ALTER TABLE `progress_entries` DISABLE KEYS */;
INSERT INTO `progress_entries` VALUES (1,1,4,'2026-09-30',78.00,'Un 1er forage terminé 6m3/h, 2ème forage terminé, débit 5,5 m3/h. CE de 100 m3: cuve et coupole achevées BF : réalisé 9 sur 12 prévues',0.00,'Conduites : 5237,4 m posées sur 3395 m prévues dans le contrat soit 1842,4 m de plus que prévu ce qui équivaut à 54 % de dépassement','2026-10-16 10:15:22','2026-10-16 10:42:05'),(2,1,1,'2026-09-30',39.00,'Réalisation d\'un premier forage négatif et d\'un deuxième forage productif, débit 8m3/h d\'après les essais CE',0.00,'Capacité du CE de 100 m3 à 60m3 travaux au niveau de la fouille terminée et pose de conduite : de 5118m sur 3340 prévue Rupture de stock en tuyau pour poursuivre la pose conduite','2026-10-16 10:41:49','2026-10-16 10:41:49'),(3,1,3,'2026-09-30',21.00,'Un forage de 10m3/h après les essais',0.00,'Retard sur l\'exécution du réseau et construction du CE  après deux mois de fin de forage, Attente approbation des plans','2026-10-16 10:45:06','2026-10-16 10:45:06'),(4,1,2,'2026-09-30',1.00,'Réalisation du 1er forage négatif. Prospection et étude en cours pour le captage des sources le plus proches',0.00,'Refaire les études pour verifier les données géophysique enfin de consolider les travaux de forage ou non. Si les etudes sont positives, l\'entreprise doit garantir un personnel qualifie pour les travaux, disposer des equipements adaptés. MCva refaire les études en presence de l\'hydrogeologue, lhydraulicien, maître forreur de l\'entreprise.','2026-10-16 11:04:49','2026-10-16 11:04:49'),(5,2,5,'2026-09-30',24.00,'Forage réalisé productif : 106 m, 16m3/h',0.00,'Le dossier technique a été approuvé pour le réseau sauf le dimensionnement en régime transitoire, attente du dossier de génie civile','2026-10-19 13:58:27','2026-10-19 14:01:45'),(6,2,7,'2026-09-30',28.00,'Après 2 forages loupés, réalisation d\'un 3ème forage réussi, débit 12 m3/h',0.00,'Le dossier technique pour le réseau a été approuvé et attente dossier de génie civile','2026-10-19 14:01:26','2026-10-19 14:01:26'),(7,2,6,'2026-09-30',19.00,'Forage déjà réalisé, débit 12 m3/h',0.00,'Dossier technique pour ce site en élaboration pour envoyer en MC','2026-10-19 14:04:46','2026-10-19 14:04:46');
/*!40000 ALTER TABLE `progress_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_phases`
--

DROP TABLE IF EXISTS `project_phases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_phases` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `number` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_current` tinyint(1) NOT NULL DEFAULT '0',
  `is_archived` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_phases_project_id_number_unique` (`project_id`,`number`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_phases`
--

LOCK TABLES `project_phases` WRITE;
/*!40000 ALTER TABLE `project_phases` DISABLE KEYS */;
INSERT INTO `project_phases` VALUES (1,1,2,'PRISE','Projet de Renforcement des Infranstructures Socio-Economiques dans la Zone Centre de la RDC',1,0,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(2,2,1,'PREDIRE','Programme Régional d\'Appui au Développement des Infranstructures et Valorisations de Ressources en Eau Transfrontalières entre la RCA et RDC',1,0,'2026-10-14 10:49:59','2026-10-14 10:49:59');
/*!40000 ALTER TABLE `project_phases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `projects_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'PRISE','Projet de Renforcement des Infrastructures Socio-Économiques dans la Zone Centre de la RDC','2026-10-14 10:49:59','2026-10-14 10:49:59'),(2,'PREDIRE','Programme Régional d’Appui au Développement des Infrastructures et de Valorisation des Ressources en Eau Transfrontalières entre la RCA et la RDC','2026-10-14 10:49:59','2026-10-14 10:49:59');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provinces`
--

DROP TABLE IF EXISTS `provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provinces` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provinces_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provinces`
--

LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;
INSERT INTO `provinces` VALUES (1,'Kinshasa','2026-10-14 10:19:49','2026-10-14 10:19:49'),(2,'Kongo Central','2026-10-14 10:19:49','2026-10-14 10:19:49'),(3,'Kwango','2026-10-14 10:19:49','2026-10-14 10:19:49'),(4,'Kwilu','2026-10-14 10:19:49','2026-10-14 10:19:49'),(5,'Mai-Ndombe','2026-10-14 10:19:49','2026-10-14 10:19:49'),(6,'Équateur','2026-10-14 10:19:49','2026-10-14 10:19:49'),(7,'Mongala','2026-10-14 10:19:49','2026-10-14 10:19:49'),(8,'Nord-Ubangi','2026-10-14 10:19:49','2026-10-14 10:19:49'),(9,'Sud-Ubangi','2026-10-14 10:19:49','2026-10-14 10:19:49'),(10,'Tshuapa','2026-10-14 10:19:49','2026-10-14 10:19:49'),(11,'Tshopo','2026-10-14 10:19:49','2026-10-14 10:19:49'),(12,'Bas-Uele','2026-10-14 10:19:49','2026-10-14 10:19:49'),(13,'Haut-Uele','2026-10-14 10:19:49','2026-10-14 10:19:49'),(14,'Ituri','2026-10-14 10:19:49','2026-10-14 10:19:49'),(15,'Nord-Kivu','2026-10-14 10:19:49','2026-10-14 10:19:49'),(16,'Sud-Kivu','2026-10-14 10:19:49','2026-10-14 10:19:49'),(17,'Maniema','2026-10-14 10:19:49','2026-10-14 10:19:49'),(18,'Tanganyika','2026-10-14 10:19:49','2026-10-14 10:19:49'),(19,'Haut-Lomami','2026-10-14 10:19:49','2026-10-14 10:19:49'),(20,'Lualaba','2026-10-14 10:19:49','2026-10-14 10:19:49'),(21,'Haut-Katanga','2026-10-14 10:19:49','2026-10-14 10:19:49'),(22,'Kasaï','2026-10-14 10:19:49','2026-10-14 10:19:49'),(23,'Kasaï Central','2026-10-14 10:19:49','2026-10-14 10:19:49'),(24,'Lomami','2026-10-14 10:19:49','2026-10-14 10:19:49'),(25,'Sankuru','2026-10-14 10:19:49','2026-10-14 10:19:49'),(26,'Kasaï Oriental','2026-10-14 10:19:49','2026-10-14 10:19:49');
/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_snapshots`
--

DROP TABLE IF EXISTS `report_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_snapshots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `phase_id` bigint unsigned DEFAULT NULL,
  `period_type` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_snapshots_label_unique` (`project_id`,`phase_id`,`label`),
  CONSTRAINT `report_snapshots_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_snapshots`
--

LOCK TABLES `report_snapshots` WRITE;
/*!40000 ALTER TABLE `report_snapshots` DISABLE KEYS */;
INSERT INTO `report_snapshots` VALUES (1,1,1,'MOIS','Octobre 2026','2026-10-01','2026-10-31','{\"asOf\":\"2026-10-29\",\"rows\":[{\"id\":1,\"number\":\"068\",\"company\":\"SZTC\",\"category\":\"TRAVAUX\",\"province\":\"Kasaï Oriental\",\"amount\":3381983.53,\"progress\":34.75,\"elapsed\":78.63,\"status\":\"Retard\",\"paid\":1520776.73,\"paymentRate\":44.97,\"remaining\":1861206.8,\"decomptesValidated\":236789,\"decomptesPending\":0,\"observation\":\"Refaire les études pour verifier les données géophysique enfin de consolider les travaux de forage ou non. Si les etudes sont positives, l\'entreprise doit garantir un personnel qualifie pour les travaux, disposer des equipements adaptés. MCva refaire les études en presence de l\'hydrogeologue, lhydraulicien, maître forreur de l\'entreprise.\"},{\"id\":2,\"number\":\"069\",\"company\":\"SAGEC-KAT\",\"category\":\"TRAVAUX\",\"province\":\"Sankuru\",\"amount\":2555335,\"progress\":23.67,\"elapsed\":69.86,\"status\":\"Retard\",\"paid\":1839545.75,\"paymentRate\":71.99,\"remaining\":715789.25,\"decomptesValidated\":1650685,\"decomptesPending\":0,\"observation\":\"Dossier technique pour ce site en élaboration pour envoyer en MC\"},{\"id\":3,\"number\":\"070\",\"company\":\"SAGEC-KAT\",\"category\":\"TRAVAUX\",\"province\":\"Maniema\",\"amount\":2512215,\"progress\":0,\"elapsed\":69.86,\"status\":\"Retard\",\"paid\":753664.5,\"paymentRate\":30,\"remaining\":1758550.5,\"decomptesValidated\":0,\"decomptesPending\":0,\"observation\":\"\"},{\"id\":4,\"number\":\"071\",\"company\":\"SZTC\",\"category\":\"TRAVAUX\",\"province\":\"Kasaï\",\"amount\":2942138.63,\"progress\":0,\"elapsed\":78.63,\"status\":\"Retard\",\"paid\":1377283.14,\"paymentRate\":46.81,\"remaining\":1564855.49,\"decomptesValidated\":760987,\"decomptesPending\":0,\"observation\":\"\"},{\"id\":5,\"number\":\"072\",\"company\":\"SZTC\",\"category\":\"TRAVAUX\",\"province\":\"Kwilu\",\"amount\":3591585.03,\"progress\":0,\"elapsed\":78.63,\"status\":\"Retard\",\"paid\":1077475.51,\"paymentRate\":30,\"remaining\":2514109.52,\"decomptesValidated\":0,\"decomptesPending\":0,\"observation\":\"\"},{\"id\":6,\"number\":\"073\",\"company\":\"CGC\",\"category\":\"TRAVAUX\",\"province\":\"Kwilu\",\"amount\":3052291.32,\"progress\":0,\"elapsed\":79.73,\"status\":\"Retard\",\"paid\":915687.4,\"paymentRate\":30,\"remaining\":2136603.92,\"decomptesValidated\":0,\"decomptesPending\":0,\"observation\":\"\"},{\"id\":7,\"number\":\"091\",\"company\":\"SAGEC-KAT\",\"category\":\"TRAVAUX\",\"province\":\"Lomami\",\"amount\":0,\"progress\":0,\"elapsed\":5.48,\"status\":\"Normal\",\"paid\":0,\"paymentRate\":0,\"remaining\":0,\"decomptesValidated\":0,\"decomptesPending\":0,\"observation\":\"\"}],\"summary\":{\"contracts\":7,\"amount\":18035548.51,\"paid\":7484433.03,\"remaining\":10551115.48,\"progress\":8.35,\"paymentRate\":41.5,\"statuses\":{\"Retard\":6,\"Normal\":1}},\"fuel\":{\"vehicles\":{\"entries\":0,\"distance\":0,\"litresPurchased\":0,\"purchaseCost\":0,\"estimatedLitres\":0,\"estimatedCost\":0,\"lubricantEntries\":0,\"pending\":1,\"objected\":0,\"pendingDistance\":140,\"pendingLitres\":0,\"per100Km\":null,\"perHour\":null},\"generators\":{\"entries\":0,\"distance\":0,\"litresPurchased\":0,\"purchaseCost\":0,\"estimatedLitres\":0,\"estimatedCost\":0,\"lubricantEntries\":0,\"pending\":0,\"objected\":0,\"pendingDistance\":0,\"pendingLitres\":0,\"per100Km\":null,\"perHour\":null}}}',NULL,1,'2026-10-29 13:45:01','2026-10-29 13:45:01');
/*!40000 ALTER TABLE `report_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smtp_settings`
--

DROP TABLE IF EXISTS `smtp_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smtp_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `host` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int unsigned NOT NULL DEFAULT '587',
  `sender_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text COLLATE utf8mb4_unicode_ci,
  `use_ssl` tinyint(1) NOT NULL DEFAULT '0',
  `recipient1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `smtp_settings_project_id_unique` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smtp_settings`
--

LOCK TABLES `smtp_settings` WRITE;
/*!40000 ALTER TABLE `smtp_settings` DISABLE KEYS */;
INSERT INTO `smtp_settings` VALUES (1,1,'smtp.gmail.com',587,'hermansimbaleva20@gmail.com','eyJpdiI6IkMwSS9ld0tWaUh0Y0FGZWcyK3hUTnc9PSIsInZhbHVlIjoiN3grN2Y3WVZudzRJNm0yRkNUUVZSNkl2b0pJL21zOVMxRmVWSURRa2E3VT0iLCJtYWMiOiJkYjhiOGI2Y2IxMWI0MjIwZjk5Yjk4NDIwMjg3NjNiZTdkN2IyYjNmZGYwZDU1Nzk2M2ExY2E4YzNhNmU4Y2YzIiwidGFnIjoiIn0=',1,NULL,NULL,NULL,NULL,'2026-10-14 10:49:59','2026-11-02 14:32:09'),(2,2,'smtp.gmail.com',587,'hermansimbaleva20@gmail.com','eyJpdiI6InpIUDR5RWVpWGVmMDBHL20vMVk1MEE9PSIsInZhbHVlIjoibjZiK3k4WTc3NDY3RXRGZDg2cllzNnFlR2ZvV3J5VFhkOVJubENaZGdBVT0iLCJtYWMiOiJkMjMwMWE1NjU5ZWU4YzViN2Q2OWFhODJiMTg1YzFlMDUyMDEwNmE5ZWRmNmMyNWM1ZjY2ODI4NjQ3OWE3NzNhIiwidGFnIjoiIn0=',1,NULL,NULL,NULL,NULL,'2026-10-14 10:49:59','2026-11-03 07:22:20');
/*!40000 ALTER TABLE `smtp_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_articles`
--

DROP TABLE IF EXISTS `stock_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_articles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `organizational_unit_id` bigint unsigned DEFAULT NULL,
  `contract_id` bigint unsigned DEFAULT NULL,
  `number` int unsigned NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pack_size` decimal(10,2) DEFAULT NULL,
  `pack_unit` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_price` decimal(18,2) NOT NULL DEFAULT '0.00',
  `alert_threshold` decimal(14,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_articles_project_number_unique` (`project_id`,`number`),
  KEY `stock_articles_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `stock_articles_contract_id_foreign` (`contract_id`),
  KEY `stock_articles_project_designation_idx` (`project_id`,`designation`),
  CONSTRAINT `stock_articles_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_articles_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_articles_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_articles`
--

LOCK TABLES `stock_articles` WRITE;
/*!40000 ALTER TABLE `stock_articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `organizational_unit_id` bigint unsigned NOT NULL,
  `stock_article_id` bigint unsigned NOT NULL,
  `operation_no` int unsigned DEFAULT NULL,
  `movement_date` date NOT NULL,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(14,2) NOT NULL,
  `origin_destination` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_id` bigint unsigned DEFAULT NULL,
  `reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observation` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancel_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `stock_movements_stock_article_id_foreign` (`stock_article_id`),
  KEY `stock_movements_card_idx` (`project_id`,`organizational_unit_id`,`stock_article_id`,`movement_date`),
  KEY `stock_movements_company_id_foreign` (`company_id`),
  CONSTRAINT `stock_movements_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_movements_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_movements_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_stock_article_id_foreign` FOREIGN KEY (`stock_article_id`) REFERENCES `stock_articles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notifications`
--

DROP TABLE IF EXISTS `user_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `kind` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_name` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_notifications_project_id_foreign` (`project_id`),
  KEY `user_notifications_user_read_idx` (`user_id`,`read_at`),
  KEY `user_notifications_entity_idx` (`entity_name`,`entity_id`),
  CONSTRAINT `user_notifications_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notifications`
--

LOCK TABLES `user_notifications` WRITE;
/*!40000 ALTER TABLE `user_notifications` DISABLE KEYS */;
INSERT INTO `user_notifications` VALUES (1,1,6,'DECOMPTE_A_VALIDER','DECOMPTE N°1 à valider — contrat 068','DECOMPTE N°1 du contrat 068 (SZTC) : 236 789,00 USD, transmis au comptable. Saisi par Hermans imbaleva.','/decomptes?contrat=1','Decompte','3','2026-10-29 10:01:51','2026-10-29 09:01:21','2026-10-29 09:01:51'),(2,1,1,'DECOMPTE_DECISION','DECOMPTE N°1 validé — contrat 068','DECOMPTE N°1 du contrat 068 validé par Glody TSHIMPAKA.','/decomptes?contrat=1','Decompte','3','2026-10-29 10:12:06','2026-10-29 09:11:21','2026-10-29 09:12:06'),(3,1,1,'DECOMPTE_DECISION','DECOMPTE N°1 validé — contrat 069','DECOMPTE N°1 du contrat 069 validé par Glody TSHIMPAKA le 29/10/2026.','/decomptes?contrat=2','Decompte','1','2026-10-29 13:20:50','2026-10-29 10:33:54','2026-10-29 12:20:50'),(4,1,3,'DECOMPTE_DECISION','DECOMPTE N°2 validé — contrat 069','DECOMPTE N°2 du contrat 069 validé par Glody TSHIMPAKA le 29/10/2026.','/decomptes?contrat=2','Decompte','2',NULL,'2026-10-29 10:33:58','2026-10-29 10:33:58'),(5,1,6,'DECOMPTE_A_VALIDER','DECOMPTE N°2 à valider — contrat 071','DECOMPTE N°2 du contrat 071 (SZTC) : 760 987,00 USD, transmis au comptable. Saisi par Hermans imbaleva.','/decomptes?contrat=4','Decompte','4','2026-10-29 14:31:16','2026-10-29 13:30:28','2026-10-29 13:31:16'),(6,1,1,'DECOMPTE_DECISION','DECOMPTE N°2 validé — contrat 071','DECOMPTE N°2 du contrat 071 validé par Glody TSHIMPAKA le 29/10/2026.','/decomptes?contrat=4','Decompte','4','2026-10-29 14:32:38','2026-10-29 13:31:49','2026-10-29 13:32:38'),(7,1,6,'DECOMPTE_A_VALIDER','DECOMPTE N°2 à valider — contrat 068','DECOMPTE N°2 du contrat 068 (SZTC) : 345 677,00 USD, transmis au comptable. Saisi par Hermans imbaleva.','/decomptes?contrat=1','Decompte','5','2026-11-03 09:11:42','2026-11-02 13:13:44','2026-11-03 08:11:42'),(8,1,1,'DECOMPTE_DECISION','DECOMPTE N°2 validé — contrat 068','DECOMPTE N°2 du contrat 068 validé par Glody TSHIMPAKA le 03/11/2026.','/decomptes?contrat=1','Decompte','5','2026-11-03 09:27:50','2026-11-03 08:11:53','2026-11-03 08:27:50'),(9,1,3,'DECOMPTE_A_VALIDER','DECOMPTE N°1 à valider — contrat 070','DECOMPTE N°1 du contrat 070 (SAGEC-KAT) : 450 567,00 USD, transmis au chef de cellule infrastructures. Saisi par Hermans imbaleva.','/decomptes?contrat=3','Decompte','6',NULL,'2026-11-04 07:55:11','2026-11-04 07:55:11');
/*!40000 ALTER TABLE `user_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_reset_tokens`
--

DROP TABLE IF EXISTS `user_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_reset_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `token_hash` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_reset_tokens_project_id_index` (`project_id`),
  KEY `user_reset_tokens_user_id_index` (`user_id`),
  KEY `user_reset_tokens_token_hash_index` (`token_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_reset_tokens`
--

LOCK TABLES `user_reset_tokens` WRITE;
/*!40000 ALTER TABLE `user_reset_tokens` DISABLE KEYS */;
INSERT INTO `user_reset_tokens` VALUES (1,1,1,'21a114ed7f7aa8a72a44e6cec28462ae8df8fcd14ac9f36576c38847fe5965e4','2026-10-15 10:52:43','2026-10-14 12:44:47','2026-10-14 10:52:43','2026-10-14 10:52:43'),(2,2,2,'e1b00f9a510a4299a25de13bae99e9babc9dbe3f5127ad99d7c66406849ed3e3','2026-10-15 10:52:43',NULL,'2026-10-14 10:52:43','2026-10-14 10:52:43'),(3,1,1,'7c39fc39bb75a4ffa2e076e2507414cf171159deabc0d766b0eadf6cbf17bfac','2026-10-15 12:38:27','2026-10-14 12:44:47','2026-10-14 12:38:27','2026-10-14 12:38:27'),(4,2,2,'8ba3622dfe208813a824acba531f55ea44ce5bc16da1686b3509e7e906567685','2026-10-15 12:38:27',NULL,'2026-10-14 12:38:27','2026-10-14 12:38:27'),(5,1,1,'9a5ebe64145c39b6eccdb9434c69ed1d02061c7c8b674f37debab1ab65ebea72','2026-10-14 13:14:47',NULL,'2026-10-14 12:44:47','2026-10-14 12:44:47'),(6,1,1,'3600eb2ce4281bf24e637cbb5cd2cb8e7070fe94b13949095c15ba0f4a99aae2','2026-10-15 13:19:27','2026-10-14 13:20:04','2026-10-14 13:19:27','2026-10-14 13:20:04'),(7,2,2,'325148eb8e48b3245f5e97726ccaa9d8b8aa7f34d8d27eb4067c36c858697d98','2026-10-15 13:19:27','2026-10-14 13:22:40','2026-10-14 13:19:27','2026-10-14 13:22:40');
/*!40000 ALTER TABLE `user_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned DEFAULT NULL,
  `full_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UTILISATEUR',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `can_view_archives` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_guarantees` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `password_hash` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_salt` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_pending` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_settings` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_users` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete_contracts` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_contracts` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_companies` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_progress` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_payments` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_reports` tinyint(1) NOT NULL DEFAULT '1',
  `can_view_alerts` tinyint(1) NOT NULL DEFAULT '1',
  `can_view_situation` tinyint(1) NOT NULL DEFAULT '1',
  `is_super_admin` tinyint(1) NOT NULL DEFAULT '0',
  `failed_login_count` int unsigned NOT NULL DEFAULT '0',
  `lockout_end` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `organizational_unit_id` bigint unsigned DEFAULT NULL,
  `position_id` bigint unsigned DEFAULT NULL,
  `can_view_stock` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_stock` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_fleet` tinyint(1) NOT NULL DEFAULT '0',
  `can_manage_fleet` tinyint(1) NOT NULL DEFAULT '0',
  `can_authorize_fleet` tinyint(1) NOT NULL DEFAULT '0',
  `can_validate_decomptes` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_pools` tinyint(1) NOT NULL DEFAULT '0',
  `logistics_authority` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `can_view_alerts_contracts` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_alerts_guarantees` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_alerts_logistics` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_project_unique` (`email`,`project_id`),
  KEY `users_organizational_unit_id_foreign` (`organizational_unit_id`),
  KEY `users_position_id_foreign` (`position_id`),
  CONSTRAINT `users_organizational_unit_id_foreign` FOREIGN KEY (`organizational_unit_id`) REFERENCES `organizational_units` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'Hermans imbaleva','hermansimbaleva20@gmail.com','$2y$12$ZDFW/BE.THj8BtgmfCfdLeaqccTX5vKkLt.eI06ffx8BpkdO5RjuS','Stagiaire en suivi et evaluation','ADMINISTRATEUR',1,1,1,NULL,'2026-10-14 10:52:43','2026-11-04 07:37:12',NULL,NULL,0,1,1,1,1,1,1,1,1,1,1,1,0,NULL,'2026-11-04 07:37:12',1,NULL,0,0,0,0,0,0,0,NULL,1,1,0),(2,2,'Hermans imbaleva','hermansimbaleva20@gmail.com','$2y$12$oR8mh/6lxLFaPX4QwenepeEfz9X0jRC56HCUz9khoI/OnnL6PE.Zu','Stagiaire en suivi et evaluation','ADMINISTRATEUR',1,1,1,NULL,'2026-10-14 10:52:43','2026-11-03 07:17:59',NULL,NULL,0,1,1,1,1,1,1,1,1,1,1,1,0,NULL,'2026-11-03 07:17:59',2,NULL,0,0,0,0,0,0,0,NULL,1,1,0),(3,1,'Jorcelin MIKADO','jorcelinmikado@gmail.com','$2y$12$bgjlILP8X.p0Du69DrS.7OzZD6PTOst6b4hV/fczmQHiFlApT3d76','COMPTABLE','UTILISATEUR',1,0,0,NULL,'2026-10-18 22:53:27','2026-11-03 13:36:18',NULL,NULL,0,0,0,0,1,0,0,1,0,0,0,0,0,NULL,'2026-10-28 17:03:48',1,3,1,0,1,0,0,1,0,NULL,0,0,0),(4,1,'BUKATITI Valentin','bukatitivalentin@gmail.com','$2y$12$mzL8U.3aifBH/bs29xEhB.20ut43VkLlnLnlJCSqt3J3AAzo6LUjS','SECA','UTILISATEUR',1,0,0,NULL,'2026-10-28 17:10:51','2026-10-29 14:40:29',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,'2026-10-29 14:07:47',4,17,1,1,1,1,1,0,0,'CA',0,0,1),(5,1,'Musikitela RUTH','ruthmusikitela45@gmail.com','$2y$12$KFB5oZjkoH/RegBI43H/LOfs1oPGC/86r6Ex90FNgzlfdMXYHPDBO','LOGISTICIEN','UTILISATEUR',1,0,0,NULL,'2026-10-28 17:29:41','2026-11-04 08:55:20',NULL,NULL,0,0,0,0,0,0,0,0,1,1,0,0,0,NULL,'2026-11-04 08:08:03',1,11,1,1,1,1,1,0,1,'COMPTABLE',0,0,1),(6,1,'Glody TSHIMPAKA','glody@gmail.com','$2y$12$HoKu5JPXMLGa.tM/1oQLROrBObPztV45P3QdHNJG/.7czJWOTuJMe','COMPTABLE','UTILISATEUR',1,0,0,NULL,'2026-10-29 08:52:53','2026-11-04 07:59:57',NULL,NULL,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'2026-11-03 08:11:36',1,3,0,0,1,1,1,1,1,'COMPTABLE',0,0,1),(7,1,'Grâce MUKOKO','gracemukoko@gmail.com','$2y$12$obpQKRh/uu2.FXNypYLkOuXrc9wTeCzLRq6lTvgAgw/yNHVYcZ0rG','C.A MBUJI-MAYI','UTILISATEUR',1,0,0,NULL,'2026-10-30 07:40:31','2026-10-30 07:44:04',NULL,NULL,0,0,0,0,0,0,0,0,1,1,1,0,0,NULL,'2026-10-30 07:44:04',3,16,1,0,1,0,0,0,0,NULL,1,1,0),(8,1,'Ghost IMBALEVA','ghostimbaleva@gmail.com','$2y$12$HmYRic7ByRNp/a52bBURBOxiiRFklTVKUer7uXr0gf1FUC6K.QHmG','SECA','UTILISATEUR',1,0,0,NULL,'2026-10-30 08:10:08','2026-10-30 08:15:34',NULL,NULL,0,0,0,0,1,0,0,0,0,1,0,0,0,NULL,'2026-10-30 08:14:47',3,18,1,1,1,1,1,0,0,'CA',1,1,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_types`
--

DROP TABLE IF EXISTS `work_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_types_unique` (`project_id`,`category`,`name`),
  KEY `work_types_project_id_index` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_types`
--

LOCK TABLES `work_types` WRITE;
/*!40000 ALTER TABLE `work_types` DISABLE KEYS */;
INSERT INTO `work_types` VALUES (1,1,'TRAVAUX','Système d’AEP',0,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(2,1,'TRAVAUX','École primaire',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(3,1,'TRAVAUX','Centre de santé',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(4,1,'TRAVAUX','Latrine publique',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(5,1,'TRAVAUX','Espace à vivre',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(6,2,'TRAVAUX','Système d’AEP',0,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(7,2,'TRAVAUX','École primaire',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(8,2,'TRAVAUX','Centre de santé',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(9,2,'TRAVAUX','Latrine publique',1,'2026-10-14 10:49:59','2026-10-14 10:49:59'),(10,2,'TRAVAUX','Espace à vivre',1,'2026-10-14 10:49:59','2026-10-14 10:49:59');
/*!40000 ALTER TABLE `work_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'prise_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-04 10:11:57
